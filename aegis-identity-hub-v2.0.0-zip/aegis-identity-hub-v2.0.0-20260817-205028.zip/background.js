var Qu = Object.defineProperty;
var Xu = (t, e, r) => e in t ? Qu(t, e, { enumerable: !0, configurable: !0, writable: !0, value: r }) : t[e] = r;
var B = (t, e, r) => Xu(t, typeof e != "symbol" ? e + "" : e, r);
function fs(t) {
  return t && t.__esModule && Object.prototype.hasOwnProperty.call(t, "default") ? t.default : t;
}
var Rn = { exports: {} }, Yu = Rn.exports, Qs;
function el() {
  return Qs || (Qs = 1, function(t, e) {
    (function(r, n) {
      n(t);
    })(typeof globalThis < "u" ? globalThis : typeof self < "u" ? self : Yu, function(r) {
      if (!(globalThis.chrome && globalThis.chrome.runtime && globalThis.chrome.runtime.id))
        throw new Error("This script should only be loaded in a browser extension.");
      if (globalThis.browser && globalThis.browser.runtime && globalThis.browser.runtime.id)
        r.exports = globalThis.browser;
      else {
        const n = "The message port closed before a response was received.", o = (s) => {
          const i = {
            alarms: {
              clear: {
                minArgs: 0,
                maxArgs: 1
              },
              clearAll: {
                minArgs: 0,
                maxArgs: 0
              },
              get: {
                minArgs: 0,
                maxArgs: 1
              },
              getAll: {
                minArgs: 0,
                maxArgs: 0
              }
            },
            bookmarks: {
              create: {
                minArgs: 1,
                maxArgs: 1
              },
              get: {
                minArgs: 1,
                maxArgs: 1
              },
              getChildren: {
                minArgs: 1,
                maxArgs: 1
              },
              getRecent: {
                minArgs: 1,
                maxArgs: 1
              },
              getSubTree: {
                minArgs: 1,
                maxArgs: 1
              },
              getTree: {
                minArgs: 0,
                maxArgs: 0
              },
              move: {
                minArgs: 2,
                maxArgs: 2
              },
              remove: {
                minArgs: 1,
                maxArgs: 1
              },
              removeTree: {
                minArgs: 1,
                maxArgs: 1
              },
              search: {
                minArgs: 1,
                maxArgs: 1
              },
              update: {
                minArgs: 2,
                maxArgs: 2
              }
            },
            browserAction: {
              disable: {
                minArgs: 0,
                maxArgs: 1,
                fallbackToNoCallback: !0
              },
              enable: {
                minArgs: 0,
                maxArgs: 1,
                fallbackToNoCallback: !0
              },
              getBadgeBackgroundColor: {
                minArgs: 1,
                maxArgs: 1
              },
              getBadgeText: {
                minArgs: 1,
                maxArgs: 1
              },
              getPopup: {
                minArgs: 1,
                maxArgs: 1
              },
              getTitle: {
                minArgs: 1,
                maxArgs: 1
              },
              openPopup: {
                minArgs: 0,
                maxArgs: 0
              },
              setBadgeBackgroundColor: {
                minArgs: 1,
                maxArgs: 1,
                fallbackToNoCallback: !0
              },
              setBadgeText: {
                minArgs: 1,
                maxArgs: 1,
                fallbackToNoCallback: !0
              },
              setIcon: {
                minArgs: 1,
                maxArgs: 1
              },
              setPopup: {
                minArgs: 1,
                maxArgs: 1,
                fallbackToNoCallback: !0
              },
              setTitle: {
                minArgs: 1,
                maxArgs: 1,
                fallbackToNoCallback: !0
              }
            },
            browsingData: {
              remove: {
                minArgs: 2,
                maxArgs: 2
              },
              removeCache: {
                minArgs: 1,
                maxArgs: 1
              },
              removeCookies: {
                minArgs: 1,
                maxArgs: 1
              },
              removeDownloads: {
                minArgs: 1,
                maxArgs: 1
              },
              removeFormData: {
                minArgs: 1,
                maxArgs: 1
              },
              removeHistory: {
                minArgs: 1,
                maxArgs: 1
              },
              removeLocalStorage: {
                minArgs: 1,
                maxArgs: 1
              },
              removePasswords: {
                minArgs: 1,
                maxArgs: 1
              },
              removePluginData: {
                minArgs: 1,
                maxArgs: 1
              },
              settings: {
                minArgs: 0,
                maxArgs: 0
              }
            },
            commands: {
              getAll: {
                minArgs: 0,
                maxArgs: 0
              }
            },
            contextMenus: {
              remove: {
                minArgs: 1,
                maxArgs: 1
              },
              removeAll: {
                minArgs: 0,
                maxArgs: 0
              },
              update: {
                minArgs: 2,
                maxArgs: 2
              }
            },
            cookies: {
              get: {
                minArgs: 1,
                maxArgs: 1
              },
              getAll: {
                minArgs: 1,
                maxArgs: 1
              },
              getAllCookieStores: {
                minArgs: 0,
                maxArgs: 0
              },
              remove: {
                minArgs: 1,
                maxArgs: 1
              },
              set: {
                minArgs: 1,
                maxArgs: 1
              }
            },
            devtools: {
              inspectedWindow: {
                eval: {
                  minArgs: 1,
                  maxArgs: 2,
                  singleCallbackArg: !1
                }
              },
              panels: {
                create: {
                  minArgs: 3,
                  maxArgs: 3,
                  singleCallbackArg: !0
                },
                elements: {
                  createSidebarPane: {
                    minArgs: 1,
                    maxArgs: 1
                  }
                }
              }
            },
            downloads: {
              cancel: {
                minArgs: 1,
                maxArgs: 1
              },
              download: {
                minArgs: 1,
                maxArgs: 1
              },
              erase: {
                minArgs: 1,
                maxArgs: 1
              },
              getFileIcon: {
                minArgs: 1,
                maxArgs: 2
              },
              open: {
                minArgs: 1,
                maxArgs: 1,
                fallbackToNoCallback: !0
              },
              pause: {
                minArgs: 1,
                maxArgs: 1
              },
              removeFile: {
                minArgs: 1,
                maxArgs: 1
              },
              resume: {
                minArgs: 1,
                maxArgs: 1
              },
              search: {
                minArgs: 1,
                maxArgs: 1
              },
              show: {
                minArgs: 1,
                maxArgs: 1,
                fallbackToNoCallback: !0
              }
            },
            extension: {
              isAllowedFileSchemeAccess: {
                minArgs: 0,
                maxArgs: 0
              },
              isAllowedIncognitoAccess: {
                minArgs: 0,
                maxArgs: 0
              }
            },
            history: {
              addUrl: {
                minArgs: 1,
                maxArgs: 1
              },
              deleteAll: {
                minArgs: 0,
                maxArgs: 0
              },
              deleteRange: {
                minArgs: 1,
                maxArgs: 1
              },
              deleteUrl: {
                minArgs: 1,
                maxArgs: 1
              },
              getVisits: {
                minArgs: 1,
                maxArgs: 1
              },
              search: {
                minArgs: 1,
                maxArgs: 1
              }
            },
            i18n: {
              detectLanguage: {
                minArgs: 1,
                maxArgs: 1
              },
              getAcceptLanguages: {
                minArgs: 0,
                maxArgs: 0
              }
            },
            identity: {
              launchWebAuthFlow: {
                minArgs: 1,
                maxArgs: 1
              }
            },
            idle: {
              queryState: {
                minArgs: 1,
                maxArgs: 1
              }
            },
            management: {
              get: {
                minArgs: 1,
                maxArgs: 1
              },
              getAll: {
                minArgs: 0,
                maxArgs: 0
              },
              getSelf: {
                minArgs: 0,
                maxArgs: 0
              },
              setEnabled: {
                minArgs: 2,
                maxArgs: 2
              },
              uninstallSelf: {
                minArgs: 0,
                maxArgs: 1
              }
            },
            notifications: {
              clear: {
                minArgs: 1,
                maxArgs: 1
              },
              create: {
                minArgs: 1,
                maxArgs: 2
              },
              getAll: {
                minArgs: 0,
                maxArgs: 0
              },
              getPermissionLevel: {
                minArgs: 0,
                maxArgs: 0
              },
              update: {
                minArgs: 2,
                maxArgs: 2
              }
            },
            pageAction: {
              getPopup: {
                minArgs: 1,
                maxArgs: 1
              },
              getTitle: {
                minArgs: 1,
                maxArgs: 1
              },
              hide: {
                minArgs: 1,
                maxArgs: 1,
                fallbackToNoCallback: !0
              },
              setIcon: {
                minArgs: 1,
                maxArgs: 1
              },
              setPopup: {
                minArgs: 1,
                maxArgs: 1,
                fallbackToNoCallback: !0
              },
              setTitle: {
                minArgs: 1,
                maxArgs: 1,
                fallbackToNoCallback: !0
              },
              show: {
                minArgs: 1,
                maxArgs: 1,
                fallbackToNoCallback: !0
              }
            },
            permissions: {
              contains: {
                minArgs: 1,
                maxArgs: 1
              },
              getAll: {
                minArgs: 0,
                maxArgs: 0
              },
              remove: {
                minArgs: 1,
                maxArgs: 1
              },
              request: {
                minArgs: 1,
                maxArgs: 1
              }
            },
            runtime: {
              getBackgroundPage: {
                minArgs: 0,
                maxArgs: 0
              },
              getPlatformInfo: {
                minArgs: 0,
                maxArgs: 0
              },
              openOptionsPage: {
                minArgs: 0,
                maxArgs: 0
              },
              requestUpdateCheck: {
                minArgs: 0,
                maxArgs: 0
              },
              sendMessage: {
                minArgs: 1,
                maxArgs: 3
              },
              sendNativeMessage: {
                minArgs: 2,
                maxArgs: 2
              },
              setUninstallURL: {
                minArgs: 1,
                maxArgs: 1
              }
            },
            sessions: {
              getDevices: {
                minArgs: 0,
                maxArgs: 1
              },
              getRecentlyClosed: {
                minArgs: 0,
                maxArgs: 1
              },
              restore: {
                minArgs: 0,
                maxArgs: 1
              }
            },
            storage: {
              local: {
                clear: {
                  minArgs: 0,
                  maxArgs: 0
                },
                get: {
                  minArgs: 0,
                  maxArgs: 1
                },
                getBytesInUse: {
                  minArgs: 0,
                  maxArgs: 1
                },
                remove: {
                  minArgs: 1,
                  maxArgs: 1
                },
                set: {
                  minArgs: 1,
                  maxArgs: 1
                }
              },
              managed: {
                get: {
                  minArgs: 0,
                  maxArgs: 1
                },
                getBytesInUse: {
                  minArgs: 0,
                  maxArgs: 1
                }
              },
              sync: {
                clear: {
                  minArgs: 0,
                  maxArgs: 0
                },
                get: {
                  minArgs: 0,
                  maxArgs: 1
                },
                getBytesInUse: {
                  minArgs: 0,
                  maxArgs: 1
                },
                remove: {
                  minArgs: 1,
                  maxArgs: 1
                },
                set: {
                  minArgs: 1,
                  maxArgs: 1
                }
              }
            },
            tabs: {
              captureVisibleTab: {
                minArgs: 0,
                maxArgs: 2
              },
              create: {
                minArgs: 1,
                maxArgs: 1
              },
              detectLanguage: {
                minArgs: 0,
                maxArgs: 1
              },
              discard: {
                minArgs: 0,
                maxArgs: 1
              },
              duplicate: {
                minArgs: 1,
                maxArgs: 1
              },
              executeScript: {
                minArgs: 1,
                maxArgs: 2
              },
              get: {
                minArgs: 1,
                maxArgs: 1
              },
              getCurrent: {
                minArgs: 0,
                maxArgs: 0
              },
              getZoom: {
                minArgs: 0,
                maxArgs: 1
              },
              getZoomSettings: {
                minArgs: 0,
                maxArgs: 1
              },
              goBack: {
                minArgs: 0,
                maxArgs: 1
              },
              goForward: {
                minArgs: 0,
                maxArgs: 1
              },
              highlight: {
                minArgs: 1,
                maxArgs: 1
              },
              insertCSS: {
                minArgs: 1,
                maxArgs: 2
              },
              move: {
                minArgs: 2,
                maxArgs: 2
              },
              query: {
                minArgs: 1,
                maxArgs: 1
              },
              reload: {
                minArgs: 0,
                maxArgs: 2
              },
              remove: {
                minArgs: 1,
                maxArgs: 1
              },
              removeCSS: {
                minArgs: 1,
                maxArgs: 2
              },
              sendMessage: {
                minArgs: 2,
                maxArgs: 3
              },
              setZoom: {
                minArgs: 1,
                maxArgs: 2
              },
              setZoomSettings: {
                minArgs: 1,
                maxArgs: 2
              },
              update: {
                minArgs: 1,
                maxArgs: 2
              }
            },
            topSites: {
              get: {
                minArgs: 0,
                maxArgs: 0
              }
            },
            webNavigation: {
              getAllFrames: {
                minArgs: 1,
                maxArgs: 1
              },
              getFrame: {
                minArgs: 1,
                maxArgs: 1
              }
            },
            webRequest: {
              handlerBehaviorChanged: {
                minArgs: 0,
                maxArgs: 0
              }
            },
            windows: {
              create: {
                minArgs: 0,
                maxArgs: 1
              },
              get: {
                minArgs: 1,
                maxArgs: 2
              },
              getAll: {
                minArgs: 0,
                maxArgs: 1
              },
              getCurrent: {
                minArgs: 0,
                maxArgs: 1
              },
              getLastFocused: {
                minArgs: 0,
                maxArgs: 1
              },
              remove: {
                minArgs: 1,
                maxArgs: 1
              },
              update: {
                minArgs: 2,
                maxArgs: 2
              }
            }
          };
          if (Object.keys(i).length === 0)
            throw new Error("api-metadata.json has not been included in browser-polyfill");
          class a extends WeakMap {
            constructor(p, E = void 0) {
              super(E), this.createItem = p;
            }
            get(p) {
              return this.has(p) || this.set(p, this.createItem(p)), super.get(p);
            }
          }
          const c = (d) => d && typeof d == "object" && typeof d.then == "function", u = (d, p) => (...E) => {
            s.runtime.lastError ? d.reject(new Error(s.runtime.lastError.message)) : p.singleCallbackArg || E.length <= 1 && p.singleCallbackArg !== !1 ? d.resolve(E[0]) : d.resolve(E);
          }, l = (d) => d == 1 ? "argument" : "arguments", h = (d, p) => function(I, ...R) {
            if (R.length < p.minArgs)
              throw new Error(`Expected at least ${p.minArgs} ${l(p.minArgs)} for ${d}(), got ${R.length}`);
            if (R.length > p.maxArgs)
              throw new Error(`Expected at most ${p.maxArgs} ${l(p.maxArgs)} for ${d}(), got ${R.length}`);
            return new Promise((A, M) => {
              if (p.fallbackToNoCallback)
                try {
                  I[d](...R, u({
                    resolve: A,
                    reject: M
                  }, p));
                } catch (P) {
                  console.warn(`${d} API method doesn't seem to support the callback parameter, falling back to call it without a callback: `, P), I[d](...R), p.fallbackToNoCallback = !1, p.noCallback = !0, A();
                }
              else p.noCallback ? (I[d](...R), A()) : I[d](...R, u({
                resolve: A,
                reject: M
              }, p));
            });
          }, m = (d, p, E) => new Proxy(p, {
            apply(I, R, A) {
              return E.call(R, d, ...A);
            }
          });
          let _ = Function.call.bind(Object.prototype.hasOwnProperty);
          const S = (d, p = {}, E = {}) => {
            let I = /* @__PURE__ */ Object.create(null), R = {
              has(M, P) {
                return P in d || P in I;
              },
              get(M, P, x) {
                if (P in I)
                  return I[P];
                if (!(P in d))
                  return;
                let G = d[P];
                if (typeof G == "function")
                  if (typeof p[P] == "function")
                    G = m(d, d[P], p[P]);
                  else if (_(E, P)) {
                    let fe = h(P, E[P]);
                    G = m(d, d[P], fe);
                  } else
                    G = G.bind(d);
                else if (typeof G == "object" && G !== null && (_(p, P) || _(E, P)))
                  G = S(G, p[P], E[P]);
                else if (_(E, "*"))
                  G = S(G, p[P], E["*"]);
                else
                  return Object.defineProperty(I, P, {
                    configurable: !0,
                    enumerable: !0,
                    get() {
                      return d[P];
                    },
                    set(fe) {
                      d[P] = fe;
                    }
                  }), G;
                return I[P] = G, G;
              },
              set(M, P, x, G) {
                return P in I ? I[P] = x : d[P] = x, !0;
              },
              defineProperty(M, P, x) {
                return Reflect.defineProperty(I, P, x);
              },
              deleteProperty(M, P) {
                return Reflect.deleteProperty(I, P);
              }
            }, A = Object.create(d);
            return new Proxy(A, R);
          }, $ = (d) => ({
            addListener(p, E, ...I) {
              p.addListener(d.get(E), ...I);
            },
            hasListener(p, E) {
              return p.hasListener(d.get(E));
            },
            removeListener(p, E) {
              p.removeListener(d.get(E));
            }
          }), v = new a((d) => typeof d != "function" ? d : function(E) {
            const I = S(E, {}, {
              getContent: {
                minArgs: 0,
                maxArgs: 0
              }
            });
            d(I);
          }), y = new a((d) => typeof d != "function" ? d : function(E, I, R) {
            let A = !1, M, P = new Promise((ue) => {
              M = function(ee) {
                A = !0, ue(ee);
              };
            }), x;
            try {
              x = d(E, I, M);
            } catch (ue) {
              x = Promise.reject(ue);
            }
            const G = x !== !0 && c(x);
            if (x !== !0 && !G && !A)
              return !1;
            const fe = (ue) => {
              ue.then((ee) => {
                R(ee);
              }, (ee) => {
                let Pe;
                ee && (ee instanceof Error || typeof ee.message == "string") ? Pe = ee.message : Pe = "An unexpected error occurred", R({
                  __mozWebExtensionPolyfillReject__: !0,
                  message: Pe
                });
              }).catch((ee) => {
                console.error("Failed to send onMessage rejected reply", ee);
              });
            };
            return fe(G ? x : P), !0;
          }), g = ({
            reject: d,
            resolve: p
          }, E) => {
            s.runtime.lastError ? s.runtime.lastError.message === n ? p() : d(new Error(s.runtime.lastError.message)) : E && E.__mozWebExtensionPolyfillReject__ ? d(new Error(E.message)) : p(E);
          }, w = (d, p, E, ...I) => {
            if (I.length < p.minArgs)
              throw new Error(`Expected at least ${p.minArgs} ${l(p.minArgs)} for ${d}(), got ${I.length}`);
            if (I.length > p.maxArgs)
              throw new Error(`Expected at most ${p.maxArgs} ${l(p.maxArgs)} for ${d}(), got ${I.length}`);
            return new Promise((R, A) => {
              const M = g.bind(null, {
                resolve: R,
                reject: A
              });
              I.push(M), E.sendMessage(...I);
            });
          }, k = {
            devtools: {
              network: {
                onRequestFinished: $(v)
              }
            },
            runtime: {
              onMessage: $(y),
              onMessageExternal: $(y),
              sendMessage: w.bind(null, "sendMessage", {
                minArgs: 1,
                maxArgs: 3
              })
            },
            tabs: {
              sendMessage: w.bind(null, "sendMessage", {
                minArgs: 2,
                maxArgs: 3
              })
            }
          }, f = {
            clear: {
              minArgs: 1,
              maxArgs: 1
            },
            get: {
              minArgs: 1,
              maxArgs: 1
            },
            set: {
              minArgs: 1,
              maxArgs: 1
            }
          };
          return i.privacy = {
            network: {
              "*": f
            },
            services: {
              "*": f
            },
            websites: {
              "*": f
            }
          }, S(s, k, i);
        };
        r.exports = o(chrome);
      }
    });
  }(Rn)), Rn.exports;
}
el();
var Tr;
(function(t) {
  t.Local = "local", t.Sync = "sync", t.Managed = "managed", t.Session = "session";
})(Tr || (Tr = {}));
var xo;
(function(t) {
  t.ExtensionPagesOnly = "TRUSTED_CONTEXTS", t.ExtensionPagesAndContentScripts = "TRUSTED_AND_UNTRUSTED_CONTEXTS";
})(xo || (xo = {}));
const Ye = globalThis.chrome, Xs = async (t, e) => {
  const r = (o) => typeof o == "function", n = (o) => o instanceof Promise;
  return r(t) ? (n(t), t(e)) : t;
};
let Ys = !1;
function ei(t) {
  if (Ye && Ye.storage[t] === void 0)
    throw new Error(`Check your storage permission in manifest.json: ${t} is not defined`);
}
function tl(t, e, r) {
  var $, v;
  let n = null, o = !1, s = [];
  const i = (r == null ? void 0 : r.storageEnum) ?? Tr.Local, a = (($ = r == null ? void 0 : r.serialization) == null ? void 0 : $.serialize) ?? ((y) => y), c = ((v = r == null ? void 0 : r.serialization) == null ? void 0 : v.deserialize) ?? ((y) => y);
  Ys === !1 && i === Tr.Session && (r == null ? void 0 : r.sessionAccessForContentScripts) === !0 && (ei(i), Ye == null || Ye.storage[i].setAccessLevel({
    accessLevel: xo.ExtensionPagesAndContentScripts
  }).catch((y) => {
    console.warn(y), console.warn("Please call setAccessLevel into different context, like a background script.");
  }), Ys = !0);
  const u = async () => {
    ei(i);
    const y = await (Ye == null ? void 0 : Ye.storage[i].get([t]));
    return y ? c(y[t]) ?? e : e;
  }, l = () => {
    s.forEach((y) => y());
  }, h = async (y) => {
    o || (n = await u()), n = await Xs(y, n), await (Ye == null ? void 0 : Ye.storage[i].set({ [t]: a(n) })), l();
  }, m = (y) => (s = [...s, y], () => {
    s = s.filter((g) => g !== y);
  }), _ = () => n;
  u().then((y) => {
    n = y, o = !0, l();
  });
  async function S(y) {
    if (y[t] === void 0)
      return;
    const g = c(y[t].newValue);
    n !== g && (n = await Xs(g, n), l());
  }
  return Ye == null || Ye.storage[i].onChanged.addListener(S), {
    get: u,
    set: h,
    getSnapshot: _,
    subscribe: m
  };
}
const ti = tl("theme-storage-key", "light", {
  storageEnum: Tr.Local
}), rl = {
  ...ti,
  toggle: async () => {
    await ti.set((t) => t === "light" ? "dark" : "light");
  }
};
var St = /* @__PURE__ */ ((t) => (t[t.DEBUG = 0] = "DEBUG", t[t.INFO = 1] = "INFO", t[t.WARN = 2] = "WARN", t[t.ERROR = 3] = "ERROR", t[t.NONE = 4] = "NONE", t))(St || {});
const nl = "mcp_logger_config";
class ol {
  constructor(e = nl) {
    B(this, "storageKey");
    this.storageKey = e;
  }
  /**
   * Get the global log level from storage
   */
  async getLevel() {
    try {
      if (typeof chrome > "u" || !chrome.storage)
        return null;
      const r = (await chrome.storage.local.get(this.storageKey))[this.storageKey];
      return r && typeof r.level == "number" ? r.level : null;
    } catch (e) {
      return console.error("[LoggerStorage] Failed to get level:", e), null;
    }
  }
  /**
   * Set the global log level in storage
   */
  async setLevel(e) {
    try {
      if (typeof chrome > "u" || !chrome.storage)
        return;
      const n = (await chrome.storage.local.get(this.storageKey))[this.storageKey] || {};
      n.level = e, await chrome.storage.local.set({ [this.storageKey]: n });
    } catch (r) {
      console.error("[LoggerStorage] Failed to set level:", r);
    }
  }
  /**
   * Get component-specific log levels from storage
   */
  async getComponentLevels() {
    try {
      if (typeof chrome > "u" || !chrome.storage)
        return {};
      const r = (await chrome.storage.local.get(this.storageKey))[this.storageKey];
      return r && r.componentLevels ? r.componentLevels : {};
    } catch (e) {
      return console.error("[LoggerStorage] Failed to get component levels:", e), {};
    }
  }
  /**
   * Set a component-specific log level in storage
   */
  async setComponentLevel(e, r) {
    try {
      if (typeof chrome > "u" || !chrome.storage)
        return;
      const o = (await chrome.storage.local.get(this.storageKey))[this.storageKey] || {};
      o.componentLevels || (o.componentLevels = {}), o.componentLevels[e] = r, await chrome.storage.local.set({ [this.storageKey]: o });
    } catch (n) {
      console.error("[LoggerStorage] Failed to set component level:", n);
    }
  }
  /**
   * Clear all logger configuration from storage
   */
  async clear() {
    try {
      if (typeof chrome > "u" || !chrome.storage)
        return;
      await chrome.storage.local.remove(this.storageKey);
    } catch (e) {
      console.error("[LoggerStorage] Failed to clear storage:", e);
    }
  }
}
const sl = { BASE_URL: "/", CEB_GA_API_SECRET: "oVosLwqtS5u_lNpCrO_-_g", CEB_GA_MEASUREMENT_ID: "G-GYKRZLYBXQ", DEV: !1, MODE: "production", PROD: !0, SSR: !1, VITE_GA_API_SECRET: "oVosLwqtS5u_lNpCrO_-_g", VITE_GA_MEASUREMENT_ID: "G-GYKRZLYBXQ" };
function ri(t) {
  return typeof t == "number" ? t : St[t];
}
class hs {
  constructor(e = "", r) {
    B(this, "level");
    B(this, "componentLevels");
    B(this, "namespace");
    B(this, "storage");
    B(this, "defaultLevel");
    B(this, "isInitialized", !1);
    this.namespace = e, this.componentLevels = /* @__PURE__ */ new Map();
    const n = this.isProductionEnvironment();
    this.defaultLevel = n ? St.ERROR : St.DEBUG, this.level = St.ERROR, r != null && r.componentLevels && Object.entries(r.componentLevels).forEach(([o, s]) => {
      this.componentLevels.set(o, s);
    }), this.storage = (r == null ? void 0 : r.persist) !== !1 ? new ol(r == null ? void 0 : r.storageKey) : null, this.storage && this.initializeFromStorage();
  }
  /**
   * Detect if running in production environment
   */
  isProductionEnvironment() {
    try {
      if (typeof import.meta < "u" && sl)
        return !0;
    } catch {
    }
    if (typeof chrome < "u" && chrome.runtime)
      try {
        return !chrome.runtime.getURL("").includes("dev");
      } catch {
      }
    return !0;
  }
  /**
   * Initialize logger settings from Chrome Storage
   */
  async initializeFromStorage() {
    if (this.storage)
      try {
        const e = await this.storage.getLevel();
        e !== null && (this.level = e);
        const r = await this.storage.getComponentLevels();
        Object.entries(r).forEach(([n, o]) => {
          this.componentLevels.set(n, o);
        }), this.isInitialized = !0;
      } catch (e) {
        console.error("[Logger] Failed to initialize from storage:", e);
      }
  }
  /**
   * Get the effective log level for this logger instance
   */
  getEffectiveLevel() {
    return this.namespace && this.componentLevels.has(this.namespace) ? this.componentLevels.get(this.namespace) : this.level;
  }
  /**
   * Check if a message should be logged based on current level
   */
  shouldLog(e) {
    return e >= this.getEffectiveLevel();
  }
  /**
   * Format the log message with namespace prefix
   */
  formatMessage(...e) {
    return this.namespace ? [`[${this.namespace}]`, ...e] : e;
  }
  /**
   * Log a debug message
   */
  debug(...e) {
    this.shouldLog(St.DEBUG) && console.debug(...this.formatMessage(...e));
  }
  /**
   * Log an info message
   */
  info(...e) {
    this.shouldLog(St.INFO) && console.info(...this.formatMessage(...e));
  }
  /**
   * Log a warning message
   */
  warn(...e) {
    this.shouldLog(St.WARN) && console.warn(...this.formatMessage(...e));
  }
  /**
   * Log an error message
   */
  error(...e) {
    this.shouldLog(St.ERROR) && console.error(...this.formatMessage(...e));
  }
  /**
   * Set the global log level
   */
  setLevel(e) {
    this.level = ri(e), this.storage && this.storage.setLevel(this.level).catch((r) => {
      console.error("[Logger] Failed to persist level:", r);
    });
  }
  /**
   * Get the current global log level
   */
  getLevel() {
    return this.level;
  }
  /**
   * Set a component-specific log level
   */
  setComponentLevel(e, r) {
    const n = ri(r);
    this.componentLevels.set(e, n), this.storage && this.storage.setComponentLevel(e, n).catch((o) => {
      console.error("[Logger] Failed to persist component level:", o);
    });
  }
  /**
   * Get a component-specific log level
   */
  getComponentLevel(e) {
    return this.componentLevels.get(e);
  }
  /**
   * Reset all log levels to environment defaults
   */
  resetToDefaults() {
    this.level = this.defaultLevel, this.componentLevels.clear(), this.storage && this.storage.clear().catch((e) => {
      console.error("[Logger] Failed to clear storage:", e);
    });
  }
  /**
   * Create a child logger with a specific namespace
   */
  child(e) {
    return new hs(e, {
      level: this.level,
      componentLevels: Object.fromEntries(this.componentLevels),
      persist: !1
      // Child loggers don't persist independently
    });
  }
  /**
   * Wait for storage initialization to complete
   */
  async waitForInitialization() {
    if (!this.storage) return;
    const e = 2e3, r = Date.now();
    for (; !this.isInitialized && Date.now() - r < e; )
      await new Promise((n) => setTimeout(n, 50));
  }
}
let ho = null;
function nt(t, e) {
  return ho || (ho = new hs("", e)), ho.child(t);
}
const Te = nt("FirebaseRemoteConfigAPI");
class il {
  constructor() {
    B(this, "projectConfig");
    B(this, "cachedConfig", {});
    B(this, "lastFetchTime", 0);
    B(this, "minimumFetchInterval", 36e5);
    // 1 hour in production
    B(this, "fetchTimeout", 6e4);
    // 60 seconds
    // Default configuration values
    B(this, "defaultConfig", {
      notifications_enabled: "true",
      max_notifications_per_day: "3",
      notification_cooldown_hours: "4",
      features: JSON.stringify({
        sidebar_v2: { enabled: !1, rollout: 0, schema_version: 1 },
        ai_tools_enhanced: { enabled: !0, rollout: 100, schema_version: 1 },
        notification_system: { enabled: !0, rollout: 100, schema_version: 1 }
      }),
      config_version: "1.0.0",
      schema_version: "1",
      last_updated: (/* @__PURE__ */ new Date()).toISOString(),
      privacy_policy_version: "1.0.0",
      data_collection_consent_required: "true",
      active_notifications: JSON.stringify([]),
      update_notifications: JSON.stringify({
        enabled: !0,
        min_version_gap: "0.1.0",
        channels: ["in-app", "badge"],
        schema_version: 1
      })
    });
    {
      Te.debug("[FirebaseRemoteConfigAPI] Remote Config is DISABLED - using defaults only"), this.projectConfig = { projectId: "", apiKey: "", appId: "" }, this.minimumFetchInterval = 0;
      return;
    }
  }
  async initialize() {
    Te.debug("[FirebaseRemoteConfigAPI] Initializing Remote Config API...");
    {
      Te.debug("[FirebaseRemoteConfigAPI] Remote Config DISABLED - initializing with defaults only"), this.initializeWithDefaults(), Te.debug("[FirebaseRemoteConfigAPI] Remote Config API initialized with defaults only");
      return;
    }
  }
  async fetchAndActivate(e = !1) {
    return Te.debug("[FirebaseRemoteConfigAPI] Remote Config DISABLED - skipping fetch, using defaults only"), !1;
  }
  async fetchRemoteConfig() {
    try {
      const e = await this.getInstallationId(), r = `https://firebaseremoteconfig.googleapis.com/v1/projects/${this.projectConfig.projectId}/namespaces/firebase:fetch`, n = {
        appId: this.projectConfig.appId,
        appInstanceId: e,
        appInstanceIdToken: "",
        // Would need Firebase Installations API for this
        languageCode: "en-US",
        platformVersion: chrome.runtime.getManifest().version,
        timeZone: Intl.DateTimeFormat().resolvedOptions().timeZone
      }, o = new AbortController(), s = setTimeout(() => o.abort(), this.fetchTimeout);
      Te.debug("[FirebaseRemoteConfigAPI] Making request to:", r), Te.debug("[FirebaseRemoteConfigAPI] Request body:", JSON.stringify(n, null, 2));
      const i = await fetch(r, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "X-Goog-Api-Key": this.projectConfig.apiKey
        },
        body: JSON.stringify(n),
        signal: o.signal
      });
      if (clearTimeout(s), Te.debug("[FirebaseRemoteConfigAPI] Response status:", i.status, i.statusText), Te.debug("[FirebaseRemoteConfigAPI] Content-Type:", i.headers.get("content-type")), !i.ok) {
        const c = await i.text();
        throw Te.error("[FirebaseRemoteConfigAPI] Error response body:", c), new Error(`HTTP ${i.status}: ${i.statusText} - ${c}`);
      }
      const a = await i.json();
      if (Te.debug("[FirebaseRemoteConfigAPI] Raw Firebase response:", JSON.stringify(a, null, 2)), a.entries) {
        const c = {};
        Object.entries(a.entries).forEach(([l, h]) => {
          c[l] = {
            value: h,
            source: "remote"
          };
        });
        const u = {};
        for (const [l, h] of Object.entries(this.defaultConfig))
          u[l] = {
            value: h,
            source: "default"
          };
        Object.assign(u, c), this.cachedConfig = u, Te.debug(`Updated config with ${Object.keys(a.entries).length} remote values, removed deleted keys`), Te.debug("[FirebaseRemoteConfigAPI] Fetched configuration details:"), Object.entries(c).forEach(([l, h]) => {
          const m = h.value, _ = h.source;
          let S = m;
          try {
            if (m && typeof m == "string") {
              const $ = JSON.parse(m);
              S = JSON.stringify($, null, 2);
            }
          } catch {
          }
          Te.debug(`  ${l} (${_}):`, S);
        });
      } else
        Te.warn("[FirebaseRemoteConfigAPI] No entries found in response:", a);
      return !0;
    } catch (e) {
      return e instanceof Error && e.name === "AbortError" ? Te.error("[FirebaseRemoteConfigAPI] Fetch timeout") : Te.error("[FirebaseRemoteConfigAPI] Fetch failed:", e), !1;
    }
  }
  getValue(e) {
    return this.cachedConfig[e] ? this.cachedConfig[e] : this.defaultConfig[e] ? {
      value: this.defaultConfig[e],
      source: "default"
    } : {
      value: "",
      source: "static"
    };
  }
  getAll() {
    const e = {};
    for (const [r, n] of Object.entries(this.defaultConfig))
      e[r] = {
        value: n,
        source: "default"
      };
    for (const [r, n] of Object.entries(this.cachedConfig))
      e[r] = n;
    return e;
  }
  initializeWithDefaults() {
    for (const [e, r] of Object.entries(this.defaultConfig))
      this.cachedConfig[e] || (this.cachedConfig[e] = {
        value: r,
        source: "default"
      });
  }
  async loadCachedConfig() {
    try {
      const e = await chrome.storage.local.get(["firebaseRemoteConfig", "firebaseRemoteConfigLastFetch"]);
      e.firebaseRemoteConfig && (this.cachedConfig = e.firebaseRemoteConfig), e.firebaseRemoteConfigLastFetch && (this.lastFetchTime = e.firebaseRemoteConfigLastFetch);
    } catch (e) {
      Te.error("[FirebaseRemoteConfigAPI] Failed to load cached config:", e);
    }
  }
  async saveCachedConfig() {
    try {
      await chrome.storage.local.set({
        firebaseRemoteConfig: this.cachedConfig,
        firebaseRemoteConfigLastFetch: this.lastFetchTime
      });
    } catch (e) {
      Te.error("[FirebaseRemoteConfigAPI] Failed to save cached config:", e);
    }
  }
  async getInstallationId() {
    try {
      const e = await chrome.storage.local.get(["firebaseInstallationId"]);
      if (e.firebaseInstallationId)
        return e.firebaseInstallationId;
      const r = this.generateInstallationId();
      return await chrome.storage.local.set({ firebaseInstallationId: r }), r;
    } catch (e) {
      return Te.error("[FirebaseRemoteConfigAPI] Failed to get installation ID:", e), this.generateInstallationId();
    }
  }
  generateInstallationId() {
    const e = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
    let r = "";
    for (let n = 0; n < 22; n++)
      r += e.charAt(Math.floor(Math.random() * e.length));
    return r;
  }
  /**
   * Clear cached config and force a fresh fetch
   * Useful when dealing with deleted Firebase keys
   */
  async clearCacheAndRefetch() {
    return Te.debug("[FirebaseRemoteConfigAPI] Remote Config DISABLED - skipping cache clear, using defaults only"), !1;
  }
}
const po = (t) => {
  if (!t || typeof t != "object")
    return !1;
  try {
    return !(t.features && typeof t.features != "object" || t.notifications && !Array.isArray(t.notifications));
  } catch (e) {
    return Te.error("[FirebaseRemoteConfigAPI] Validation error:", e), !1;
  }
}, He = new il(), re = nt("RemoteConfigManager");
class al {
  constructor() {
    B(this, "isInitialized", !1);
    B(this, "fetchInterval", null);
    B(this, "lastFetchTime", null);
    B(this, "retryCount", 0);
    B(this, "maxRetries", 3);
  }
  async initialize() {
    try {
      re.debug("[RemoteConfigManager] Initializing Remote Config Manager..."), await He.initialize(), await this.fetchConfig(!0), this.startPeriodicFetch(), this.isInitialized = !0, re.debug("[RemoteConfigManager] Remote Config Manager initialized successfully");
    } catch (e) {
      throw re.error("[RemoteConfigManager] Failed to initialize:", e), e;
    }
  }
  async fetchConfig(e = !1) {
    try {
      const r = Date.now();
      if (!e && this.lastFetchTime && r - this.lastFetchTime < 36e5) {
        re.debug("[RemoteConfigManager] Skipping fetch due to minimum interval");
        return;
      }
      re.debug("[RemoteConfigManager] Fetching remote config..."), await He.fetchAndActivate(e), await this.processConfiguration(), this.lastFetchTime = r, await this.setLastFetchTime(r), this.retryCount = 0, re.debug("[RemoteConfigManager] Remote config fetched successfully");
      const o = He.getAll(), s = Object.values(o).filter((a) => a.source === "remote").length, i = Object.values(o).filter((a) => a.source === "default").length;
      re.debug(`Config summary: ${s} remote values, ${i} default values`);
    } catch (r) {
      this.retryCount++;
      const n = r instanceof Error ? r.message : String(r);
      if (re.error("[RemoteConfigManager] Failed to fetch config:", n), this.retryCount <= this.maxRetries) {
        const o = Math.pow(2, this.retryCount) * 1e3;
        setTimeout(() => this.fetchConfig(e), o);
      }
      throw r;
    }
  }
  async processConfiguration() {
    try {
      const e = He.getAll();
      re.debug("[RemoteConfigManager] Processing configuration. Available configs:"), Object.entries(e).forEach(([r, n]) => {
        const o = n.value, s = n.source;
        let i = o;
        try {
          const a = JSON.parse(o);
          i = JSON.stringify(a, null, 2);
        } catch {
        }
        re.debug(`  ${r} (${s}):`, i);
      }), await this.processFeatureFlags(e), await this.processNotifications(e), await this.processAdapterConfigurations(e), await this.processVersionConfigurations(e);
    } catch (e) {
      throw re.error("[RemoteConfigManager] Failed to process configuration:", e), e;
    }
  }
  async processFeatureFlags(e) {
    try {
      const n = He.getValue("features").value;
      if (n) {
        const o = JSON.parse(n);
        po({ features: o }) && (await this.broadcastFeatureFlags(o), re.debug(`Updated ${Object.keys(o).length} feature flags`));
      }
    } catch (r) {
      re.error("[RemoteConfigManager] Failed to process feature flags:", r);
    }
  }
  async processNotifications(e) {
    try {
      const n = He.getValue("active_notifications").value;
      if (n) {
        const o = JSON.parse(n);
        po({ notifications: o }) && (await this.broadcastNotifications(o), re.debug(`Processed ${o.length} notifications`));
      }
    } catch (r) {
      re.error("[RemoteConfigManager] Failed to process notifications:", r);
    }
  }
  async processAdapterConfigurations(e) {
    try {
      let r = {}, n = !1;
      const s = He.getValue("adapter_configs").value;
      if (s)
        try {
          const a = JSON.parse(s);
          r = { ...a }, n = !0, re.debug(`Found unified adapter_configs with ${Object.keys(a).length} adapters`);
        } catch (a) {
          re.warn("[RemoteConfigManager] Failed to parse unified adapter_configs:", a);
        }
      const i = Object.keys(e).filter((a) => a.endsWith("_adapter_config"));
      if (i.length > 0) {
        re.debug(`Found ${i.length} individual adapter config parameters:`, i);
        for (const a of i)
          try {
            const c = He.getValue(a);
            if (c.value) {
              const u = JSON.parse(c.value), l = a.replace("_adapter_config", "");
              r[l] = u, n = !0, re.debug(`Loaded individual config for adapter: ${l}`);
            }
          } catch (c) {
            re.warn(`Failed to parse ${a}:`, c);
          }
      }
      n && Object.keys(r).length > 0 ? this.validateAdapterConfigs(r) ? (await this.broadcastAdapterConfigs(r), re.debug(`Processed and broadcasted ${Object.keys(r).length} adapter configurations`)) : re.warn("[RemoteConfigManager] Adapter configs validation failed") : re.debug("[RemoteConfigManager] No adapter configurations found");
    } catch (r) {
      re.error("[RemoteConfigManager] Failed to process adapter configurations:", r);
    }
  }
  validateAdapterConfigs(e) {
    if (!e || typeof e != "object")
      return re.warn("[RemoteConfigManager] Invalid adapter configs structure"), !1;
    for (const [r, n] of Object.entries(e)) {
      if (!n || typeof n != "object") {
        re.warn(`Invalid config for adapter: ${r}`);
        continue;
      }
      const o = n;
      if (!o.selectors || !o.ui) {
        re.warn(`Missing required fields for adapter: ${r}`);
        continue;
      }
    }
    return !0;
  }
  async processVersionConfigurations(e) {
    try {
      const n = `version_config_${chrome.runtime.getManifest().version.replace(/\./g, "_")}`, s = He.getValue(n).value;
      if (s) {
        const i = JSON.parse(s);
        po(i) && (await this.broadcastVersionConfig(i), re.debug("[RemoteConfigManager] Applied version-specific configuration"));
      }
    } catch (r) {
      re.error("[RemoteConfigManager] Failed to process version configurations:", r);
    }
  }
  async broadcastFeatureFlags(e) {
    try {
      const r = await chrome.tabs.query({ active: !0 });
      for (const n of r)
        if (n.id)
          try {
            await chrome.tabs.sendMessage(n.id, {
              type: "remote-config:feature-flags-updated",
              data: {
                flags: e,
                timestamp: Date.now()
              }
            });
          } catch {
            re.debug("[RemoteConfigManager] Could not send message to tab:", n.id);
          }
    } catch (r) {
      re.error("[RemoteConfigManager] Failed to broadcast feature flags:", r);
    }
  }
  async broadcastNotifications(e) {
    try {
      const r = await chrome.tabs.query({ active: !0 });
      for (const n of r)
        if (n.id)
          try {
            await chrome.tabs.sendMessage(n.id, {
              type: "remote-config:notifications-received",
              data: {
                notifications: e,
                timestamp: Date.now()
              }
            });
          } catch {
            re.debug("[RemoteConfigManager] Could not send message to tab:", n.id);
          }
    } catch (r) {
      re.error("[RemoteConfigManager] Failed to broadcast notifications:", r);
    }
  }
  async broadcastAdapterConfigs(e) {
    try {
      const r = await chrome.tabs.query({});
      let n = 0;
      for (const o of r)
        if (o.id && o.url && !o.url.startsWith("chrome://") && !o.url.startsWith("chrome-extension://"))
          try {
            await chrome.tabs.sendMessage(o.id, {
              type: "remote-config:adapter-configs-updated",
              data: {
                adapterConfigs: e,
                timestamp: Date.now()
              }
            }), n++;
          } catch (s) {
            re.debug(`Could not send adapter config message to tab ${o.id}:`, s instanceof Error ? s.message : String(s));
          }
      re.debug(`Broadcasted adapter configs to ${n} tabs`);
    } catch (r) {
      re.error("[RemoteConfigManager] Failed to broadcast adapter configurations:", r);
    }
  }
  async broadcastVersionConfig(e) {
    try {
      const r = await chrome.tabs.query({ active: !0 });
      for (const n of r)
        if (n.id)
          try {
            await chrome.tabs.sendMessage(n.id, {
              type: "remote-config:version-config-updated",
              data: {
                config: e,
                timestamp: Date.now()
              }
            });
          } catch {
            re.debug("[RemoteConfigManager] Could not send message to tab:", n.id);
          }
    } catch (r) {
      re.error("[RemoteConfigManager] Failed to broadcast version config:", r);
    }
  }
  //development
  //   private startPeriodicFetch(): void {
  //     // Fetch every 5 sec
  //     this.fetchInterval = setInterval(() => {
  //       this.fetchConfig(true);
  //     }, 5000);
  //     logger.debug('[RemoteConfigManager] Started periodic config fetching');
  //   }
  startPeriodicFetch() {
    this.fetchInterval = setInterval(() => {
      this.fetchConfig(!1);
    }, 12 * 60 * 60 * 1e3), re.debug("[RemoteConfigManager] Started periodic config fetching");
  }
  stopPeriodicFetch() {
    this.fetchInterval && (clearInterval(this.fetchInterval), this.fetchInterval = null, re.debug("[RemoteConfigManager] Stopped periodic config fetching"));
  }
  async setLastFetchTime(e) {
    await chrome.storage.local.set({ remoteConfigLastFetch: e });
  }
  async getLastFetchTime() {
    const e = await chrome.storage.local.get(["remoteConfigLastFetch"]);
    return (e == null ? void 0 : e.remoteConfigLastFetch) || null;
  }
  async getFeatureFlag(e) {
    try {
      const n = He.getValue("features").value;
      return n && JSON.parse(n)[e] || null;
    } catch (r) {
      return re.error("[RemoteConfigManager] Failed to get feature flag:", r), null;
    }
  }
  async getAllConfig() {
    try {
      return He.getAll();
    } catch (e) {
      return re.error("[RemoteConfigManager] Failed to get all config:", e), {};
    }
  }
  async getSpecificConfig(e) {
    try {
      const r = He.getAll();
      if (e.includes("adapter_config")) {
        const o = He.getValue("adapter_configs").value;
        if (o) {
          const i = JSON.parse(o);
          if (e.endsWith("_adapter_config")) {
            const a = e.replace("_adapter_config", "");
            return { [e]: i[a] || null };
          }
        }
        const s = He.getValue(e);
        if (s.value)
          try {
            return { [e]: JSON.parse(s.value) };
          } catch {
            return { [e]: s.value };
          }
        return { [e]: null };
      }
      if (r[e]) {
        const n = r[e];
        try {
          return { [e]: JSON.parse(n.value) };
        } catch {
          return { [e]: n.value };
        }
      }
      return { [e]: null };
    } catch (r) {
      return re.error(`Failed to get specific config for key ${e}:`, r), { [e]: null };
    }
  }
  async cleanup() {
    this.stopPeriodicFetch(), this.isInitialized = !1, this.lastFetchTime = null, this.retryCount = 0, re.debug("[RemoteConfigManager] Cleaned up");
  }
  get initialized() {
    return this.isInitialized;
  }
  async getLastFetchTimePublic() {
    return this.getLastFetchTime();
  }
  /**
   * Clear cache and force refresh - useful for handling deleted Firebase keys
   */
  async clearCacheAndRefresh() {
    try {
      re.debug("[RemoteConfigManager] Clearing cache and forcing refresh...");
      const e = await He.clearCacheAndRefetch();
      return e && (await this.processConfiguration(), re.debug("[RemoteConfigManager] Cache cleared and config refreshed successfully")), e;
    } catch (e) {
      return re.error("[RemoteConfigManager] Failed to clear cache and refresh:", e), !1;
    }
  }
}
var ni;
const cl = /* @__PURE__ */ Object.freeze({
  status: "aborted"
});
function q(t, e, r) {
  function n(a, c) {
    if (a._zod || Object.defineProperty(a, "_zod", {
      value: {
        def: c,
        constr: i,
        traits: /* @__PURE__ */ new Set()
      },
      enumerable: !1
    }), a._zod.traits.has(t))
      return;
    a._zod.traits.add(t), e(a, c);
    const u = i.prototype, l = Object.keys(u);
    for (let h = 0; h < l.length; h++) {
      const m = l[h];
      m in a || (a[m] = u[m].bind(a));
    }
  }
  const o = (r == null ? void 0 : r.Parent) ?? Object;
  class s extends o {
  }
  Object.defineProperty(s, "name", { value: t });
  function i(a) {
    var c;
    const u = r != null && r.Parent ? new s() : this;
    n(u, a), (c = u._zod).deferred ?? (c.deferred = []);
    for (const l of u._zod.deferred)
      l();
    return u;
  }
  return Object.defineProperty(i, "init", { value: n }), Object.defineProperty(i, Symbol.hasInstance, {
    value: (a) => {
      var c, u;
      return r != null && r.Parent && a instanceof r.Parent ? !0 : (u = (c = a == null ? void 0 : a._zod) == null ? void 0 : c.traits) == null ? void 0 : u.has(t);
    }
  }), Object.defineProperty(i, "name", { value: t }), i;
}
class ir extends Error {
  constructor() {
    super("Encountered Promise during synchronous parse. Use .parseAsync() instead.");
  }
}
class ic extends Error {
  constructor(e) {
    super(`Encountered unidirectional transform during encode: ${e}`), this.name = "ZodEncodeError";
  }
}
(ni = globalThis).__zod_globalConfig ?? (ni.__zod_globalConfig = {});
const ps = globalThis.__zod_globalConfig;
function kt(t) {
  return ps;
}
function ac(t) {
  const e = Object.values(t).filter((n) => typeof n == "number");
  return Object.entries(t).filter(([n, o]) => e.indexOf(+n) === -1).map(([n, o]) => o);
}
function qo(t, e) {
  return typeof e == "bigint" ? e.toString() : e;
}
function Jn(t) {
  return {
    get value() {
      {
        const e = t();
        return Object.defineProperty(this, "value", { value: e }), e;
      }
    }
  };
}
function ms(t) {
  return t == null;
}
function gs(t) {
  const e = t.startsWith("^") ? 1 : 0, r = t.endsWith("$") ? t.length - 1 : t.length;
  return t.slice(e, r);
}
function ul(t, e) {
  const r = t / e, n = Math.round(r), o = Number.EPSILON * Math.max(Math.abs(r), 1);
  return Math.abs(r - n) < o ? 0 : r - n;
}
const oi = /* @__PURE__ */ Symbol("evaluating");
function ge(t, e, r) {
  let n;
  Object.defineProperty(t, e, {
    get() {
      if (n !== oi)
        return n === void 0 && (n = oi, n = r()), n;
    },
    set(o) {
      Object.defineProperty(t, e, {
        value: o
        // configurable: true,
      });
    },
    configurable: !0
  });
}
function Gt(t, e, r) {
  Object.defineProperty(t, e, {
    value: r,
    writable: !0,
    enumerable: !0,
    configurable: !0
  });
}
function It(...t) {
  const e = {};
  for (const r of t) {
    const n = Object.getOwnPropertyDescriptors(r);
    Object.assign(e, n);
  }
  return Object.defineProperties({}, e);
}
function si(t) {
  return JSON.stringify(t);
}
function ll(t) {
  return t.toLowerCase().trim().replace(/[^\w\s-]/g, "").replace(/[\s_-]+/g, "-").replace(/^-+|-+$/g, "");
}
const cc = "captureStackTrace" in Error ? Error.captureStackTrace : (...t) => {
};
function Pr(t) {
  return typeof t == "object" && t !== null && !Array.isArray(t);
}
const dl = /* @__PURE__ */ Jn(() => {
  var t;
  if (ps.jitless || typeof navigator < "u" && ((t = navigator == null ? void 0 : navigator.userAgent) != null && t.includes("Cloudflare")))
    return !1;
  try {
    const e = Function;
    return new e(""), !0;
  } catch {
    return !1;
  }
});
function lr(t) {
  if (Pr(t) === !1)
    return !1;
  const e = t.constructor;
  if (e === void 0 || typeof e != "function")
    return !0;
  const r = e.prototype;
  return !(Pr(r) === !1 || Object.prototype.hasOwnProperty.call(r, "isPrototypeOf") === !1);
}
function uc(t) {
  return lr(t) ? { ...t } : Array.isArray(t) ? [...t] : t instanceof Map ? new Map(t) : t instanceof Set ? new Set(t) : t;
}
const fl = /* @__PURE__ */ new Set(["string", "number", "symbol"]);
function dr(t) {
  return t.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}
function Ot(t, e, r) {
  const n = new t._zod.constr(e ?? t._zod.def);
  return (!e || r != null && r.parent) && (n._zod.parent = t), n;
}
function K(t) {
  const e = t;
  if (!e)
    return {};
  if (typeof e == "string")
    return { error: () => e };
  if ((e == null ? void 0 : e.message) !== void 0) {
    if ((e == null ? void 0 : e.error) !== void 0)
      throw new Error("Cannot specify both `message` and `error` params");
    e.error = e.message;
  }
  return delete e.message, typeof e.error == "string" ? { ...e, error: () => e.error } : e;
}
function hl(t) {
  return Object.keys(t).filter((e) => t[e]._zod.optin === "optional" && t[e]._zod.optout === "optional");
}
const pl = {
  safeint: [Number.MIN_SAFE_INTEGER, Number.MAX_SAFE_INTEGER],
  int32: [-2147483648, 2147483647],
  uint32: [0, 4294967295],
  float32: [-34028234663852886e22, 34028234663852886e22],
  float64: [-Number.MAX_VALUE, Number.MAX_VALUE]
};
function ml(t, e) {
  const r = t._zod.def, n = r.checks;
  if (n && n.length > 0)
    throw new Error(".pick() cannot be used on object schemas containing refinements");
  const s = It(t._zod.def, {
    get shape() {
      const i = {};
      for (const a in e) {
        if (!(a in r.shape))
          throw new Error(`Unrecognized key: "${a}"`);
        e[a] && (i[a] = r.shape[a]);
      }
      return Gt(this, "shape", i), i;
    },
    checks: []
  });
  return Ot(t, s);
}
function gl(t, e) {
  const r = t._zod.def, n = r.checks;
  if (n && n.length > 0)
    throw new Error(".omit() cannot be used on object schemas containing refinements");
  const s = It(t._zod.def, {
    get shape() {
      const i = { ...t._zod.def.shape };
      for (const a in e) {
        if (!(a in r.shape))
          throw new Error(`Unrecognized key: "${a}"`);
        e[a] && delete i[a];
      }
      return Gt(this, "shape", i), i;
    },
    checks: []
  });
  return Ot(t, s);
}
function _l(t, e) {
  if (!lr(e))
    throw new Error("Invalid input to extend: expected a plain object");
  const r = t._zod.def.checks;
  if (r && r.length > 0) {
    const s = t._zod.def.shape;
    for (const i in e)
      if (Object.getOwnPropertyDescriptor(s, i) !== void 0)
        throw new Error("Cannot overwrite keys on object schemas containing refinements. Use `.safeExtend()` instead.");
  }
  const o = It(t._zod.def, {
    get shape() {
      const s = { ...t._zod.def.shape, ...e };
      return Gt(this, "shape", s), s;
    }
  });
  return Ot(t, o);
}
function yl(t, e) {
  if (!lr(e))
    throw new Error("Invalid input to safeExtend: expected a plain object");
  const r = It(t._zod.def, {
    get shape() {
      const n = { ...t._zod.def.shape, ...e };
      return Gt(this, "shape", n), n;
    }
  });
  return Ot(t, r);
}
function vl(t, e) {
  var n;
  if ((n = t._zod.def.checks) != null && n.length)
    throw new Error(".merge() cannot be used on object schemas containing refinements. Use .safeExtend() instead.");
  const r = It(t._zod.def, {
    get shape() {
      const o = { ...t._zod.def.shape, ...e._zod.def.shape };
      return Gt(this, "shape", o), o;
    },
    get catchall() {
      return e._zod.def.catchall;
    },
    checks: e._zod.def.checks ?? []
  });
  return Ot(t, r);
}
function wl(t, e, r) {
  const o = e._zod.def.checks;
  if (o && o.length > 0)
    throw new Error(".partial() cannot be used on object schemas containing refinements");
  const i = It(e._zod.def, {
    get shape() {
      const a = e._zod.def.shape, c = { ...a };
      if (r)
        for (const u in r) {
          if (!(u in a))
            throw new Error(`Unrecognized key: "${u}"`);
          r[u] && (c[u] = t ? new t({
            type: "optional",
            innerType: a[u]
          }) : a[u]);
        }
      else
        for (const u in a)
          c[u] = t ? new t({
            type: "optional",
            innerType: a[u]
          }) : a[u];
      return Gt(this, "shape", c), c;
    },
    checks: []
  });
  return Ot(e, i);
}
function bl(t, e, r) {
  const n = It(e._zod.def, {
    get shape() {
      const o = e._zod.def.shape, s = { ...o };
      if (r)
        for (const i in r) {
          if (!(i in s))
            throw new Error(`Unrecognized key: "${i}"`);
          r[i] && (s[i] = new t({
            type: "nonoptional",
            innerType: o[i]
          }));
        }
      else
        for (const i in o)
          s[i] = new t({
            type: "nonoptional",
            innerType: o[i]
          });
      return Gt(this, "shape", s), s;
    }
  });
  return Ot(e, n);
}
function rr(t, e = 0) {
  var r;
  if (t.aborted === !0)
    return !0;
  for (let n = e; n < t.issues.length; n++)
    if (((r = t.issues[n]) == null ? void 0 : r.continue) !== !0)
      return !0;
  return !1;
}
function $l(t, e = 0) {
  var r;
  if (t.aborted === !0)
    return !0;
  for (let n = e; n < t.issues.length; n++)
    if (((r = t.issues[n]) == null ? void 0 : r.continue) === !1)
      return !0;
  return !1;
}
function nr(t, e) {
  return e.map((r) => {
    var n;
    return (n = r).path ?? (n.path = []), r.path.unshift(t), r;
  });
}
function Ur(t) {
  return typeof t == "string" ? t : t == null ? void 0 : t.message;
}
function Ct(t, e, r) {
  var c, u, l, h, m, _;
  const n = t.message ? t.message : Ur((l = (u = (c = t.inst) == null ? void 0 : c._zod.def) == null ? void 0 : u.error) == null ? void 0 : l.call(u, t)) ?? Ur((h = e == null ? void 0 : e.error) == null ? void 0 : h.call(e, t)) ?? Ur((m = r.customError) == null ? void 0 : m.call(r, t)) ?? Ur((_ = r.localeError) == null ? void 0 : _.call(r, t)) ?? "Invalid input", { inst: o, continue: s, input: i, ...a } = t;
  return a.path ?? (a.path = []), a.message = n, e != null && e.reportInput && (a.input = i), a;
}
function _s(t) {
  return Array.isArray(t) ? "array" : typeof t == "string" ? "string" : "unknown";
}
function Ar(...t) {
  const [e, r, n] = t;
  return typeof e == "string" ? {
    message: e,
    code: "custom",
    input: r,
    inst: n
  } : { ...e };
}
const lc = (t, e) => {
  t.name = "$ZodError", Object.defineProperty(t, "_zod", {
    value: t._zod,
    enumerable: !1
  }), Object.defineProperty(t, "issues", {
    value: e,
    enumerable: !1
  }), t.message = JSON.stringify(e, qo, 2), Object.defineProperty(t, "toString", {
    value: () => t.message,
    enumerable: !1
  });
}, dc = q("$ZodError", lc), fc = q("$ZodError", lc, { Parent: Error });
function Sl(t, e = (r) => r.message) {
  const r = {}, n = [];
  for (const o of t.issues)
    o.path.length > 0 ? (r[o.path[0]] = r[o.path[0]] || [], r[o.path[0]].push(e(o))) : n.push(e(o));
  return { formErrors: n, fieldErrors: r };
}
function El(t, e = (r) => r.message) {
  const r = { _errors: [] }, n = (o, s = []) => {
    for (const i of o.issues)
      if (i.code === "invalid_union" && i.errors.length)
        i.errors.map((a) => n({ issues: a }, [...s, ...i.path]));
      else if (i.code === "invalid_key")
        n({ issues: i.issues }, [...s, ...i.path]);
      else if (i.code === "invalid_element")
        n({ issues: i.issues }, [...s, ...i.path]);
      else {
        const a = [...s, ...i.path];
        if (a.length === 0)
          r._errors.push(e(i));
        else {
          let c = r, u = 0;
          for (; u < a.length; ) {
            const l = a[u];
            u === a.length - 1 ? (c[l] = c[l] || { _errors: [] }, c[l]._errors.push(e(i))) : c[l] = c[l] || { _errors: [] }, c = c[l], u++;
          }
        }
      }
  };
  return n(t), r;
}
const ys = (t) => (e, r, n, o) => {
  const s = n ? { ...n, async: !1 } : { async: !1 }, i = e._zod.run({ value: r, issues: [] }, s);
  if (i instanceof Promise)
    throw new ir();
  if (i.issues.length) {
    const a = new ((o == null ? void 0 : o.Err) ?? t)(i.issues.map((c) => Ct(c, s, kt())));
    throw cc(a, o == null ? void 0 : o.callee), a;
  }
  return i.value;
}, vs = (t) => async (e, r, n, o) => {
  const s = n ? { ...n, async: !0 } : { async: !0 };
  let i = e._zod.run({ value: r, issues: [] }, s);
  if (i instanceof Promise && (i = await i), i.issues.length) {
    const a = new ((o == null ? void 0 : o.Err) ?? t)(i.issues.map((c) => Ct(c, s, kt())));
    throw cc(a, o == null ? void 0 : o.callee), a;
  }
  return i.value;
}, Qn = (t) => (e, r, n) => {
  const o = n ? { ...n, async: !1 } : { async: !1 }, s = e._zod.run({ value: r, issues: [] }, o);
  if (s instanceof Promise)
    throw new ir();
  return s.issues.length ? {
    success: !1,
    error: new (t ?? dc)(s.issues.map((i) => Ct(i, o, kt())))
  } : { success: !0, data: s.value };
}, hc = /* @__PURE__ */ Qn(fc), Xn = (t) => async (e, r, n) => {
  const o = n ? { ...n, async: !0 } : { async: !0 };
  let s = e._zod.run({ value: r, issues: [] }, o);
  return s instanceof Promise && (s = await s), s.issues.length ? {
    success: !1,
    error: new t(s.issues.map((i) => Ct(i, o, kt())))
  } : { success: !0, data: s.value };
}, kl = /* @__PURE__ */ Xn(fc), Cl = (t) => (e, r, n) => {
  const o = n ? { ...n, direction: "backward" } : { direction: "backward" };
  return ys(t)(e, r, o);
}, Tl = (t) => (e, r, n) => ys(t)(e, r, n), Pl = (t) => async (e, r, n) => {
  const o = n ? { ...n, direction: "backward" } : { direction: "backward" };
  return vs(t)(e, r, o);
}, Al = (t) => async (e, r, n) => vs(t)(e, r, n), Rl = (t) => (e, r, n) => {
  const o = n ? { ...n, direction: "backward" } : { direction: "backward" };
  return Qn(t)(e, r, o);
}, Il = (t) => (e, r, n) => Qn(t)(e, r, n), Ol = (t) => async (e, r, n) => {
  const o = n ? { ...n, direction: "backward" } : { direction: "backward" };
  return Xn(t)(e, r, o);
}, zl = (t) => async (e, r, n) => Xn(t)(e, r, n), Nl = /^[cC][0-9a-z]{6,}$/, Ml = /^[0-9a-z]+$/, jl = /^[0-9A-HJKMNP-TV-Za-hjkmnp-tv-z]{26}$/, xl = /^[0-9a-vA-V]{20}$/, ql = /^[A-Za-z0-9]{27}$/, Dl = /^[a-zA-Z0-9_-]{21}$/, Ul = /^P(?:(\d+W)|(?!.*W)(?=\d|T\d)(\d+Y)?(\d+M)?(\d+D)?(T(?=\d)(\d+H)?(\d+M)?(\d+([.,]\d+)?S)?)?)$/, Fl = /^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12})$/, ii = (t) => t ? new RegExp(`^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-${t}[0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12})$`) : /^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[1-8][0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12}|00000000-0000-0000-0000-000000000000|ffffffff-ffff-ffff-ffff-ffffffffffff)$/, Ll = /^(?!\.)(?!.*\.\.)([A-Za-z0-9_'+\-\.]*)[A-Za-z0-9_+-]@([A-Za-z0-9][A-Za-z0-9\-]*\.)+[A-Za-z]{2,}$/, Zl = "^(\\p{Extended_Pictographic}|\\p{Emoji_Component})+$";
function Vl() {
  return new RegExp(Zl, "u");
}
const Hl = /^(?:(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])$/, Wl = /^(([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:))$/, Bl = /^((25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\/([0-9]|[1-2][0-9]|3[0-2])$/, Gl = /^(([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|::|([0-9a-fA-F]{1,4})?::([0-9a-fA-F]{1,4}:?){0,6})\/(12[0-8]|1[01][0-9]|[1-9]?[0-9])$/, Kl = /^$|^(?:[0-9a-zA-Z+/]{4})*(?:(?:[0-9a-zA-Z+/]{2}==)|(?:[0-9a-zA-Z+/]{3}=))?$/, pc = /^[A-Za-z0-9_-]*$/, Jl = /^https?$/, Ql = /^\+[1-9]\d{6,14}$/, mc = "(?:(?:\\d\\d[2468][048]|\\d\\d[13579][26]|\\d\\d0[48]|[02468][048]00|[13579][26]00)-02-29|\\d{4}-(?:(?:0[13578]|1[02])-(?:0[1-9]|[12]\\d|3[01])|(?:0[469]|11)-(?:0[1-9]|[12]\\d|30)|(?:02)-(?:0[1-9]|1\\d|2[0-8])))", Xl = /* @__PURE__ */ new RegExp(`^${mc}$`);
function gc(t) {
  const e = "(?:[01]\\d|2[0-3]):[0-5]\\d";
  return typeof t.precision == "number" ? t.precision === -1 ? `${e}` : t.precision === 0 ? `${e}:[0-5]\\d` : `${e}:[0-5]\\d\\.\\d{${t.precision}}` : `${e}(?::[0-5]\\d(?:\\.\\d+)?)?`;
}
function Yl(t) {
  return new RegExp(`^${gc(t)}$`);
}
function ed(t) {
  const e = gc({ precision: t.precision }), r = ["Z"];
  t.local && r.push(""), t.offset && r.push("([+-](?:[01]\\d|2[0-3]):[0-5]\\d)");
  const n = `${e}(?:${r.join("|")})`;
  return new RegExp(`^${mc}T(?:${n})$`);
}
const td = (t) => {
  const e = t ? `[\\s\\S]{${(t == null ? void 0 : t.minimum) ?? 0},${(t == null ? void 0 : t.maximum) ?? ""}}` : "[\\s\\S]*";
  return new RegExp(`^${e}$`);
}, rd = /^-?\d+$/, _c = /^-?\d+(?:\.\d+)?$/, nd = /^(?:true|false)$/i, od = /^null$/i, sd = /^[^A-Z]*$/, id = /^[^a-z]*$/, tt = /* @__PURE__ */ q("$ZodCheck", (t, e) => {
  var r;
  t._zod ?? (t._zod = {}), t._zod.def = e, (r = t._zod).onattach ?? (r.onattach = []);
}), yc = {
  number: "number",
  bigint: "bigint",
  object: "date"
}, vc = /* @__PURE__ */ q("$ZodCheckLessThan", (t, e) => {
  tt.init(t, e);
  const r = yc[typeof e.value];
  t._zod.onattach.push((n) => {
    const o = n._zod.bag, s = (e.inclusive ? o.maximum : o.exclusiveMaximum) ?? Number.POSITIVE_INFINITY;
    e.value < s && (e.inclusive ? o.maximum = e.value : o.exclusiveMaximum = e.value);
  }), t._zod.check = (n) => {
    (e.inclusive ? n.value <= e.value : n.value < e.value) || n.issues.push({
      origin: r,
      code: "too_big",
      maximum: typeof e.value == "object" ? e.value.getTime() : e.value,
      input: n.value,
      inclusive: e.inclusive,
      inst: t,
      continue: !e.abort
    });
  };
}), wc = /* @__PURE__ */ q("$ZodCheckGreaterThan", (t, e) => {
  tt.init(t, e);
  const r = yc[typeof e.value];
  t._zod.onattach.push((n) => {
    const o = n._zod.bag, s = (e.inclusive ? o.minimum : o.exclusiveMinimum) ?? Number.NEGATIVE_INFINITY;
    e.value > s && (e.inclusive ? o.minimum = e.value : o.exclusiveMinimum = e.value);
  }), t._zod.check = (n) => {
    (e.inclusive ? n.value >= e.value : n.value > e.value) || n.issues.push({
      origin: r,
      code: "too_small",
      minimum: typeof e.value == "object" ? e.value.getTime() : e.value,
      input: n.value,
      inclusive: e.inclusive,
      inst: t,
      continue: !e.abort
    });
  };
}), ad = /* @__PURE__ */ q("$ZodCheckMultipleOf", (t, e) => {
  tt.init(t, e), t._zod.onattach.push((r) => {
    var n;
    (n = r._zod.bag).multipleOf ?? (n.multipleOf = e.value);
  }), t._zod.check = (r) => {
    if (typeof r.value != typeof e.value)
      throw new Error("Cannot mix number and bigint in multiple_of check.");
    (typeof r.value == "bigint" ? r.value % e.value === BigInt(0) : ul(r.value, e.value) === 0) || r.issues.push({
      origin: typeof r.value,
      code: "not_multiple_of",
      divisor: e.value,
      input: r.value,
      inst: t,
      continue: !e.abort
    });
  };
}), cd = /* @__PURE__ */ q("$ZodCheckNumberFormat", (t, e) => {
  var i;
  tt.init(t, e), e.format = e.format || "float64";
  const r = (i = e.format) == null ? void 0 : i.includes("int"), n = r ? "int" : "number", [o, s] = pl[e.format];
  t._zod.onattach.push((a) => {
    const c = a._zod.bag;
    c.format = e.format, c.minimum = o, c.maximum = s, r && (c.pattern = rd);
  }), t._zod.check = (a) => {
    const c = a.value;
    if (r) {
      if (!Number.isInteger(c)) {
        a.issues.push({
          expected: n,
          format: e.format,
          code: "invalid_type",
          continue: !1,
          input: c,
          inst: t
        });
        return;
      }
      if (!Number.isSafeInteger(c)) {
        c > 0 ? a.issues.push({
          input: c,
          code: "too_big",
          maximum: Number.MAX_SAFE_INTEGER,
          note: "Integers must be within the safe integer range.",
          inst: t,
          origin: n,
          inclusive: !0,
          continue: !e.abort
        }) : a.issues.push({
          input: c,
          code: "too_small",
          minimum: Number.MIN_SAFE_INTEGER,
          note: "Integers must be within the safe integer range.",
          inst: t,
          origin: n,
          inclusive: !0,
          continue: !e.abort
        });
        return;
      }
    }
    c < o && a.issues.push({
      origin: "number",
      input: c,
      code: "too_small",
      minimum: o,
      inclusive: !0,
      inst: t,
      continue: !e.abort
    }), c > s && a.issues.push({
      origin: "number",
      input: c,
      code: "too_big",
      maximum: s,
      inclusive: !0,
      inst: t,
      continue: !e.abort
    });
  };
}), ud = /* @__PURE__ */ q("$ZodCheckMaxLength", (t, e) => {
  var r;
  tt.init(t, e), (r = t._zod.def).when ?? (r.when = (n) => {
    const o = n.value;
    return !ms(o) && o.length !== void 0;
  }), t._zod.onattach.push((n) => {
    const o = n._zod.bag.maximum ?? Number.POSITIVE_INFINITY;
    e.maximum < o && (n._zod.bag.maximum = e.maximum);
  }), t._zod.check = (n) => {
    const o = n.value;
    if (o.length <= e.maximum)
      return;
    const i = _s(o);
    n.issues.push({
      origin: i,
      code: "too_big",
      maximum: e.maximum,
      inclusive: !0,
      input: o,
      inst: t,
      continue: !e.abort
    });
  };
}), ld = /* @__PURE__ */ q("$ZodCheckMinLength", (t, e) => {
  var r;
  tt.init(t, e), (r = t._zod.def).when ?? (r.when = (n) => {
    const o = n.value;
    return !ms(o) && o.length !== void 0;
  }), t._zod.onattach.push((n) => {
    const o = n._zod.bag.minimum ?? Number.NEGATIVE_INFINITY;
    e.minimum > o && (n._zod.bag.minimum = e.minimum);
  }), t._zod.check = (n) => {
    const o = n.value;
    if (o.length >= e.minimum)
      return;
    const i = _s(o);
    n.issues.push({
      origin: i,
      code: "too_small",
      minimum: e.minimum,
      inclusive: !0,
      input: o,
      inst: t,
      continue: !e.abort
    });
  };
}), dd = /* @__PURE__ */ q("$ZodCheckLengthEquals", (t, e) => {
  var r;
  tt.init(t, e), (r = t._zod.def).when ?? (r.when = (n) => {
    const o = n.value;
    return !ms(o) && o.length !== void 0;
  }), t._zod.onattach.push((n) => {
    const o = n._zod.bag;
    o.minimum = e.length, o.maximum = e.length, o.length = e.length;
  }), t._zod.check = (n) => {
    const o = n.value, s = o.length;
    if (s === e.length)
      return;
    const i = _s(o), a = s > e.length;
    n.issues.push({
      origin: i,
      ...a ? { code: "too_big", maximum: e.length } : { code: "too_small", minimum: e.length },
      inclusive: !0,
      exact: !0,
      input: n.value,
      inst: t,
      continue: !e.abort
    });
  };
}), Yn = /* @__PURE__ */ q("$ZodCheckStringFormat", (t, e) => {
  var r, n;
  tt.init(t, e), t._zod.onattach.push((o) => {
    const s = o._zod.bag;
    s.format = e.format, e.pattern && (s.patterns ?? (s.patterns = /* @__PURE__ */ new Set()), s.patterns.add(e.pattern));
  }), e.pattern ? (r = t._zod).check ?? (r.check = (o) => {
    e.pattern.lastIndex = 0, !e.pattern.test(o.value) && o.issues.push({
      origin: "string",
      code: "invalid_format",
      format: e.format,
      input: o.value,
      ...e.pattern ? { pattern: e.pattern.toString() } : {},
      inst: t,
      continue: !e.abort
    });
  }) : (n = t._zod).check ?? (n.check = () => {
  });
}), fd = /* @__PURE__ */ q("$ZodCheckRegex", (t, e) => {
  Yn.init(t, e), t._zod.check = (r) => {
    e.pattern.lastIndex = 0, !e.pattern.test(r.value) && r.issues.push({
      origin: "string",
      code: "invalid_format",
      format: "regex",
      input: r.value,
      pattern: e.pattern.toString(),
      inst: t,
      continue: !e.abort
    });
  };
}), hd = /* @__PURE__ */ q("$ZodCheckLowerCase", (t, e) => {
  e.pattern ?? (e.pattern = sd), Yn.init(t, e);
}), pd = /* @__PURE__ */ q("$ZodCheckUpperCase", (t, e) => {
  e.pattern ?? (e.pattern = id), Yn.init(t, e);
}), md = /* @__PURE__ */ q("$ZodCheckIncludes", (t, e) => {
  tt.init(t, e);
  const r = dr(e.includes), n = new RegExp(typeof e.position == "number" ? `^.{${e.position}}${r}` : r);
  e.pattern = n, t._zod.onattach.push((o) => {
    const s = o._zod.bag;
    s.patterns ?? (s.patterns = /* @__PURE__ */ new Set()), s.patterns.add(n);
  }), t._zod.check = (o) => {
    o.value.includes(e.includes, e.position) || o.issues.push({
      origin: "string",
      code: "invalid_format",
      format: "includes",
      includes: e.includes,
      input: o.value,
      inst: t,
      continue: !e.abort
    });
  };
}), gd = /* @__PURE__ */ q("$ZodCheckStartsWith", (t, e) => {
  tt.init(t, e);
  const r = new RegExp(`^${dr(e.prefix)}.*`);
  e.pattern ?? (e.pattern = r), t._zod.onattach.push((n) => {
    const o = n._zod.bag;
    o.patterns ?? (o.patterns = /* @__PURE__ */ new Set()), o.patterns.add(r);
  }), t._zod.check = (n) => {
    n.value.startsWith(e.prefix) || n.issues.push({
      origin: "string",
      code: "invalid_format",
      format: "starts_with",
      prefix: e.prefix,
      input: n.value,
      inst: t,
      continue: !e.abort
    });
  };
}), _d = /* @__PURE__ */ q("$ZodCheckEndsWith", (t, e) => {
  tt.init(t, e);
  const r = new RegExp(`.*${dr(e.suffix)}$`);
  e.pattern ?? (e.pattern = r), t._zod.onattach.push((n) => {
    const o = n._zod.bag;
    o.patterns ?? (o.patterns = /* @__PURE__ */ new Set()), o.patterns.add(r);
  }), t._zod.check = (n) => {
    n.value.endsWith(e.suffix) || n.issues.push({
      origin: "string",
      code: "invalid_format",
      format: "ends_with",
      suffix: e.suffix,
      input: n.value,
      inst: t,
      continue: !e.abort
    });
  };
}), yd = /* @__PURE__ */ q("$ZodCheckOverwrite", (t, e) => {
  tt.init(t, e), t._zod.check = (r) => {
    r.value = e.tx(r.value);
  };
});
class vd {
  constructor(e = []) {
    this.content = [], this.indent = 0, this && (this.args = e);
  }
  indented(e) {
    this.indent += 1, e(this), this.indent -= 1;
  }
  write(e) {
    if (typeof e == "function") {
      e(this, { execution: "sync" }), e(this, { execution: "async" });
      return;
    }
    const n = e.split(`
`).filter((i) => i), o = Math.min(...n.map((i) => i.length - i.trimStart().length)), s = n.map((i) => i.slice(o)).map((i) => " ".repeat(this.indent * 2) + i);
    for (const i of s)
      this.content.push(i);
  }
  compile() {
    const e = Function, r = this == null ? void 0 : this.args, o = [...((this == null ? void 0 : this.content) ?? [""]).map((s) => `  ${s}`)];
    return new e(...r, o.join(`
`));
  }
}
const wd = {
  major: 4,
  minor: 4,
  patch: 3
}, ve = /* @__PURE__ */ q("$ZodType", (t, e) => {
  var o;
  var r;
  t ?? (t = {}), t._zod.def = e, t._zod.bag = t._zod.bag || {}, t._zod.version = wd;
  const n = [...t._zod.def.checks ?? []];
  t._zod.traits.has("$ZodCheck") && n.unshift(t);
  for (const s of n)
    for (const i of s._zod.onattach)
      i(t);
  if (n.length === 0)
    (r = t._zod).deferred ?? (r.deferred = []), (o = t._zod.deferred) == null || o.push(() => {
      t._zod.run = t._zod.parse;
    });
  else {
    const s = (a, c, u) => {
      let l = rr(a), h;
      for (const m of c) {
        if (m._zod.def.when) {
          if ($l(a) || !m._zod.def.when(a))
            continue;
        } else if (l)
          continue;
        const _ = a.issues.length, S = m._zod.check(a);
        if (S instanceof Promise && (u == null ? void 0 : u.async) === !1)
          throw new ir();
        if (h || S instanceof Promise)
          h = (h ?? Promise.resolve()).then(async () => {
            await S, a.issues.length !== _ && (l || (l = rr(a, _)));
          });
        else {
          if (a.issues.length === _)
            continue;
          l || (l = rr(a, _));
        }
      }
      return h ? h.then(() => a) : a;
    }, i = (a, c, u) => {
      if (rr(a))
        return a.aborted = !0, a;
      const l = s(c, n, u);
      if (l instanceof Promise) {
        if (u.async === !1)
          throw new ir();
        return l.then((h) => t._zod.parse(h, u));
      }
      return t._zod.parse(l, u);
    };
    t._zod.run = (a, c) => {
      if (c.skipChecks)
        return t._zod.parse(a, c);
      if (c.direction === "backward") {
        const l = t._zod.parse({ value: a.value, issues: [] }, { ...c, skipChecks: !0 });
        return l instanceof Promise ? l.then((h) => i(h, a, c)) : i(l, a, c);
      }
      const u = t._zod.parse(a, c);
      if (u instanceof Promise) {
        if (c.async === !1)
          throw new ir();
        return u.then((l) => s(l, n, c));
      }
      return s(u, n, c);
    };
  }
  ge(t, "~standard", () => ({
    validate: (s) => {
      var i;
      try {
        const a = hc(t, s);
        return a.success ? { value: a.data } : { issues: (i = a.error) == null ? void 0 : i.issues };
      } catch {
        return kl(t, s).then((c) => {
          var u;
          return c.success ? { value: c.data } : { issues: (u = c.error) == null ? void 0 : u.issues };
        });
      }
    },
    vendor: "zod",
    version: 1
  }));
}), ws = /* @__PURE__ */ q("$ZodString", (t, e) => {
  var r;
  ve.init(t, e), t._zod.pattern = [...((r = t == null ? void 0 : t._zod.bag) == null ? void 0 : r.patterns) ?? []].pop() ?? td(t._zod.bag), t._zod.parse = (n, o) => {
    if (e.coerce)
      try {
        n.value = String(n.value);
      } catch {
      }
    return typeof n.value == "string" || n.issues.push({
      expected: "string",
      code: "invalid_type",
      input: n.value,
      inst: t
    }), n;
  };
}), $e = /* @__PURE__ */ q("$ZodStringFormat", (t, e) => {
  Yn.init(t, e), ws.init(t, e);
}), bd = /* @__PURE__ */ q("$ZodGUID", (t, e) => {
  e.pattern ?? (e.pattern = Fl), $e.init(t, e);
}), $d = /* @__PURE__ */ q("$ZodUUID", (t, e) => {
  if (e.version) {
    const n = {
      v1: 1,
      v2: 2,
      v3: 3,
      v4: 4,
      v5: 5,
      v6: 6,
      v7: 7,
      v8: 8
    }[e.version];
    if (n === void 0)
      throw new Error(`Invalid UUID version: "${e.version}"`);
    e.pattern ?? (e.pattern = ii(n));
  } else
    e.pattern ?? (e.pattern = ii());
  $e.init(t, e);
}), Sd = /* @__PURE__ */ q("$ZodEmail", (t, e) => {
  e.pattern ?? (e.pattern = Ll), $e.init(t, e);
}), Ed = /* @__PURE__ */ q("$ZodURL", (t, e) => {
  $e.init(t, e), t._zod.check = (r) => {
    var n;
    try {
      const o = r.value.trim();
      if (!e.normalize && ((n = e.protocol) == null ? void 0 : n.source) === Jl.source && !/^https?:\/\//i.test(o)) {
        r.issues.push({
          code: "invalid_format",
          format: "url",
          note: "Invalid URL format",
          input: r.value,
          inst: t,
          continue: !e.abort
        });
        return;
      }
      const s = new URL(o);
      e.hostname && (e.hostname.lastIndex = 0, e.hostname.test(s.hostname) || r.issues.push({
        code: "invalid_format",
        format: "url",
        note: "Invalid hostname",
        pattern: e.hostname.source,
        input: r.value,
        inst: t,
        continue: !e.abort
      })), e.protocol && (e.protocol.lastIndex = 0, e.protocol.test(s.protocol.endsWith(":") ? s.protocol.slice(0, -1) : s.protocol) || r.issues.push({
        code: "invalid_format",
        format: "url",
        note: "Invalid protocol",
        pattern: e.protocol.source,
        input: r.value,
        inst: t,
        continue: !e.abort
      })), e.normalize ? r.value = s.href : r.value = o;
      return;
    } catch {
      r.issues.push({
        code: "invalid_format",
        format: "url",
        input: r.value,
        inst: t,
        continue: !e.abort
      });
    }
  };
}), kd = /* @__PURE__ */ q("$ZodEmoji", (t, e) => {
  e.pattern ?? (e.pattern = Vl()), $e.init(t, e);
}), Cd = /* @__PURE__ */ q("$ZodNanoID", (t, e) => {
  e.pattern ?? (e.pattern = Dl), $e.init(t, e);
}), Td = /* @__PURE__ */ q("$ZodCUID", (t, e) => {
  e.pattern ?? (e.pattern = Nl), $e.init(t, e);
}), Pd = /* @__PURE__ */ q("$ZodCUID2", (t, e) => {
  e.pattern ?? (e.pattern = Ml), $e.init(t, e);
}), Ad = /* @__PURE__ */ q("$ZodULID", (t, e) => {
  e.pattern ?? (e.pattern = jl), $e.init(t, e);
}), Rd = /* @__PURE__ */ q("$ZodXID", (t, e) => {
  e.pattern ?? (e.pattern = xl), $e.init(t, e);
}), Id = /* @__PURE__ */ q("$ZodKSUID", (t, e) => {
  e.pattern ?? (e.pattern = ql), $e.init(t, e);
}), Od = /* @__PURE__ */ q("$ZodISODateTime", (t, e) => {
  e.pattern ?? (e.pattern = ed(e)), $e.init(t, e);
}), zd = /* @__PURE__ */ q("$ZodISODate", (t, e) => {
  e.pattern ?? (e.pattern = Xl), $e.init(t, e);
}), Nd = /* @__PURE__ */ q("$ZodISOTime", (t, e) => {
  e.pattern ?? (e.pattern = Yl(e)), $e.init(t, e);
}), Md = /* @__PURE__ */ q("$ZodISODuration", (t, e) => {
  e.pattern ?? (e.pattern = Ul), $e.init(t, e);
}), jd = /* @__PURE__ */ q("$ZodIPv4", (t, e) => {
  e.pattern ?? (e.pattern = Hl), $e.init(t, e), t._zod.bag.format = "ipv4";
}), xd = /* @__PURE__ */ q("$ZodIPv6", (t, e) => {
  e.pattern ?? (e.pattern = Wl), $e.init(t, e), t._zod.bag.format = "ipv6", t._zod.check = (r) => {
    try {
      new URL(`http://[${r.value}]`);
    } catch {
      r.issues.push({
        code: "invalid_format",
        format: "ipv6",
        input: r.value,
        inst: t,
        continue: !e.abort
      });
    }
  };
}), qd = /* @__PURE__ */ q("$ZodCIDRv4", (t, e) => {
  e.pattern ?? (e.pattern = Bl), $e.init(t, e);
}), Dd = /* @__PURE__ */ q("$ZodCIDRv6", (t, e) => {
  e.pattern ?? (e.pattern = Gl), $e.init(t, e), t._zod.check = (r) => {
    const n = r.value.split("/");
    try {
      if (n.length !== 2)
        throw new Error();
      const [o, s] = n;
      if (!s)
        throw new Error();
      const i = Number(s);
      if (`${i}` !== s)
        throw new Error();
      if (i < 0 || i > 128)
        throw new Error();
      new URL(`http://[${o}]`);
    } catch {
      r.issues.push({
        code: "invalid_format",
        format: "cidrv6",
        input: r.value,
        inst: t,
        continue: !e.abort
      });
    }
  };
});
function bc(t) {
  if (t === "")
    return !0;
  if (/\s/.test(t) || t.length % 4 !== 0)
    return !1;
  try {
    return atob(t), !0;
  } catch {
    return !1;
  }
}
const Ud = /* @__PURE__ */ q("$ZodBase64", (t, e) => {
  e.pattern ?? (e.pattern = Kl), $e.init(t, e), t._zod.bag.contentEncoding = "base64", t._zod.check = (r) => {
    bc(r.value) || r.issues.push({
      code: "invalid_format",
      format: "base64",
      input: r.value,
      inst: t,
      continue: !e.abort
    });
  };
});
function Fd(t) {
  if (!pc.test(t))
    return !1;
  const e = t.replace(/[-_]/g, (n) => n === "-" ? "+" : "/"), r = e.padEnd(Math.ceil(e.length / 4) * 4, "=");
  return bc(r);
}
const Ld = /* @__PURE__ */ q("$ZodBase64URL", (t, e) => {
  e.pattern ?? (e.pattern = pc), $e.init(t, e), t._zod.bag.contentEncoding = "base64url", t._zod.check = (r) => {
    Fd(r.value) || r.issues.push({
      code: "invalid_format",
      format: "base64url",
      input: r.value,
      inst: t,
      continue: !e.abort
    });
  };
}), Zd = /* @__PURE__ */ q("$ZodE164", (t, e) => {
  e.pattern ?? (e.pattern = Ql), $e.init(t, e);
});
function Vd(t, e = null) {
  try {
    const r = t.split(".");
    if (r.length !== 3)
      return !1;
    const [n] = r;
    if (!n)
      return !1;
    const o = JSON.parse(atob(n));
    return !("typ" in o && (o == null ? void 0 : o.typ) !== "JWT" || !o.alg || e && (!("alg" in o) || o.alg !== e));
  } catch {
    return !1;
  }
}
const Hd = /* @__PURE__ */ q("$ZodJWT", (t, e) => {
  $e.init(t, e), t._zod.check = (r) => {
    Vd(r.value, e.alg) || r.issues.push({
      code: "invalid_format",
      format: "jwt",
      input: r.value,
      inst: t,
      continue: !e.abort
    });
  };
}), $c = /* @__PURE__ */ q("$ZodNumber", (t, e) => {
  ve.init(t, e), t._zod.pattern = t._zod.bag.pattern ?? _c, t._zod.parse = (r, n) => {
    if (e.coerce)
      try {
        r.value = Number(r.value);
      } catch {
      }
    const o = r.value;
    if (typeof o == "number" && !Number.isNaN(o) && Number.isFinite(o))
      return r;
    const s = typeof o == "number" ? Number.isNaN(o) ? "NaN" : Number.isFinite(o) ? void 0 : "Infinity" : void 0;
    return r.issues.push({
      expected: "number",
      code: "invalid_type",
      input: o,
      inst: t,
      ...s ? { received: s } : {}
    }), r;
  };
}), Wd = /* @__PURE__ */ q("$ZodNumberFormat", (t, e) => {
  cd.init(t, e), $c.init(t, e);
}), Bd = /* @__PURE__ */ q("$ZodBoolean", (t, e) => {
  ve.init(t, e), t._zod.pattern = nd, t._zod.parse = (r, n) => {
    if (e.coerce)
      try {
        r.value = !!r.value;
      } catch {
      }
    const o = r.value;
    return typeof o == "boolean" || r.issues.push({
      expected: "boolean",
      code: "invalid_type",
      input: o,
      inst: t
    }), r;
  };
}), Gd = /* @__PURE__ */ q("$ZodNull", (t, e) => {
  ve.init(t, e), t._zod.pattern = od, t._zod.values = /* @__PURE__ */ new Set([null]), t._zod.parse = (r, n) => {
    const o = r.value;
    return o === null || r.issues.push({
      expected: "null",
      code: "invalid_type",
      input: o,
      inst: t
    }), r;
  };
}), Kd = /* @__PURE__ */ q("$ZodAny", (t, e) => {
  ve.init(t, e), t._zod.parse = (r) => r;
}), Jd = /* @__PURE__ */ q("$ZodUnknown", (t, e) => {
  ve.init(t, e), t._zod.parse = (r) => r;
}), Qd = /* @__PURE__ */ q("$ZodNever", (t, e) => {
  ve.init(t, e), t._zod.parse = (r, n) => (r.issues.push({
    expected: "never",
    code: "invalid_type",
    input: r.value,
    inst: t
  }), r);
});
function ai(t, e, r) {
  t.issues.length && e.issues.push(...nr(r, t.issues)), e.value[r] = t.value;
}
const Xd = /* @__PURE__ */ q("$ZodArray", (t, e) => {
  ve.init(t, e), t._zod.parse = (r, n) => {
    const o = r.value;
    if (!Array.isArray(o))
      return r.issues.push({
        expected: "array",
        code: "invalid_type",
        input: o,
        inst: t
      }), r;
    r.value = Array(o.length);
    const s = [];
    for (let i = 0; i < o.length; i++) {
      const a = o[i], c = e.element._zod.run({
        value: a,
        issues: []
      }, n);
      c instanceof Promise ? s.push(c.then((u) => ai(u, r, i))) : ai(c, r, i);
    }
    return s.length ? Promise.all(s).then(() => r) : r;
  };
});
function Mn(t, e, r, n, o, s) {
  const i = r in n;
  if (t.issues.length) {
    if (o && s && !i)
      return;
    e.issues.push(...nr(r, t.issues));
  }
  if (!i && !o) {
    t.issues.length || e.issues.push({
      code: "invalid_type",
      expected: "nonoptional",
      input: void 0,
      path: [r]
    });
    return;
  }
  t.value === void 0 ? i && (e.value[r] = void 0) : e.value[r] = t.value;
}
function Sc(t) {
  var n, o, s, i;
  const e = Object.keys(t.shape);
  for (const a of e)
    if (!((i = (s = (o = (n = t.shape) == null ? void 0 : n[a]) == null ? void 0 : o._zod) == null ? void 0 : s.traits) != null && i.has("$ZodType")))
      throw new Error(`Invalid element at key "${a}": expected a Zod schema`);
  const r = hl(t.shape);
  return {
    ...t,
    keys: e,
    keySet: new Set(e),
    numKeys: e.length,
    optionalKeys: new Set(r)
  };
}
function Ec(t, e, r, n, o, s) {
  const i = [], a = o.keySet, c = o.catchall._zod, u = c.def.type, l = c.optin === "optional", h = c.optout === "optional";
  for (const m in e) {
    if (m === "__proto__" || a.has(m))
      continue;
    if (u === "never") {
      i.push(m);
      continue;
    }
    const _ = c.run({ value: e[m], issues: [] }, n);
    _ instanceof Promise ? t.push(_.then((S) => Mn(S, r, m, e, l, h))) : Mn(_, r, m, e, l, h);
  }
  return i.length && r.issues.push({
    code: "unrecognized_keys",
    keys: i,
    input: e,
    inst: s
  }), t.length ? Promise.all(t).then(() => r) : r;
}
const Yd = /* @__PURE__ */ q("$ZodObject", (t, e) => {
  ve.init(t, e);
  const r = Object.getOwnPropertyDescriptor(e, "shape");
  if (!(r != null && r.get)) {
    const a = e.shape;
    Object.defineProperty(e, "shape", {
      get: () => {
        const c = { ...a };
        return Object.defineProperty(e, "shape", {
          value: c
        }), c;
      }
    });
  }
  const n = Jn(() => Sc(e));
  ge(t._zod, "propValues", () => {
    const a = e.shape, c = {};
    for (const u in a) {
      const l = a[u]._zod;
      if (l.values) {
        c[u] ?? (c[u] = /* @__PURE__ */ new Set());
        for (const h of l.values)
          c[u].add(h);
      }
    }
    return c;
  });
  const o = Pr, s = e.catchall;
  let i;
  t._zod.parse = (a, c) => {
    i ?? (i = n.value);
    const u = a.value;
    if (!o(u))
      return a.issues.push({
        expected: "object",
        code: "invalid_type",
        input: u,
        inst: t
      }), a;
    a.value = {};
    const l = [], h = i.shape;
    for (const m of i.keys) {
      const _ = h[m], S = _._zod.optin === "optional", $ = _._zod.optout === "optional", v = _._zod.run({ value: u[m], issues: [] }, c);
      v instanceof Promise ? l.push(v.then((y) => Mn(y, a, m, u, S, $))) : Mn(v, a, m, u, S, $);
    }
    return s ? Ec(l, u, a, c, n.value, t) : l.length ? Promise.all(l).then(() => a) : a;
  };
}), ef = /* @__PURE__ */ q("$ZodObjectJIT", (t, e) => {
  Yd.init(t, e);
  const r = t._zod.parse, n = Jn(() => Sc(e)), o = (m) => {
    var w, k;
    const _ = new vd(["shape", "payload", "ctx"]), S = n.value, $ = (f) => {
      const d = si(f);
      return `shape[${d}]._zod.run({ value: input[${d}], issues: [] }, ctx)`;
    };
    _.write("const input = payload.value;");
    const v = /* @__PURE__ */ Object.create(null);
    let y = 0;
    for (const f of S.keys)
      v[f] = `key_${y++}`;
    _.write("const newResult = {};");
    for (const f of S.keys) {
      const d = v[f], p = si(f), E = m[f], I = ((w = E == null ? void 0 : E._zod) == null ? void 0 : w.optin) === "optional", R = ((k = E == null ? void 0 : E._zod) == null ? void 0 : k.optout) === "optional";
      _.write(`const ${d} = ${$(f)};`), I && R ? _.write(`
        if (${d}.issues.length) {
          if (${p} in input) {
            payload.issues = payload.issues.concat(${d}.issues.map(iss => ({
              ...iss,
              path: iss.path ? [${p}, ...iss.path] : [${p}]
            })));
          }
        }
        
        if (${d}.value === undefined) {
          if (${p} in input) {
            newResult[${p}] = undefined;
          }
        } else {
          newResult[${p}] = ${d}.value;
        }
        
      `) : I ? _.write(`
        if (${d}.issues.length) {
          payload.issues = payload.issues.concat(${d}.issues.map(iss => ({
            ...iss,
            path: iss.path ? [${p}, ...iss.path] : [${p}]
          })));
        }
        
        if (${d}.value === undefined) {
          if (${p} in input) {
            newResult[${p}] = undefined;
          }
        } else {
          newResult[${p}] = ${d}.value;
        }
        
      `) : _.write(`
        const ${d}_present = ${p} in input;
        if (${d}.issues.length) {
          payload.issues = payload.issues.concat(${d}.issues.map(iss => ({
            ...iss,
            path: iss.path ? [${p}, ...iss.path] : [${p}]
          })));
        }
        if (!${d}_present && !${d}.issues.length) {
          payload.issues.push({
            code: "invalid_type",
            expected: "nonoptional",
            input: undefined,
            path: [${p}]
          });
        }

        if (${d}_present) {
          if (${d}.value === undefined) {
            newResult[${p}] = undefined;
          } else {
            newResult[${p}] = ${d}.value;
          }
        }

      `);
    }
    _.write("payload.value = newResult;"), _.write("return payload;");
    const g = _.compile();
    return (f, d) => g(m, f, d);
  };
  let s;
  const i = Pr, a = !ps.jitless, u = a && dl.value, l = e.catchall;
  let h;
  t._zod.parse = (m, _) => {
    h ?? (h = n.value);
    const S = m.value;
    return i(S) ? a && u && (_ == null ? void 0 : _.async) === !1 && _.jitless !== !0 ? (s || (s = o(e.shape)), m = s(m, _), l ? Ec([], S, m, _, h, t) : m) : r(m, _) : (m.issues.push({
      expected: "object",
      code: "invalid_type",
      input: S,
      inst: t
    }), m);
  };
});
function ci(t, e, r, n) {
  for (const s of t)
    if (s.issues.length === 0)
      return e.value = s.value, e;
  const o = t.filter((s) => !rr(s));
  return o.length === 1 ? (e.value = o[0].value, o[0]) : (e.issues.push({
    code: "invalid_union",
    input: e.value,
    inst: r,
    errors: t.map((s) => s.issues.map((i) => Ct(i, n, kt())))
  }), e);
}
const kc = /* @__PURE__ */ q("$ZodUnion", (t, e) => {
  ve.init(t, e), ge(t._zod, "optin", () => e.options.some((n) => n._zod.optin === "optional") ? "optional" : void 0), ge(t._zod, "optout", () => e.options.some((n) => n._zod.optout === "optional") ? "optional" : void 0), ge(t._zod, "values", () => {
    if (e.options.every((n) => n._zod.values))
      return new Set(e.options.flatMap((n) => Array.from(n._zod.values)));
  }), ge(t._zod, "pattern", () => {
    if (e.options.every((n) => n._zod.pattern)) {
      const n = e.options.map((o) => o._zod.pattern);
      return new RegExp(`^(${n.map((o) => gs(o.source)).join("|")})$`);
    }
  });
  const r = e.options.length === 1 ? e.options[0]._zod.run : null;
  t._zod.parse = (n, o) => {
    if (r)
      return r(n, o);
    let s = !1;
    const i = [];
    for (const a of e.options) {
      const c = a._zod.run({
        value: n.value,
        issues: []
      }, o);
      if (c instanceof Promise)
        i.push(c), s = !0;
      else {
        if (c.issues.length === 0)
          return c;
        i.push(c);
      }
    }
    return s ? Promise.all(i).then((a) => ci(a, n, t, o)) : ci(i, n, t, o);
  };
}), tf = /* @__PURE__ */ q("$ZodDiscriminatedUnion", (t, e) => {
  e.inclusive = !1, kc.init(t, e);
  const r = t._zod.parse;
  ge(t._zod, "propValues", () => {
    const o = {};
    for (const s of e.options) {
      const i = s._zod.propValues;
      if (!i || Object.keys(i).length === 0)
        throw new Error(`Invalid discriminated union option at index "${e.options.indexOf(s)}"`);
      for (const [a, c] of Object.entries(i)) {
        o[a] || (o[a] = /* @__PURE__ */ new Set());
        for (const u of c)
          o[a].add(u);
      }
    }
    return o;
  });
  const n = Jn(() => {
    var i;
    const o = e.options, s = /* @__PURE__ */ new Map();
    for (const a of o) {
      const c = (i = a._zod.propValues) == null ? void 0 : i[e.discriminator];
      if (!c || c.size === 0)
        throw new Error(`Invalid discriminated union option at index "${e.options.indexOf(a)}"`);
      for (const u of c) {
        if (s.has(u))
          throw new Error(`Duplicate discriminator value "${String(u)}"`);
        s.set(u, a);
      }
    }
    return s;
  });
  t._zod.parse = (o, s) => {
    const i = o.value;
    if (!Pr(i))
      return o.issues.push({
        code: "invalid_type",
        expected: "object",
        input: i,
        inst: t
      }), o;
    const a = n.value.get(i == null ? void 0 : i[e.discriminator]);
    return a ? a._zod.run(o, s) : e.unionFallback || s.direction === "backward" ? r(o, s) : (o.issues.push({
      code: "invalid_union",
      errors: [],
      note: "No matching discriminator",
      discriminator: e.discriminator,
      options: Array.from(n.value.keys()),
      input: i,
      path: [e.discriminator],
      inst: t
    }), o);
  };
}), rf = /* @__PURE__ */ q("$ZodIntersection", (t, e) => {
  ve.init(t, e), t._zod.parse = (r, n) => {
    const o = r.value, s = e.left._zod.run({ value: o, issues: [] }, n), i = e.right._zod.run({ value: o, issues: [] }, n);
    return s instanceof Promise || i instanceof Promise ? Promise.all([s, i]).then(([c, u]) => ui(r, c, u)) : ui(r, s, i);
  };
});
function Do(t, e) {
  if (t === e)
    return { valid: !0, data: t };
  if (t instanceof Date && e instanceof Date && +t == +e)
    return { valid: !0, data: t };
  if (lr(t) && lr(e)) {
    const r = Object.keys(e), n = Object.keys(t).filter((s) => r.indexOf(s) !== -1), o = { ...t, ...e };
    for (const s of n) {
      const i = Do(t[s], e[s]);
      if (!i.valid)
        return {
          valid: !1,
          mergeErrorPath: [s, ...i.mergeErrorPath]
        };
      o[s] = i.data;
    }
    return { valid: !0, data: o };
  }
  if (Array.isArray(t) && Array.isArray(e)) {
    if (t.length !== e.length)
      return { valid: !1, mergeErrorPath: [] };
    const r = [];
    for (let n = 0; n < t.length; n++) {
      const o = t[n], s = e[n], i = Do(o, s);
      if (!i.valid)
        return {
          valid: !1,
          mergeErrorPath: [n, ...i.mergeErrorPath]
        };
      r.push(i.data);
    }
    return { valid: !0, data: r };
  }
  return { valid: !1, mergeErrorPath: [] };
}
function ui(t, e, r) {
  const n = /* @__PURE__ */ new Map();
  let o;
  for (const a of e.issues)
    if (a.code === "unrecognized_keys") {
      o ?? (o = a);
      for (const c of a.keys)
        n.has(c) || n.set(c, {}), n.get(c).l = !0;
    } else
      t.issues.push(a);
  for (const a of r.issues)
    if (a.code === "unrecognized_keys")
      for (const c of a.keys)
        n.has(c) || n.set(c, {}), n.get(c).r = !0;
    else
      t.issues.push(a);
  const s = [...n].filter(([, a]) => a.l && a.r).map(([a]) => a);
  if (s.length && o && t.issues.push({ ...o, keys: s }), rr(t))
    return t;
  const i = Do(e.value, r.value);
  if (!i.valid)
    throw new Error(`Unmergable intersection. Error path: ${JSON.stringify(i.mergeErrorPath)}`);
  return t.value = i.data, t;
}
const nf = /* @__PURE__ */ q("$ZodRecord", (t, e) => {
  ve.init(t, e), t._zod.parse = (r, n) => {
    const o = r.value;
    if (!lr(o))
      return r.issues.push({
        expected: "record",
        code: "invalid_type",
        input: o,
        inst: t
      }), r;
    const s = [], i = e.keyType._zod.values;
    if (i) {
      r.value = {};
      const a = /* @__PURE__ */ new Set();
      for (const u of i)
        if (typeof u == "string" || typeof u == "number" || typeof u == "symbol") {
          a.add(typeof u == "number" ? u.toString() : u);
          const l = e.keyType._zod.run({ value: u, issues: [] }, n);
          if (l instanceof Promise)
            throw new Error("Async schemas not supported in object keys currently");
          if (l.issues.length) {
            r.issues.push({
              code: "invalid_key",
              origin: "record",
              issues: l.issues.map((_) => Ct(_, n, kt())),
              input: u,
              path: [u],
              inst: t
            });
            continue;
          }
          const h = l.value, m = e.valueType._zod.run({ value: o[u], issues: [] }, n);
          m instanceof Promise ? s.push(m.then((_) => {
            _.issues.length && r.issues.push(...nr(u, _.issues)), r.value[h] = _.value;
          })) : (m.issues.length && r.issues.push(...nr(u, m.issues)), r.value[h] = m.value);
        }
      let c;
      for (const u in o)
        a.has(u) || (c = c ?? [], c.push(u));
      c && c.length > 0 && r.issues.push({
        code: "unrecognized_keys",
        input: o,
        inst: t,
        keys: c
      });
    } else {
      r.value = {};
      for (const a of Reflect.ownKeys(o)) {
        if (a === "__proto__" || !Object.prototype.propertyIsEnumerable.call(o, a))
          continue;
        let c = e.keyType._zod.run({ value: a, issues: [] }, n);
        if (c instanceof Promise)
          throw new Error("Async schemas not supported in object keys currently");
        if (typeof a == "string" && _c.test(a) && c.issues.length) {
          const h = e.keyType._zod.run({ value: Number(a), issues: [] }, n);
          if (h instanceof Promise)
            throw new Error("Async schemas not supported in object keys currently");
          h.issues.length === 0 && (c = h);
        }
        if (c.issues.length) {
          e.mode === "loose" ? r.value[a] = o[a] : r.issues.push({
            code: "invalid_key",
            origin: "record",
            issues: c.issues.map((h) => Ct(h, n, kt())),
            input: a,
            path: [a],
            inst: t
          });
          continue;
        }
        const l = e.valueType._zod.run({ value: o[a], issues: [] }, n);
        l instanceof Promise ? s.push(l.then((h) => {
          h.issues.length && r.issues.push(...nr(a, h.issues)), r.value[c.value] = h.value;
        })) : (l.issues.length && r.issues.push(...nr(a, l.issues)), r.value[c.value] = l.value);
      }
    }
    return s.length ? Promise.all(s).then(() => r) : r;
  };
}), of = /* @__PURE__ */ q("$ZodEnum", (t, e) => {
  ve.init(t, e);
  const r = ac(e.entries), n = new Set(r);
  t._zod.values = n, t._zod.pattern = new RegExp(`^(${r.filter((o) => fl.has(typeof o)).map((o) => typeof o == "string" ? dr(o) : o.toString()).join("|")})$`), t._zod.parse = (o, s) => {
    const i = o.value;
    return n.has(i) || o.issues.push({
      code: "invalid_value",
      values: r,
      input: i,
      inst: t
    }), o;
  };
}), sf = /* @__PURE__ */ q("$ZodLiteral", (t, e) => {
  if (ve.init(t, e), e.values.length === 0)
    throw new Error("Cannot create literal schema with no valid values");
  const r = new Set(e.values);
  t._zod.values = r, t._zod.pattern = new RegExp(`^(${e.values.map((n) => typeof n == "string" ? dr(n) : n ? dr(n.toString()) : String(n)).join("|")})$`), t._zod.parse = (n, o) => {
    const s = n.value;
    return r.has(s) || n.issues.push({
      code: "invalid_value",
      values: e.values,
      input: s,
      inst: t
    }), n;
  };
}), af = /* @__PURE__ */ q("$ZodTransform", (t, e) => {
  ve.init(t, e), t._zod.optin = "optional", t._zod.parse = (r, n) => {
    if (n.direction === "backward")
      throw new ic(t.constructor.name);
    const o = e.transform(r.value, r);
    if (n.async)
      return (o instanceof Promise ? o : Promise.resolve(o)).then((i) => (r.value = i, r.fallback = !0, r));
    if (o instanceof Promise)
      throw new ir();
    return r.value = o, r.fallback = !0, r;
  };
});
function li(t, e) {
  return e === void 0 && (t.issues.length || t.fallback) ? { issues: [], value: void 0 } : t;
}
const Cc = /* @__PURE__ */ q("$ZodOptional", (t, e) => {
  ve.init(t, e), t._zod.optin = "optional", t._zod.optout = "optional", ge(t._zod, "values", () => e.innerType._zod.values ? /* @__PURE__ */ new Set([...e.innerType._zod.values, void 0]) : void 0), ge(t._zod, "pattern", () => {
    const r = e.innerType._zod.pattern;
    return r ? new RegExp(`^(${gs(r.source)})?$`) : void 0;
  }), t._zod.parse = (r, n) => {
    if (e.innerType._zod.optin === "optional") {
      const o = r.value, s = e.innerType._zod.run(r, n);
      return s instanceof Promise ? s.then((i) => li(i, o)) : li(s, o);
    }
    return r.value === void 0 ? r : e.innerType._zod.run(r, n);
  };
}), cf = /* @__PURE__ */ q("$ZodExactOptional", (t, e) => {
  Cc.init(t, e), ge(t._zod, "values", () => e.innerType._zod.values), ge(t._zod, "pattern", () => e.innerType._zod.pattern), t._zod.parse = (r, n) => e.innerType._zod.run(r, n);
}), uf = /* @__PURE__ */ q("$ZodNullable", (t, e) => {
  ve.init(t, e), ge(t._zod, "optin", () => e.innerType._zod.optin), ge(t._zod, "optout", () => e.innerType._zod.optout), ge(t._zod, "pattern", () => {
    const r = e.innerType._zod.pattern;
    return r ? new RegExp(`^(${gs(r.source)}|null)$`) : void 0;
  }), ge(t._zod, "values", () => e.innerType._zod.values ? /* @__PURE__ */ new Set([...e.innerType._zod.values, null]) : void 0), t._zod.parse = (r, n) => r.value === null ? r : e.innerType._zod.run(r, n);
}), lf = /* @__PURE__ */ q("$ZodDefault", (t, e) => {
  ve.init(t, e), t._zod.optin = "optional", ge(t._zod, "values", () => e.innerType._zod.values), t._zod.parse = (r, n) => {
    if (n.direction === "backward")
      return e.innerType._zod.run(r, n);
    if (r.value === void 0)
      return r.value = e.defaultValue, r;
    const o = e.innerType._zod.run(r, n);
    return o instanceof Promise ? o.then((s) => di(s, e)) : di(o, e);
  };
});
function di(t, e) {
  return t.value === void 0 && (t.value = e.defaultValue), t;
}
const df = /* @__PURE__ */ q("$ZodPrefault", (t, e) => {
  ve.init(t, e), t._zod.optin = "optional", ge(t._zod, "values", () => e.innerType._zod.values), t._zod.parse = (r, n) => (n.direction === "backward" || r.value === void 0 && (r.value = e.defaultValue), e.innerType._zod.run(r, n));
}), ff = /* @__PURE__ */ q("$ZodNonOptional", (t, e) => {
  ve.init(t, e), ge(t._zod, "values", () => {
    const r = e.innerType._zod.values;
    return r ? new Set([...r].filter((n) => n !== void 0)) : void 0;
  }), t._zod.parse = (r, n) => {
    const o = e.innerType._zod.run(r, n);
    return o instanceof Promise ? o.then((s) => fi(s, t)) : fi(o, t);
  };
});
function fi(t, e) {
  return !t.issues.length && t.value === void 0 && t.issues.push({
    code: "invalid_type",
    expected: "nonoptional",
    input: t.value,
    inst: e
  }), t;
}
const hf = /* @__PURE__ */ q("$ZodCatch", (t, e) => {
  ve.init(t, e), t._zod.optin = "optional", ge(t._zod, "optout", () => e.innerType._zod.optout), ge(t._zod, "values", () => e.innerType._zod.values), t._zod.parse = (r, n) => {
    if (n.direction === "backward")
      return e.innerType._zod.run(r, n);
    const o = e.innerType._zod.run(r, n);
    return o instanceof Promise ? o.then((s) => (r.value = s.value, s.issues.length && (r.value = e.catchValue({
      ...r,
      error: {
        issues: s.issues.map((i) => Ct(i, n, kt()))
      },
      input: r.value
    }), r.issues = [], r.fallback = !0), r)) : (r.value = o.value, o.issues.length && (r.value = e.catchValue({
      ...r,
      error: {
        issues: o.issues.map((s) => Ct(s, n, kt()))
      },
      input: r.value
    }), r.issues = [], r.fallback = !0), r);
  };
}), Tc = /* @__PURE__ */ q("$ZodPipe", (t, e) => {
  ve.init(t, e), ge(t._zod, "values", () => e.in._zod.values), ge(t._zod, "optin", () => e.in._zod.optin), ge(t._zod, "optout", () => e.out._zod.optout), ge(t._zod, "propValues", () => e.in._zod.propValues), t._zod.parse = (r, n) => {
    if (n.direction === "backward") {
      const s = e.out._zod.run(r, n);
      return s instanceof Promise ? s.then((i) => Fr(i, e.in, n)) : Fr(s, e.in, n);
    }
    const o = e.in._zod.run(r, n);
    return o instanceof Promise ? o.then((s) => Fr(s, e.out, n)) : Fr(o, e.out, n);
  };
});
function Fr(t, e, r) {
  return t.issues.length ? (t.aborted = !0, t) : e._zod.run({ value: t.value, issues: t.issues, fallback: t.fallback }, r);
}
const pf = /* @__PURE__ */ q("$ZodPreprocess", (t, e) => {
  Tc.init(t, e);
}), mf = /* @__PURE__ */ q("$ZodReadonly", (t, e) => {
  ve.init(t, e), ge(t._zod, "propValues", () => e.innerType._zod.propValues), ge(t._zod, "values", () => e.innerType._zod.values), ge(t._zod, "optin", () => {
    var r, n;
    return (n = (r = e.innerType) == null ? void 0 : r._zod) == null ? void 0 : n.optin;
  }), ge(t._zod, "optout", () => {
    var r, n;
    return (n = (r = e.innerType) == null ? void 0 : r._zod) == null ? void 0 : n.optout;
  }), t._zod.parse = (r, n) => {
    if (n.direction === "backward")
      return e.innerType._zod.run(r, n);
    const o = e.innerType._zod.run(r, n);
    return o instanceof Promise ? o.then(hi) : hi(o);
  };
});
function hi(t) {
  return t.value = Object.freeze(t.value), t;
}
const gf = /* @__PURE__ */ q("$ZodCustom", (t, e) => {
  tt.init(t, e), ve.init(t, e), t._zod.parse = (r, n) => r, t._zod.check = (r) => {
    const n = r.value, o = e.fn(n);
    if (o instanceof Promise)
      return o.then((s) => pi(s, r, n, t));
    pi(o, r, n, t);
  };
});
function pi(t, e, r, n) {
  if (!t) {
    const o = {
      code: "custom",
      input: r,
      inst: n,
      // incorporates params.error into issue reporting
      path: [...n._zod.def.path ?? []],
      // incorporates params.error into issue reporting
      continue: !n._zod.def.abort
      // params: inst._zod.def.params,
    };
    n._zod.def.params && (o.params = n._zod.def.params), e.issues.push(Ar(o));
  }
}
var mi;
class _f {
  constructor() {
    this._map = /* @__PURE__ */ new WeakMap(), this._idmap = /* @__PURE__ */ new Map();
  }
  add(e, ...r) {
    const n = r[0];
    return this._map.set(e, n), n && typeof n == "object" && "id" in n && this._idmap.set(n.id, e), this;
  }
  clear() {
    return this._map = /* @__PURE__ */ new WeakMap(), this._idmap = /* @__PURE__ */ new Map(), this;
  }
  remove(e) {
    const r = this._map.get(e);
    return r && typeof r == "object" && "id" in r && this._idmap.delete(r.id), this._map.delete(e), this;
  }
  get(e) {
    const r = e._zod.parent;
    if (r) {
      const n = { ...this.get(r) ?? {} };
      delete n.id;
      const o = { ...n, ...this._map.get(e) };
      return Object.keys(o).length ? o : void 0;
    }
    return this._map.get(e);
  }
  has(e) {
    return this._map.has(e);
  }
}
function yf() {
  return new _f();
}
(mi = globalThis).__zod_globalRegistry ?? (mi.__zod_globalRegistry = yf());
const wr = globalThis.__zod_globalRegistry;
// @__NO_SIDE_EFFECTS__
function vf(t, e) {
  return new t({
    type: "string",
    ...K(e)
  });
}
// @__NO_SIDE_EFFECTS__
function wf(t, e) {
  return new t({
    type: "string",
    format: "email",
    check: "string_format",
    abort: !1,
    ...K(e)
  });
}
// @__NO_SIDE_EFFECTS__
function gi(t, e) {
  return new t({
    type: "string",
    format: "guid",
    check: "string_format",
    abort: !1,
    ...K(e)
  });
}
// @__NO_SIDE_EFFECTS__
function bf(t, e) {
  return new t({
    type: "string",
    format: "uuid",
    check: "string_format",
    abort: !1,
    ...K(e)
  });
}
// @__NO_SIDE_EFFECTS__
function $f(t, e) {
  return new t({
    type: "string",
    format: "uuid",
    check: "string_format",
    abort: !1,
    version: "v4",
    ...K(e)
  });
}
// @__NO_SIDE_EFFECTS__
function Sf(t, e) {
  return new t({
    type: "string",
    format: "uuid",
    check: "string_format",
    abort: !1,
    version: "v6",
    ...K(e)
  });
}
// @__NO_SIDE_EFFECTS__
function Ef(t, e) {
  return new t({
    type: "string",
    format: "uuid",
    check: "string_format",
    abort: !1,
    version: "v7",
    ...K(e)
  });
}
// @__NO_SIDE_EFFECTS__
function Pc(t, e) {
  return new t({
    type: "string",
    format: "url",
    check: "string_format",
    abort: !1,
    ...K(e)
  });
}
// @__NO_SIDE_EFFECTS__
function kf(t, e) {
  return new t({
    type: "string",
    format: "emoji",
    check: "string_format",
    abort: !1,
    ...K(e)
  });
}
// @__NO_SIDE_EFFECTS__
function Cf(t, e) {
  return new t({
    type: "string",
    format: "nanoid",
    check: "string_format",
    abort: !1,
    ...K(e)
  });
}
// @__NO_SIDE_EFFECTS__
function Tf(t, e) {
  return new t({
    type: "string",
    format: "cuid",
    check: "string_format",
    abort: !1,
    ...K(e)
  });
}
// @__NO_SIDE_EFFECTS__
function Pf(t, e) {
  return new t({
    type: "string",
    format: "cuid2",
    check: "string_format",
    abort: !1,
    ...K(e)
  });
}
// @__NO_SIDE_EFFECTS__
function Af(t, e) {
  return new t({
    type: "string",
    format: "ulid",
    check: "string_format",
    abort: !1,
    ...K(e)
  });
}
// @__NO_SIDE_EFFECTS__
function Rf(t, e) {
  return new t({
    type: "string",
    format: "xid",
    check: "string_format",
    abort: !1,
    ...K(e)
  });
}
// @__NO_SIDE_EFFECTS__
function If(t, e) {
  return new t({
    type: "string",
    format: "ksuid",
    check: "string_format",
    abort: !1,
    ...K(e)
  });
}
// @__NO_SIDE_EFFECTS__
function Of(t, e) {
  return new t({
    type: "string",
    format: "ipv4",
    check: "string_format",
    abort: !1,
    ...K(e)
  });
}
// @__NO_SIDE_EFFECTS__
function zf(t, e) {
  return new t({
    type: "string",
    format: "ipv6",
    check: "string_format",
    abort: !1,
    ...K(e)
  });
}
// @__NO_SIDE_EFFECTS__
function Nf(t, e) {
  return new t({
    type: "string",
    format: "cidrv4",
    check: "string_format",
    abort: !1,
    ...K(e)
  });
}
// @__NO_SIDE_EFFECTS__
function Mf(t, e) {
  return new t({
    type: "string",
    format: "cidrv6",
    check: "string_format",
    abort: !1,
    ...K(e)
  });
}
// @__NO_SIDE_EFFECTS__
function jf(t, e) {
  return new t({
    type: "string",
    format: "base64",
    check: "string_format",
    abort: !1,
    ...K(e)
  });
}
// @__NO_SIDE_EFFECTS__
function xf(t, e) {
  return new t({
    type: "string",
    format: "base64url",
    check: "string_format",
    abort: !1,
    ...K(e)
  });
}
// @__NO_SIDE_EFFECTS__
function qf(t, e) {
  return new t({
    type: "string",
    format: "e164",
    check: "string_format",
    abort: !1,
    ...K(e)
  });
}
// @__NO_SIDE_EFFECTS__
function Df(t, e) {
  return new t({
    type: "string",
    format: "jwt",
    check: "string_format",
    abort: !1,
    ...K(e)
  });
}
// @__NO_SIDE_EFFECTS__
function Uf(t, e) {
  return new t({
    type: "string",
    format: "datetime",
    check: "string_format",
    offset: !1,
    local: !1,
    precision: null,
    ...K(e)
  });
}
// @__NO_SIDE_EFFECTS__
function Ff(t, e) {
  return new t({
    type: "string",
    format: "date",
    check: "string_format",
    ...K(e)
  });
}
// @__NO_SIDE_EFFECTS__
function Lf(t, e) {
  return new t({
    type: "string",
    format: "time",
    check: "string_format",
    precision: null,
    ...K(e)
  });
}
// @__NO_SIDE_EFFECTS__
function Zf(t, e) {
  return new t({
    type: "string",
    format: "duration",
    check: "string_format",
    ...K(e)
  });
}
// @__NO_SIDE_EFFECTS__
function Vf(t, e) {
  return new t({
    type: "number",
    checks: [],
    ...K(e)
  });
}
// @__NO_SIDE_EFFECTS__
function Hf(t, e) {
  return new t({
    type: "number",
    coerce: !0,
    checks: [],
    ...K(e)
  });
}
// @__NO_SIDE_EFFECTS__
function Wf(t, e) {
  return new t({
    type: "number",
    check: "number_format",
    abort: !1,
    format: "safeint",
    ...K(e)
  });
}
// @__NO_SIDE_EFFECTS__
function Bf(t, e) {
  return new t({
    type: "boolean",
    ...K(e)
  });
}
// @__NO_SIDE_EFFECTS__
function Gf(t, e) {
  return new t({
    type: "null",
    ...K(e)
  });
}
// @__NO_SIDE_EFFECTS__
function Kf(t) {
  return new t({
    type: "any"
  });
}
// @__NO_SIDE_EFFECTS__
function Jf(t) {
  return new t({
    type: "unknown"
  });
}
// @__NO_SIDE_EFFECTS__
function Qf(t, e) {
  return new t({
    type: "never",
    ...K(e)
  });
}
// @__NO_SIDE_EFFECTS__
function _i(t, e) {
  return new vc({
    check: "less_than",
    ...K(e),
    value: t,
    inclusive: !1
  });
}
// @__NO_SIDE_EFFECTS__
function mo(t, e) {
  return new vc({
    check: "less_than",
    ...K(e),
    value: t,
    inclusive: !0
  });
}
// @__NO_SIDE_EFFECTS__
function yi(t, e) {
  return new wc({
    check: "greater_than",
    ...K(e),
    value: t,
    inclusive: !1
  });
}
// @__NO_SIDE_EFFECTS__
function go(t, e) {
  return new wc({
    check: "greater_than",
    ...K(e),
    value: t,
    inclusive: !0
  });
}
// @__NO_SIDE_EFFECTS__
function vi(t, e) {
  return new ad({
    check: "multiple_of",
    ...K(e),
    value: t
  });
}
// @__NO_SIDE_EFFECTS__
function Ac(t, e) {
  return new ud({
    check: "max_length",
    ...K(e),
    maximum: t
  });
}
// @__NO_SIDE_EFFECTS__
function jn(t, e) {
  return new ld({
    check: "min_length",
    ...K(e),
    minimum: t
  });
}
// @__NO_SIDE_EFFECTS__
function Rc(t, e) {
  return new dd({
    check: "length_equals",
    ...K(e),
    length: t
  });
}
// @__NO_SIDE_EFFECTS__
function Xf(t, e) {
  return new fd({
    check: "string_format",
    format: "regex",
    ...K(e),
    pattern: t
  });
}
// @__NO_SIDE_EFFECTS__
function Yf(t) {
  return new hd({
    check: "string_format",
    format: "lowercase",
    ...K(t)
  });
}
// @__NO_SIDE_EFFECTS__
function eh(t) {
  return new pd({
    check: "string_format",
    format: "uppercase",
    ...K(t)
  });
}
// @__NO_SIDE_EFFECTS__
function th(t, e) {
  return new md({
    check: "string_format",
    format: "includes",
    ...K(e),
    includes: t
  });
}
// @__NO_SIDE_EFFECTS__
function rh(t, e) {
  return new gd({
    check: "string_format",
    format: "starts_with",
    ...K(e),
    prefix: t
  });
}
// @__NO_SIDE_EFFECTS__
function nh(t, e) {
  return new _d({
    check: "string_format",
    format: "ends_with",
    ...K(e),
    suffix: t
  });
}
// @__NO_SIDE_EFFECTS__
function pr(t) {
  return new yd({
    check: "overwrite",
    tx: t
  });
}
// @__NO_SIDE_EFFECTS__
function oh(t) {
  return /* @__PURE__ */ pr((e) => e.normalize(t));
}
// @__NO_SIDE_EFFECTS__
function sh() {
  return /* @__PURE__ */ pr((t) => t.trim());
}
// @__NO_SIDE_EFFECTS__
function ih() {
  return /* @__PURE__ */ pr((t) => t.toLowerCase());
}
// @__NO_SIDE_EFFECTS__
function ah() {
  return /* @__PURE__ */ pr((t) => t.toUpperCase());
}
// @__NO_SIDE_EFFECTS__
function ch() {
  return /* @__PURE__ */ pr((t) => ll(t));
}
// @__NO_SIDE_EFFECTS__
function uh(t, e, r) {
  return new t({
    type: "array",
    element: e,
    // get element() {
    //   return element;
    // },
    ...K(r)
  });
}
// @__NO_SIDE_EFFECTS__
function lh(t, e, r) {
  const n = K(r);
  return n.abort ?? (n.abort = !0), new t({
    type: "custom",
    check: "custom",
    fn: e,
    ...n
  });
}
// @__NO_SIDE_EFFECTS__
function dh(t, e, r) {
  return new t({
    type: "custom",
    check: "custom",
    fn: e,
    ...K(r)
  });
}
// @__NO_SIDE_EFFECTS__
function fh(t, e) {
  const r = /* @__PURE__ */ hh((n) => (n.addIssue = (o) => {
    if (typeof o == "string")
      n.issues.push(Ar(o, n.value, r._zod.def));
    else {
      const s = o;
      s.fatal && (s.continue = !1), s.code ?? (s.code = "custom"), s.input ?? (s.input = n.value), s.inst ?? (s.inst = r), s.continue ?? (s.continue = !r._zod.def.abort), n.issues.push(Ar(s));
    }
  }, t(n.value, n)), e);
  return r;
}
// @__NO_SIDE_EFFECTS__
function hh(t, e) {
  const r = new tt({
    check: "custom",
    ...K(e)
  });
  return r._zod.check = t, r;
}
function Ic(t) {
  let e = (t == null ? void 0 : t.target) ?? "draft-2020-12";
  return e === "draft-4" && (e = "draft-04"), e === "draft-7" && (e = "draft-07"), {
    processors: t.processors ?? {},
    metadataRegistry: (t == null ? void 0 : t.metadata) ?? wr,
    target: e,
    unrepresentable: (t == null ? void 0 : t.unrepresentable) ?? "throw",
    override: (t == null ? void 0 : t.override) ?? (() => {
    }),
    io: (t == null ? void 0 : t.io) ?? "output",
    counter: 0,
    seen: /* @__PURE__ */ new Map(),
    cycles: (t == null ? void 0 : t.cycles) ?? "ref",
    reused: (t == null ? void 0 : t.reused) ?? "inline",
    external: (t == null ? void 0 : t.external) ?? void 0
  };
}
function Ie(t, e, r = { path: [], schemaPath: [] }) {
  var l, h;
  var n;
  const o = t._zod.def, s = e.seen.get(t);
  if (s)
    return s.count++, r.schemaPath.includes(t) && (s.cycle = r.path), s.schema;
  const i = { schema: {}, count: 1, cycle: void 0, path: r.path };
  e.seen.set(t, i);
  const a = (h = (l = t._zod).toJSONSchema) == null ? void 0 : h.call(l);
  if (a)
    i.schema = a;
  else {
    const m = {
      ...r,
      schemaPath: [...r.schemaPath, t],
      path: r.path
    };
    if (t._zod.processJSONSchema)
      t._zod.processJSONSchema(e, i.schema, m);
    else {
      const S = i.schema, $ = e.processors[o.type];
      if (!$)
        throw new Error(`[toJSONSchema]: Non-representable type encountered: ${o.type}`);
      $(t, e, S, m);
    }
    const _ = t._zod.parent;
    _ && (i.ref || (i.ref = _), Ie(_, e, m), e.seen.get(_).isParent = !0);
  }
  const c = e.metadataRegistry.get(t);
  return c && Object.assign(i.schema, c), e.io === "input" && Ge(t) && (delete i.schema.examples, delete i.schema.default), e.io === "input" && "_prefault" in i.schema && ((n = i.schema).default ?? (n.default = i.schema._prefault)), delete i.schema._prefault, e.seen.get(t).schema;
}
function Oc(t, e) {
  var i, a, c, u;
  const r = t.seen.get(e);
  if (!r)
    throw new Error("Unprocessed schema. This is a bug in Zod.");
  const n = /* @__PURE__ */ new Map();
  for (const l of t.seen.entries()) {
    const h = (i = t.metadataRegistry.get(l[0])) == null ? void 0 : i.id;
    if (h) {
      const m = n.get(h);
      if (m && m !== l[0])
        throw new Error(`Duplicate schema id "${h}" detected during JSON Schema conversion. Two different schemas cannot share the same id when converted together.`);
      n.set(h, l[0]);
    }
  }
  const o = (l) => {
    var $;
    const h = t.target === "draft-2020-12" ? "$defs" : "definitions";
    if (t.external) {
      const v = ($ = t.external.registry.get(l[0])) == null ? void 0 : $.id, y = t.external.uri ?? ((w) => w);
      if (v)
        return { ref: y(v) };
      const g = l[1].defId ?? l[1].schema.id ?? `schema${t.counter++}`;
      return l[1].defId = g, { defId: g, ref: `${y("__shared")}#/${h}/${g}` };
    }
    if (l[1] === r)
      return { ref: "#" };
    const _ = `#/${h}/`, S = l[1].schema.id ?? `__schema${t.counter++}`;
    return { defId: S, ref: _ + S };
  }, s = (l) => {
    if (l[1].schema.$ref)
      return;
    const h = l[1], { ref: m, defId: _ } = o(l);
    h.def = { ...h.schema }, _ && (h.defId = _);
    const S = h.schema;
    for (const $ in S)
      delete S[$];
    S.$ref = m;
  };
  if (t.cycles === "throw")
    for (const l of t.seen.entries()) {
      const h = l[1];
      if (h.cycle)
        throw new Error(`Cycle detected: #/${(a = h.cycle) == null ? void 0 : a.join("/")}/<root>

Set the \`cycles\` parameter to \`"ref"\` to resolve cyclical schemas with defs.`);
    }
  for (const l of t.seen.entries()) {
    const h = l[1];
    if (e === l[0]) {
      s(l);
      continue;
    }
    if (t.external) {
      const _ = (c = t.external.registry.get(l[0])) == null ? void 0 : c.id;
      if (e !== l[0] && _) {
        s(l);
        continue;
      }
    }
    if ((u = t.metadataRegistry.get(l[0])) == null ? void 0 : u.id) {
      s(l);
      continue;
    }
    if (h.cycle) {
      s(l);
      continue;
    }
    if (h.count > 1 && t.reused === "ref") {
      s(l);
      continue;
    }
  }
}
function zc(t, e) {
  var a, c, u, l;
  const r = t.seen.get(e);
  if (!r)
    throw new Error("Unprocessed schema. This is a bug in Zod.");
  const n = (h) => {
    const m = t.seen.get(h);
    if (m.ref === null)
      return;
    const _ = m.def ?? m.schema, S = { ..._ }, $ = m.ref;
    if (m.ref = null, $) {
      n($);
      const y = t.seen.get($), g = y.schema;
      if (g.$ref && (t.target === "draft-07" || t.target === "draft-04" || t.target === "openapi-3.0") ? (_.allOf = _.allOf ?? [], _.allOf.push(g)) : Object.assign(_, g), Object.assign(_, S), h._zod.parent === $)
        for (const k in _)
          k === "$ref" || k === "allOf" || k in S || delete _[k];
      if (g.$ref && y.def)
        for (const k in _)
          k === "$ref" || k === "allOf" || k in y.def && JSON.stringify(_[k]) === JSON.stringify(y.def[k]) && delete _[k];
    }
    const v = h._zod.parent;
    if (v && v !== $) {
      n(v);
      const y = t.seen.get(v);
      if (y != null && y.schema.$ref && (_.$ref = y.schema.$ref, y.def))
        for (const g in _)
          g === "$ref" || g === "allOf" || g in y.def && JSON.stringify(_[g]) === JSON.stringify(y.def[g]) && delete _[g];
    }
    t.override({
      zodSchema: h,
      jsonSchema: _,
      path: m.path ?? []
    });
  };
  for (const h of [...t.seen.entries()].reverse())
    n(h[0]);
  const o = {};
  if (t.target === "draft-2020-12" ? o.$schema = "https://json-schema.org/draft/2020-12/schema" : t.target === "draft-07" ? o.$schema = "http://json-schema.org/draft-07/schema#" : t.target === "draft-04" ? o.$schema = "http://json-schema.org/draft-04/schema#" : t.target, (a = t.external) != null && a.uri) {
    const h = (c = t.external.registry.get(e)) == null ? void 0 : c.id;
    if (!h)
      throw new Error("Schema is missing an `id` property");
    o.$id = t.external.uri(h);
  }
  Object.assign(o, r.def ?? r.schema);
  const s = (u = t.metadataRegistry.get(e)) == null ? void 0 : u.id;
  s !== void 0 && o.id === s && delete o.id;
  const i = ((l = t.external) == null ? void 0 : l.defs) ?? {};
  for (const h of t.seen.entries()) {
    const m = h[1];
    m.def && m.defId && (m.def.id === m.defId && delete m.def.id, i[m.defId] = m.def);
  }
  t.external || Object.keys(i).length > 0 && (t.target === "draft-2020-12" ? o.$defs = i : o.definitions = i);
  try {
    const h = JSON.parse(JSON.stringify(o));
    return Object.defineProperty(h, "~standard", {
      value: {
        ...e["~standard"],
        jsonSchema: {
          input: xn(e, "input", t.processors),
          output: xn(e, "output", t.processors)
        }
      },
      enumerable: !1,
      writable: !1
    }), h;
  } catch {
    throw new Error("Error converting schema to JSON.");
  }
}
function Ge(t, e) {
  const r = e ?? { seen: /* @__PURE__ */ new Set() };
  if (r.seen.has(t))
    return !1;
  r.seen.add(t);
  const n = t._zod.def;
  if (n.type === "transform")
    return !0;
  if (n.type === "array")
    return Ge(n.element, r);
  if (n.type === "set")
    return Ge(n.valueType, r);
  if (n.type === "lazy")
    return Ge(n.getter(), r);
  if (n.type === "promise" || n.type === "optional" || n.type === "nonoptional" || n.type === "nullable" || n.type === "readonly" || n.type === "default" || n.type === "prefault")
    return Ge(n.innerType, r);
  if (n.type === "intersection")
    return Ge(n.left, r) || Ge(n.right, r);
  if (n.type === "record" || n.type === "map")
    return Ge(n.keyType, r) || Ge(n.valueType, r);
  if (n.type === "pipe")
    return t._zod.traits.has("$ZodCodec") ? !0 : Ge(n.in, r) || Ge(n.out, r);
  if (n.type === "object") {
    for (const o in n.shape)
      if (Ge(n.shape[o], r))
        return !0;
    return !1;
  }
  if (n.type === "union") {
    for (const o of n.options)
      if (Ge(o, r))
        return !0;
    return !1;
  }
  if (n.type === "tuple") {
    for (const o of n.items)
      if (Ge(o, r))
        return !0;
    return !!(n.rest && Ge(n.rest, r));
  }
  return !1;
}
const ph = (t, e = {}) => (r) => {
  const n = Ic({ ...r, processors: e });
  return Ie(t, n), Oc(n, t), zc(n, t);
}, xn = (t, e, r = {}) => (n) => {
  const { libraryOptions: o, target: s } = n ?? {}, i = Ic({ ...o ?? {}, target: s, io: e, processors: r });
  return Ie(t, i), Oc(i, t), zc(i, t);
}, mh = {
  guid: "uuid",
  url: "uri",
  datetime: "date-time",
  json_string: "json-string",
  regex: ""
  // do not set
}, gh = (t, e, r, n) => {
  const o = r;
  o.type = "string";
  const { minimum: s, maximum: i, format: a, patterns: c, contentEncoding: u } = t._zod.bag;
  if (typeof s == "number" && (o.minLength = s), typeof i == "number" && (o.maxLength = i), a && (o.format = mh[a] ?? a, o.format === "" && delete o.format, a === "time" && delete o.format), u && (o.contentEncoding = u), c && c.size > 0) {
    const l = [...c];
    l.length === 1 ? o.pattern = l[0].source : l.length > 1 && (o.allOf = [
      ...l.map((h) => ({
        ...e.target === "draft-07" || e.target === "draft-04" || e.target === "openapi-3.0" ? { type: "string" } : {},
        pattern: h.source
      }))
    ]);
  }
}, _h = (t, e, r, n) => {
  const o = r, { minimum: s, maximum: i, format: a, multipleOf: c, exclusiveMaximum: u, exclusiveMinimum: l } = t._zod.bag;
  typeof a == "string" && a.includes("int") ? o.type = "integer" : o.type = "number";
  const h = typeof l == "number" && l >= (s ?? Number.NEGATIVE_INFINITY), m = typeof u == "number" && u <= (i ?? Number.POSITIVE_INFINITY), _ = e.target === "draft-04" || e.target === "openapi-3.0";
  h ? _ ? (o.minimum = l, o.exclusiveMinimum = !0) : o.exclusiveMinimum = l : typeof s == "number" && (o.minimum = s), m ? _ ? (o.maximum = u, o.exclusiveMaximum = !0) : o.exclusiveMaximum = u : typeof i == "number" && (o.maximum = i), typeof c == "number" && (o.multipleOf = c);
}, yh = (t, e, r, n) => {
  r.type = "boolean";
}, vh = (t, e, r, n) => {
  e.target === "openapi-3.0" ? (r.type = "string", r.nullable = !0, r.enum = [null]) : r.type = "null";
}, wh = (t, e, r, n) => {
  r.not = {};
}, bh = (t, e, r, n) => {
}, $h = (t, e, r, n) => {
}, Sh = (t, e, r, n) => {
  const o = t._zod.def, s = ac(o.entries);
  s.every((i) => typeof i == "number") && (r.type = "number"), s.every((i) => typeof i == "string") && (r.type = "string"), r.enum = s;
}, Eh = (t, e, r, n) => {
  const o = t._zod.def, s = [];
  for (const i of o.values)
    if (i === void 0) {
      if (e.unrepresentable === "throw")
        throw new Error("Literal `undefined` cannot be represented in JSON Schema");
    } else if (typeof i == "bigint") {
      if (e.unrepresentable === "throw")
        throw new Error("BigInt literals cannot be represented in JSON Schema");
      s.push(Number(i));
    } else
      s.push(i);
  if (s.length !== 0) if (s.length === 1) {
    const i = s[0];
    r.type = i === null ? "null" : typeof i, e.target === "draft-04" || e.target === "openapi-3.0" ? r.enum = [i] : r.const = i;
  } else
    s.every((i) => typeof i == "number") && (r.type = "number"), s.every((i) => typeof i == "string") && (r.type = "string"), s.every((i) => typeof i == "boolean") && (r.type = "boolean"), s.every((i) => i === null) && (r.type = "null"), r.enum = s;
}, kh = (t, e, r, n) => {
  if (e.unrepresentable === "throw")
    throw new Error("Custom types cannot be represented in JSON Schema");
}, Ch = (t, e, r, n) => {
  if (e.unrepresentable === "throw")
    throw new Error("Transforms cannot be represented in JSON Schema");
}, Th = (t, e, r, n) => {
  const o = r, s = t._zod.def, { minimum: i, maximum: a } = t._zod.bag;
  typeof i == "number" && (o.minItems = i), typeof a == "number" && (o.maxItems = a), o.type = "array", o.items = Ie(s.element, e, {
    ...n,
    path: [...n.path, "items"]
  });
}, Ph = (t, e, r, n) => {
  var u;
  const o = r, s = t._zod.def;
  o.type = "object", o.properties = {};
  const i = s.shape;
  for (const l in i)
    o.properties[l] = Ie(i[l], e, {
      ...n,
      path: [...n.path, "properties", l]
    });
  const a = new Set(Object.keys(i)), c = new Set([...a].filter((l) => {
    const h = s.shape[l]._zod;
    return e.io === "input" ? h.optin === void 0 : h.optout === void 0;
  }));
  c.size > 0 && (o.required = Array.from(c)), ((u = s.catchall) == null ? void 0 : u._zod.def.type) === "never" ? o.additionalProperties = !1 : s.catchall ? s.catchall && (o.additionalProperties = Ie(s.catchall, e, {
    ...n,
    path: [...n.path, "additionalProperties"]
  })) : e.io === "output" && (o.additionalProperties = !1);
}, Ah = (t, e, r, n) => {
  const o = t._zod.def, s = o.inclusive === !1, i = o.options.map((a, c) => Ie(a, e, {
    ...n,
    path: [...n.path, s ? "oneOf" : "anyOf", c]
  }));
  s ? r.oneOf = i : r.anyOf = i;
}, Rh = (t, e, r, n) => {
  const o = t._zod.def, s = Ie(o.left, e, {
    ...n,
    path: [...n.path, "allOf", 0]
  }), i = Ie(o.right, e, {
    ...n,
    path: [...n.path, "allOf", 1]
  }), a = (u) => "allOf" in u && Object.keys(u).length === 1, c = [
    ...a(s) ? s.allOf : [s],
    ...a(i) ? i.allOf : [i]
  ];
  r.allOf = c;
}, Ih = (t, e, r, n) => {
  const o = r, s = t._zod.def;
  o.type = "object";
  const i = s.keyType, a = i._zod.bag, c = a == null ? void 0 : a.patterns;
  if (s.mode === "loose" && c && c.size > 0) {
    const l = Ie(s.valueType, e, {
      ...n,
      path: [...n.path, "patternProperties", "*"]
    });
    o.patternProperties = {};
    for (const h of c)
      o.patternProperties[h.source] = l;
  } else
    (e.target === "draft-07" || e.target === "draft-2020-12") && (o.propertyNames = Ie(s.keyType, e, {
      ...n,
      path: [...n.path, "propertyNames"]
    })), o.additionalProperties = Ie(s.valueType, e, {
      ...n,
      path: [...n.path, "additionalProperties"]
    });
  const u = i._zod.values;
  if (u) {
    const l = [...u].filter((h) => typeof h == "string" || typeof h == "number");
    l.length > 0 && (o.required = l);
  }
}, Oh = (t, e, r, n) => {
  const o = t._zod.def, s = Ie(o.innerType, e, n), i = e.seen.get(t);
  e.target === "openapi-3.0" ? (i.ref = o.innerType, r.nullable = !0) : r.anyOf = [s, { type: "null" }];
}, zh = (t, e, r, n) => {
  const o = t._zod.def;
  Ie(o.innerType, e, n);
  const s = e.seen.get(t);
  s.ref = o.innerType;
}, Nh = (t, e, r, n) => {
  const o = t._zod.def;
  Ie(o.innerType, e, n);
  const s = e.seen.get(t);
  s.ref = o.innerType, r.default = JSON.parse(JSON.stringify(o.defaultValue));
}, Mh = (t, e, r, n) => {
  const o = t._zod.def;
  Ie(o.innerType, e, n);
  const s = e.seen.get(t);
  s.ref = o.innerType, e.io === "input" && (r._prefault = JSON.parse(JSON.stringify(o.defaultValue)));
}, jh = (t, e, r, n) => {
  const o = t._zod.def;
  Ie(o.innerType, e, n);
  const s = e.seen.get(t);
  s.ref = o.innerType;
  let i;
  try {
    i = o.catchValue(void 0);
  } catch {
    throw new Error("Dynamic catch values are not supported in JSON Schema");
  }
  r.default = i;
}, xh = (t, e, r, n) => {
  const o = t._zod.def, s = o.in._zod.traits.has("$ZodTransform"), i = e.io === "input" ? s ? o.out : o.in : o.out;
  Ie(i, e, n);
  const a = e.seen.get(t);
  a.ref = i;
}, qh = (t, e, r, n) => {
  const o = t._zod.def;
  Ie(o.innerType, e, n);
  const s = e.seen.get(t);
  s.ref = o.innerType, r.readOnly = !0;
}, Nc = (t, e, r, n) => {
  const o = t._zod.def;
  Ie(o.innerType, e, n);
  const s = e.seen.get(t);
  s.ref = o.innerType;
};
function bs(t) {
  return !!t._zod;
}
function Pt(t, e) {
  return bs(t) ? hc(t, e) : t.safeParse(e);
}
function Mc(t) {
  var r, n;
  if (!t)
    return;
  let e;
  if (bs(t) ? e = (n = (r = t._zod) == null ? void 0 : r.def) == null ? void 0 : n.shape : e = t.shape, !!e) {
    if (typeof e == "function")
      try {
        return e();
      } catch {
        return;
      }
    return e;
  }
}
function jc(t) {
  var o;
  if (bs(t)) {
    const i = (o = t._zod) == null ? void 0 : o.def;
    if (i) {
      if (i.value !== void 0)
        return i.value;
      if (Array.isArray(i.values) && i.values.length > 0)
        return i.values[0];
    }
  }
  const r = t._def;
  if (r) {
    if (r.value !== void 0)
      return r.value;
    if (Array.isArray(r.values) && r.values.length > 0)
      return r.values[0];
  }
  const n = t.value;
  if (n !== void 0)
    return n;
}
const Dh = /* @__PURE__ */ q("ZodISODateTime", (t, e) => {
  Od.init(t, e), Ce.init(t, e);
});
function xc(t) {
  return /* @__PURE__ */ Uf(Dh, t);
}
const Uh = /* @__PURE__ */ q("ZodISODate", (t, e) => {
  zd.init(t, e), Ce.init(t, e);
});
function Fh(t) {
  return /* @__PURE__ */ Ff(Uh, t);
}
const Lh = /* @__PURE__ */ q("ZodISOTime", (t, e) => {
  Nd.init(t, e), Ce.init(t, e);
});
function Zh(t) {
  return /* @__PURE__ */ Lf(Lh, t);
}
const Vh = /* @__PURE__ */ q("ZodISODuration", (t, e) => {
  Md.init(t, e), Ce.init(t, e);
});
function Hh(t) {
  return /* @__PURE__ */ Zf(Vh, t);
}
const Wh = (t, e) => {
  dc.init(t, e), t.name = "ZodError", Object.defineProperties(t, {
    format: {
      value: (r) => El(t, r)
      // enumerable: false,
    },
    flatten: {
      value: (r) => Sl(t, r)
      // enumerable: false,
    },
    addIssue: {
      value: (r) => {
        t.issues.push(r), t.message = JSON.stringify(t.issues, qo, 2);
      }
      // enumerable: false,
    },
    addIssues: {
      value: (r) => {
        t.issues.push(...r), t.message = JSON.stringify(t.issues, qo, 2);
      }
      // enumerable: false,
    },
    isEmpty: {
      get() {
        return t.issues.length === 0;
      }
      // enumerable: false,
    }
  });
}, ut = /* @__PURE__ */ q("ZodError", Wh, {
  Parent: Error
}), Bh = /* @__PURE__ */ ys(ut), Gh = /* @__PURE__ */ vs(ut), Kh = /* @__PURE__ */ Qn(ut), Jh = /* @__PURE__ */ Xn(ut), Qh = /* @__PURE__ */ Cl(ut), Xh = /* @__PURE__ */ Tl(ut), Yh = /* @__PURE__ */ Pl(ut), ep = /* @__PURE__ */ Al(ut), tp = /* @__PURE__ */ Rl(ut), rp = /* @__PURE__ */ Il(ut), np = /* @__PURE__ */ Ol(ut), op = /* @__PURE__ */ zl(ut), wi = /* @__PURE__ */ new WeakMap();
function Or(t, e, r) {
  const n = Object.getPrototypeOf(t);
  let o = wi.get(n);
  if (o || (o = /* @__PURE__ */ new Set(), wi.set(n, o)), !o.has(e)) {
    o.add(e);
    for (const s in r) {
      const i = r[s];
      Object.defineProperty(n, s, {
        configurable: !0,
        enumerable: !1,
        get() {
          const a = i.bind(this);
          return Object.defineProperty(this, s, {
            configurable: !0,
            writable: !0,
            enumerable: !0,
            value: a
          }), a;
        },
        set(a) {
          Object.defineProperty(this, s, {
            configurable: !0,
            writable: !0,
            enumerable: !0,
            value: a
          });
        }
      });
    }
  }
}
const we = /* @__PURE__ */ q("ZodType", (t, e) => (ve.init(t, e), Object.assign(t["~standard"], {
  jsonSchema: {
    input: xn(t, "input"),
    output: xn(t, "output")
  }
}), t.toJSONSchema = ph(t, {}), t.def = e, t.type = e.type, Object.defineProperty(t, "_def", { value: e }), t.parse = (r, n) => Bh(t, r, n, { callee: t.parse }), t.safeParse = (r, n) => Kh(t, r, n), t.parseAsync = async (r, n) => Gh(t, r, n, { callee: t.parseAsync }), t.safeParseAsync = async (r, n) => Jh(t, r, n), t.spa = t.safeParseAsync, t.encode = (r, n) => Qh(t, r, n), t.decode = (r, n) => Xh(t, r, n), t.encodeAsync = async (r, n) => Yh(t, r, n), t.decodeAsync = async (r, n) => ep(t, r, n), t.safeEncode = (r, n) => tp(t, r, n), t.safeDecode = (r, n) => rp(t, r, n), t.safeEncodeAsync = async (r, n) => np(t, r, n), t.safeDecodeAsync = async (r, n) => op(t, r, n), Or(t, "ZodType", {
  check(...r) {
    const n = this.def;
    return this.clone(It(n, {
      checks: [
        ...n.checks ?? [],
        ...r.map((o) => typeof o == "function" ? { _zod: { check: o, def: { check: "custom" }, onattach: [] } } : o)
      ]
    }), { parent: !0 });
  },
  with(...r) {
    return this.check(...r);
  },
  clone(r, n) {
    return Ot(this, r, n);
  },
  brand() {
    return this;
  },
  register(r, n) {
    return r.add(this, n), this;
  },
  refine(r, n) {
    return this.check(Qp(r, n));
  },
  superRefine(r, n) {
    return this.check(Xp(r, n));
  },
  overwrite(r) {
    return this.check(/* @__PURE__ */ pr(r));
  },
  optional() {
    return Ee(this);
  },
  exactOptional() {
    return qp(this);
  },
  nullable() {
    return Ei(this);
  },
  nullish() {
    return Ee(Ei(this));
  },
  nonoptional(r) {
    return Vp(this, r);
  },
  array() {
    return H(this);
  },
  or(r) {
    return Se([this, r]);
  },
  and(r) {
    return Ss(this, r);
  },
  transform(r) {
    return ki(this, Zc(r));
  },
  default(r) {
    return Fp(this, r);
  },
  prefault(r) {
    return Zp(this, r);
  },
  catch(r) {
    return Wp(this, r);
  },
  pipe(r) {
    return ki(this, r);
  },
  readonly() {
    return Kp(this);
  },
  describe(r) {
    const n = this.clone();
    return wr.add(n, { description: r }), n;
  },
  meta(...r) {
    if (r.length === 0)
      return wr.get(this);
    const n = this.clone();
    return wr.add(n, r[0]), n;
  },
  isOptional() {
    return this.safeParse(void 0).success;
  },
  isNullable() {
    return this.safeParse(null).success;
  },
  apply(r) {
    return r(this);
  }
}), Object.defineProperty(t, "description", {
  get() {
    var r;
    return (r = wr.get(t)) == null ? void 0 : r.description;
  },
  configurable: !0
}), t)), qc = /* @__PURE__ */ q("_ZodString", (t, e) => {
  ws.init(t, e), we.init(t, e), t._zod.processJSONSchema = (n, o, s) => gh(t, n, o);
  const r = t._zod.bag;
  t.format = r.format ?? null, t.minLength = r.minimum ?? null, t.maxLength = r.maximum ?? null, Or(t, "_ZodString", {
    regex(...n) {
      return this.check(/* @__PURE__ */ Xf(...n));
    },
    includes(...n) {
      return this.check(/* @__PURE__ */ th(...n));
    },
    startsWith(...n) {
      return this.check(/* @__PURE__ */ rh(...n));
    },
    endsWith(...n) {
      return this.check(/* @__PURE__ */ nh(...n));
    },
    min(...n) {
      return this.check(/* @__PURE__ */ jn(...n));
    },
    max(...n) {
      return this.check(/* @__PURE__ */ Ac(...n));
    },
    length(...n) {
      return this.check(/* @__PURE__ */ Rc(...n));
    },
    nonempty(...n) {
      return this.check(/* @__PURE__ */ jn(1, ...n));
    },
    lowercase(n) {
      return this.check(/* @__PURE__ */ Yf(n));
    },
    uppercase(n) {
      return this.check(/* @__PURE__ */ eh(n));
    },
    trim() {
      return this.check(/* @__PURE__ */ sh());
    },
    normalize(...n) {
      return this.check(/* @__PURE__ */ oh(...n));
    },
    toLowerCase() {
      return this.check(/* @__PURE__ */ ih());
    },
    toUpperCase() {
      return this.check(/* @__PURE__ */ ah());
    },
    slugify() {
      return this.check(/* @__PURE__ */ ch());
    }
  });
}), sp = /* @__PURE__ */ q("ZodString", (t, e) => {
  ws.init(t, e), qc.init(t, e), t.email = (r) => t.check(/* @__PURE__ */ wf(ip, r)), t.url = (r) => t.check(/* @__PURE__ */ Pc(Dc, r)), t.jwt = (r) => t.check(/* @__PURE__ */ Df($p, r)), t.emoji = (r) => t.check(/* @__PURE__ */ kf(cp, r)), t.guid = (r) => t.check(/* @__PURE__ */ gi(bi, r)), t.uuid = (r) => t.check(/* @__PURE__ */ bf(Lr, r)), t.uuidv4 = (r) => t.check(/* @__PURE__ */ $f(Lr, r)), t.uuidv6 = (r) => t.check(/* @__PURE__ */ Sf(Lr, r)), t.uuidv7 = (r) => t.check(/* @__PURE__ */ Ef(Lr, r)), t.nanoid = (r) => t.check(/* @__PURE__ */ Cf(up, r)), t.guid = (r) => t.check(/* @__PURE__ */ gi(bi, r)), t.cuid = (r) => t.check(/* @__PURE__ */ Tf(lp, r)), t.cuid2 = (r) => t.check(/* @__PURE__ */ Pf(dp, r)), t.ulid = (r) => t.check(/* @__PURE__ */ Af(fp, r)), t.base64 = (r) => t.check(/* @__PURE__ */ jf(vp, r)), t.base64url = (r) => t.check(/* @__PURE__ */ xf(wp, r)), t.xid = (r) => t.check(/* @__PURE__ */ Rf(hp, r)), t.ksuid = (r) => t.check(/* @__PURE__ */ If(pp, r)), t.ipv4 = (r) => t.check(/* @__PURE__ */ Of(mp, r)), t.ipv6 = (r) => t.check(/* @__PURE__ */ zf(gp, r)), t.cidrv4 = (r) => t.check(/* @__PURE__ */ Nf(_p, r)), t.cidrv6 = (r) => t.check(/* @__PURE__ */ Mf(yp, r)), t.e164 = (r) => t.check(/* @__PURE__ */ qf(bp, r)), t.datetime = (r) => t.check(xc(r)), t.date = (r) => t.check(Fh(r)), t.time = (r) => t.check(Zh(r)), t.duration = (r) => t.check(Hh(r));
});
function C(t) {
  return /* @__PURE__ */ vf(sp, t);
}
const Ce = /* @__PURE__ */ q("ZodStringFormat", (t, e) => {
  $e.init(t, e), qc.init(t, e);
}), ip = /* @__PURE__ */ q("ZodEmail", (t, e) => {
  Sd.init(t, e), Ce.init(t, e);
}), bi = /* @__PURE__ */ q("ZodGUID", (t, e) => {
  bd.init(t, e), Ce.init(t, e);
}), Lr = /* @__PURE__ */ q("ZodUUID", (t, e) => {
  $d.init(t, e), Ce.init(t, e);
}), Dc = /* @__PURE__ */ q("ZodURL", (t, e) => {
  Ed.init(t, e), Ce.init(t, e);
});
function ap(t) {
  return /* @__PURE__ */ Pc(Dc, t);
}
const cp = /* @__PURE__ */ q("ZodEmoji", (t, e) => {
  kd.init(t, e), Ce.init(t, e);
}), up = /* @__PURE__ */ q("ZodNanoID", (t, e) => {
  Cd.init(t, e), Ce.init(t, e);
}), lp = /* @__PURE__ */ q("ZodCUID", (t, e) => {
  Td.init(t, e), Ce.init(t, e);
}), dp = /* @__PURE__ */ q("ZodCUID2", (t, e) => {
  Pd.init(t, e), Ce.init(t, e);
}), fp = /* @__PURE__ */ q("ZodULID", (t, e) => {
  Ad.init(t, e), Ce.init(t, e);
}), hp = /* @__PURE__ */ q("ZodXID", (t, e) => {
  Rd.init(t, e), Ce.init(t, e);
}), pp = /* @__PURE__ */ q("ZodKSUID", (t, e) => {
  Id.init(t, e), Ce.init(t, e);
}), mp = /* @__PURE__ */ q("ZodIPv4", (t, e) => {
  jd.init(t, e), Ce.init(t, e);
}), gp = /* @__PURE__ */ q("ZodIPv6", (t, e) => {
  xd.init(t, e), Ce.init(t, e);
}), _p = /* @__PURE__ */ q("ZodCIDRv4", (t, e) => {
  qd.init(t, e), Ce.init(t, e);
}), yp = /* @__PURE__ */ q("ZodCIDRv6", (t, e) => {
  Dd.init(t, e), Ce.init(t, e);
}), vp = /* @__PURE__ */ q("ZodBase64", (t, e) => {
  Ud.init(t, e), Ce.init(t, e);
}), wp = /* @__PURE__ */ q("ZodBase64URL", (t, e) => {
  Ld.init(t, e), Ce.init(t, e);
}), bp = /* @__PURE__ */ q("ZodE164", (t, e) => {
  Zd.init(t, e), Ce.init(t, e);
}), $p = /* @__PURE__ */ q("ZodJWT", (t, e) => {
  Hd.init(t, e), Ce.init(t, e);
}), $s = /* @__PURE__ */ q("ZodNumber", (t, e) => {
  $c.init(t, e), we.init(t, e), t._zod.processJSONSchema = (n, o, s) => _h(t, n, o), Or(t, "ZodNumber", {
    gt(n, o) {
      return this.check(/* @__PURE__ */ yi(n, o));
    },
    gte(n, o) {
      return this.check(/* @__PURE__ */ go(n, o));
    },
    min(n, o) {
      return this.check(/* @__PURE__ */ go(n, o));
    },
    lt(n, o) {
      return this.check(/* @__PURE__ */ _i(n, o));
    },
    lte(n, o) {
      return this.check(/* @__PURE__ */ mo(n, o));
    },
    max(n, o) {
      return this.check(/* @__PURE__ */ mo(n, o));
    },
    int(n) {
      return this.check($i(n));
    },
    safe(n) {
      return this.check($i(n));
    },
    positive(n) {
      return this.check(/* @__PURE__ */ yi(0, n));
    },
    nonnegative(n) {
      return this.check(/* @__PURE__ */ go(0, n));
    },
    negative(n) {
      return this.check(/* @__PURE__ */ _i(0, n));
    },
    nonpositive(n) {
      return this.check(/* @__PURE__ */ mo(0, n));
    },
    multipleOf(n, o) {
      return this.check(/* @__PURE__ */ vi(n, o));
    },
    step(n, o) {
      return this.check(/* @__PURE__ */ vi(n, o));
    },
    finite() {
      return this;
    }
  });
  const r = t._zod.bag;
  t.minValue = Math.max(r.minimum ?? Number.NEGATIVE_INFINITY, r.exclusiveMinimum ?? Number.NEGATIVE_INFINITY) ?? null, t.maxValue = Math.min(r.maximum ?? Number.POSITIVE_INFINITY, r.exclusiveMaximum ?? Number.POSITIVE_INFINITY) ?? null, t.isInt = (r.format ?? "").includes("int") || Number.isSafeInteger(r.multipleOf ?? 0.5), t.isFinite = !0, t.format = r.format ?? null;
});
function pe(t) {
  return /* @__PURE__ */ Vf($s, t);
}
const Sp = /* @__PURE__ */ q("ZodNumberFormat", (t, e) => {
  Wd.init(t, e), $s.init(t, e);
});
function $i(t) {
  return /* @__PURE__ */ Wf(Sp, t);
}
const Ep = /* @__PURE__ */ q("ZodBoolean", (t, e) => {
  Bd.init(t, e), we.init(t, e), t._zod.processJSONSchema = (r, n, o) => yh(t, r, n);
});
function _e(t) {
  return /* @__PURE__ */ Bf(Ep, t);
}
const kp = /* @__PURE__ */ q("ZodNull", (t, e) => {
  Gd.init(t, e), we.init(t, e), t._zod.processJSONSchema = (r, n, o) => vh(t, r, n);
});
function Cp(t) {
  return /* @__PURE__ */ Gf(kp, t);
}
const Tp = /* @__PURE__ */ q("ZodAny", (t, e) => {
  Kd.init(t, e), we.init(t, e), t._zod.processJSONSchema = (r, n, o) => bh();
});
function Pp() {
  return /* @__PURE__ */ Kf(Tp);
}
const Ap = /* @__PURE__ */ q("ZodUnknown", (t, e) => {
  Jd.init(t, e), we.init(t, e), t._zod.processJSONSchema = (r, n, o) => $h();
});
function ke() {
  return /* @__PURE__ */ Jf(Ap);
}
const Rp = /* @__PURE__ */ q("ZodNever", (t, e) => {
  Qd.init(t, e), we.init(t, e), t._zod.processJSONSchema = (r, n, o) => wh(t, r, n);
});
function Ip(t) {
  return /* @__PURE__ */ Qf(Rp, t);
}
const Op = /* @__PURE__ */ q("ZodArray", (t, e) => {
  Xd.init(t, e), we.init(t, e), t._zod.processJSONSchema = (r, n, o) => Th(t, r, n, o), t.element = e.element, Or(t, "ZodArray", {
    min(r, n) {
      return this.check(/* @__PURE__ */ jn(r, n));
    },
    nonempty(r) {
      return this.check(/* @__PURE__ */ jn(1, r));
    },
    max(r, n) {
      return this.check(/* @__PURE__ */ Ac(r, n));
    },
    length(r, n) {
      return this.check(/* @__PURE__ */ Rc(r, n));
    },
    unwrap() {
      return this.element;
    }
  });
});
function H(t, e) {
  return /* @__PURE__ */ uh(Op, t, e);
}
const Uc = /* @__PURE__ */ q("ZodObject", (t, e) => {
  ef.init(t, e), we.init(t, e), t._zod.processJSONSchema = (r, n, o) => Ph(t, r, n, o), ge(t, "shape", () => e.shape), Or(t, "ZodObject", {
    keyof() {
      return ot(Object.keys(this._zod.def.shape));
    },
    catchall(r) {
      return this.clone({ ...this._zod.def, catchall: r });
    },
    passthrough() {
      return this.clone({ ...this._zod.def, catchall: ke() });
    },
    loose() {
      return this.clone({ ...this._zod.def, catchall: ke() });
    },
    strict() {
      return this.clone({ ...this._zod.def, catchall: Ip() });
    },
    strip() {
      return this.clone({ ...this._zod.def, catchall: void 0 });
    },
    extend(r) {
      return _l(this, r);
    },
    safeExtend(r) {
      return yl(this, r);
    },
    merge(r) {
      return vl(this, r);
    },
    pick(r) {
      return ml(this, r);
    },
    omit(r) {
      return gl(this, r);
    },
    partial(...r) {
      return wl(Vc, this, r[0]);
    },
    required(...r) {
      return bl(Hc, this, r[0]);
    }
  });
});
function W(t, e) {
  const r = {
    type: "object",
    shape: t ?? {},
    ...K(e)
  };
  return new Uc(r);
}
function Fe(t, e) {
  return new Uc({
    type: "object",
    shape: t,
    catchall: ke(),
    ...K(e)
  });
}
const Fc = /* @__PURE__ */ q("ZodUnion", (t, e) => {
  kc.init(t, e), we.init(t, e), t._zod.processJSONSchema = (r, n, o) => Ah(t, r, n, o), t.options = e.options;
});
function Se(t, e) {
  return new Fc({
    type: "union",
    options: t,
    ...K(e)
  });
}
const zp = /* @__PURE__ */ q("ZodDiscriminatedUnion", (t, e) => {
  Fc.init(t, e), tf.init(t, e);
});
function Lc(t, e, r) {
  return new zp({
    type: "union",
    options: e,
    discriminator: t,
    ...K(r)
  });
}
const Np = /* @__PURE__ */ q("ZodIntersection", (t, e) => {
  rf.init(t, e), we.init(t, e), t._zod.processJSONSchema = (r, n, o) => Rh(t, r, n, o);
});
function Ss(t, e) {
  return new Np({
    type: "intersection",
    left: t,
    right: e
  });
}
const Si = /* @__PURE__ */ q("ZodRecord", (t, e) => {
  nf.init(t, e), we.init(t, e), t._zod.processJSONSchema = (r, n, o) => Ih(t, r, n, o), t.keyType = e.keyType, t.valueType = e.valueType;
});
function ye(t, e, r) {
  return !e || !e._zod ? new Si({
    type: "record",
    keyType: C(),
    valueType: t,
    ...K(e)
  }) : new Si({
    type: "record",
    keyType: t,
    valueType: e,
    ...K(r)
  });
}
const Uo = /* @__PURE__ */ q("ZodEnum", (t, e) => {
  of.init(t, e), we.init(t, e), t._zod.processJSONSchema = (n, o, s) => Sh(t, n, o), t.enum = e.entries, t.options = Object.values(e.entries);
  const r = new Set(Object.keys(e.entries));
  t.extract = (n, o) => {
    const s = {};
    for (const i of n)
      if (r.has(i))
        s[i] = e.entries[i];
      else
        throw new Error(`Key ${i} not found in enum`);
    return new Uo({
      ...e,
      checks: [],
      ...K(o),
      entries: s
    });
  }, t.exclude = (n, o) => {
    const s = { ...e.entries };
    for (const i of n)
      if (r.has(i))
        delete s[i];
      else
        throw new Error(`Key ${i} not found in enum`);
    return new Uo({
      ...e,
      checks: [],
      ...K(o),
      entries: s
    });
  };
});
function ot(t, e) {
  const r = Array.isArray(t) ? Object.fromEntries(t.map((n) => [n, n])) : t;
  return new Uo({
    type: "enum",
    entries: r,
    ...K(e)
  });
}
const Mp = /* @__PURE__ */ q("ZodLiteral", (t, e) => {
  sf.init(t, e), we.init(t, e), t._zod.processJSONSchema = (r, n, o) => Eh(t, r, n), t.values = new Set(e.values), Object.defineProperty(t, "value", {
    get() {
      if (e.values.length > 1)
        throw new Error("This schema contains multiple valid literal values. Use `.values` instead.");
      return e.values[0];
    }
  });
});
function Q(t, e) {
  return new Mp({
    type: "literal",
    values: Array.isArray(t) ? t : [t],
    ...K(e)
  });
}
const jp = /* @__PURE__ */ q("ZodTransform", (t, e) => {
  af.init(t, e), we.init(t, e), t._zod.processJSONSchema = (r, n, o) => Ch(t, r), t._zod.parse = (r, n) => {
    if (n.direction === "backward")
      throw new ic(t.constructor.name);
    r.addIssue = (s) => {
      if (typeof s == "string")
        r.issues.push(Ar(s, r.value, e));
      else {
        const i = s;
        i.fatal && (i.continue = !1), i.code ?? (i.code = "custom"), i.input ?? (i.input = r.value), i.inst ?? (i.inst = t), r.issues.push(Ar(i));
      }
    };
    const o = e.transform(r.value, r);
    return o instanceof Promise ? o.then((s) => (r.value = s, r.fallback = !0, r)) : (r.value = o, r.fallback = !0, r);
  };
});
function Zc(t) {
  return new jp({
    type: "transform",
    transform: t
  });
}
const Vc = /* @__PURE__ */ q("ZodOptional", (t, e) => {
  Cc.init(t, e), we.init(t, e), t._zod.processJSONSchema = (r, n, o) => Nc(t, r, n, o), t.unwrap = () => t._zod.def.innerType;
});
function Ee(t) {
  return new Vc({
    type: "optional",
    innerType: t
  });
}
const xp = /* @__PURE__ */ q("ZodExactOptional", (t, e) => {
  cf.init(t, e), we.init(t, e), t._zod.processJSONSchema = (r, n, o) => Nc(t, r, n, o), t.unwrap = () => t._zod.def.innerType;
});
function qp(t) {
  return new xp({
    type: "optional",
    innerType: t
  });
}
const Dp = /* @__PURE__ */ q("ZodNullable", (t, e) => {
  uf.init(t, e), we.init(t, e), t._zod.processJSONSchema = (r, n, o) => Oh(t, r, n, o), t.unwrap = () => t._zod.def.innerType;
});
function Ei(t) {
  return new Dp({
    type: "nullable",
    innerType: t
  });
}
const Up = /* @__PURE__ */ q("ZodDefault", (t, e) => {
  lf.init(t, e), we.init(t, e), t._zod.processJSONSchema = (r, n, o) => Nh(t, r, n, o), t.unwrap = () => t._zod.def.innerType, t.removeDefault = t.unwrap;
});
function Fp(t, e) {
  return new Up({
    type: "default",
    innerType: t,
    get defaultValue() {
      return typeof e == "function" ? e() : uc(e);
    }
  });
}
const Lp = /* @__PURE__ */ q("ZodPrefault", (t, e) => {
  df.init(t, e), we.init(t, e), t._zod.processJSONSchema = (r, n, o) => Mh(t, r, n, o), t.unwrap = () => t._zod.def.innerType;
});
function Zp(t, e) {
  return new Lp({
    type: "prefault",
    innerType: t,
    get defaultValue() {
      return typeof e == "function" ? e() : uc(e);
    }
  });
}
const Hc = /* @__PURE__ */ q("ZodNonOptional", (t, e) => {
  ff.init(t, e), we.init(t, e), t._zod.processJSONSchema = (r, n, o) => zh(t, r, n, o), t.unwrap = () => t._zod.def.innerType;
});
function Vp(t, e) {
  return new Hc({
    type: "nonoptional",
    innerType: t,
    ...K(e)
  });
}
const Hp = /* @__PURE__ */ q("ZodCatch", (t, e) => {
  hf.init(t, e), we.init(t, e), t._zod.processJSONSchema = (r, n, o) => jh(t, r, n, o), t.unwrap = () => t._zod.def.innerType, t.removeCatch = t.unwrap;
});
function Wp(t, e) {
  return new Hp({
    type: "catch",
    innerType: t,
    catchValue: typeof e == "function" ? e : () => e
  });
}
const Wc = /* @__PURE__ */ q("ZodPipe", (t, e) => {
  Tc.init(t, e), we.init(t, e), t._zod.processJSONSchema = (r, n, o) => xh(t, r, n, o), t.in = e.in, t.out = e.out;
});
function ki(t, e) {
  return new Wc({
    type: "pipe",
    in: t,
    out: e
    // ...util.normalizeParams(params),
  });
}
const Bp = /* @__PURE__ */ q("ZodPreprocess", (t, e) => {
  Wc.init(t, e), pf.init(t, e);
}), Gp = /* @__PURE__ */ q("ZodReadonly", (t, e) => {
  mf.init(t, e), we.init(t, e), t._zod.processJSONSchema = (r, n, o) => qh(t, r, n, o), t.unwrap = () => t._zod.def.innerType;
});
function Kp(t) {
  return new Gp({
    type: "readonly",
    innerType: t
  });
}
const Bc = /* @__PURE__ */ q("ZodCustom", (t, e) => {
  gf.init(t, e), we.init(t, e), t._zod.processJSONSchema = (r, n, o) => kh(t, r);
});
function Jp(t, e) {
  return /* @__PURE__ */ lh(Bc, t ?? (() => !0), e);
}
function Qp(t, e = {}) {
  return /* @__PURE__ */ dh(Bc, t, e);
}
function Xp(t, e) {
  return /* @__PURE__ */ fh(t, e);
}
function Gc(t, e) {
  return new Bp({
    type: "pipe",
    in: Zc(t),
    out: e
  });
}
const Yp = {
  custom: "custom"
};
function em(t) {
  return /* @__PURE__ */ Hf($s, t);
}
const eo = "2025-11-25", tm = [eo, "2025-06-18", "2025-03-26", "2024-11-05", "2024-10-07"], Ut = "io.modelcontextprotocol/related-task", to = "2.0", Ne = Jp((t) => t !== null && (typeof t == "object" || typeof t == "function")), Kc = Se([C(), pe().int()]), Jc = C();
Fe({
  /**
   * Requested duration in milliseconds to retain task from creation.
   */
  ttl: pe().optional(),
  /**
   * Time in milliseconds to wait between task status requests.
   */
  pollInterval: pe().optional()
});
const rm = W({
  ttl: pe().optional()
}), nm = W({
  taskId: C()
}), Es = Fe({
  /**
   * If specified, the caller is requesting out-of-band progress notifications for this request (as represented by notifications/progress). The value of this parameter is an opaque token that will be attached to any subsequent notifications. The receiver is not obligated to provide these notifications.
   */
  progressToken: Kc.optional(),
  /**
   * If specified, this request is related to the provided task.
   */
  [Ut]: nm.optional()
}), st = W({
  /**
   * See [General fields: `_meta`](/specification/draft/basic/index#meta) for notes on `_meta` usage.
   */
  _meta: Es.optional()
}), zr = st.extend({
  /**
   * If specified, the caller is requesting task-augmented execution for this request.
   * The request will return a CreateTaskResult immediately, and the actual result can be
   * retrieved later via tasks/result.
   *
   * Task augmentation is subject to capability negotiation - receivers MUST declare support
   * for task augmentation of specific request types in their capabilities.
   */
  task: rm.optional()
}), om = (t) => zr.safeParse(t).success, Le = W({
  method: C(),
  params: st.loose().optional()
}), lt = W({
  /**
   * See [MCP specification](https://github.com/modelcontextprotocol/modelcontextprotocol/blob/47339c03c143bb4ec01a26e721a1b8fe66634ebe/docs/specification/draft/basic/index.mdx#general-fields)
   * for notes on _meta usage.
   */
  _meta: Es.optional()
}), dt = W({
  method: C(),
  params: lt.loose().optional()
}), Ze = Fe({
  /**
   * See [MCP specification](https://github.com/modelcontextprotocol/modelcontextprotocol/blob/47339c03c143bb4ec01a26e721a1b8fe66634ebe/docs/specification/draft/basic/index.mdx#general-fields)
   * for notes on _meta usage.
   */
  _meta: Es.optional()
}), ro = Se([C(), pe().int()]), Qc = W({
  jsonrpc: Q(to),
  id: ro,
  ...Le.shape
}).strict(), Fo = (t) => Qc.safeParse(t).success, Xc = W({
  jsonrpc: Q(to),
  ...dt.shape
}).strict(), sm = (t) => Xc.safeParse(t).success, ks = W({
  jsonrpc: Q(to),
  id: ro,
  result: Ze
}).strict(), br = (t) => ks.safeParse(t).success;
var oe;
(function(t) {
  t[t.ConnectionClosed = -32e3] = "ConnectionClosed", t[t.RequestTimeout = -32001] = "RequestTimeout", t[t.ParseError = -32700] = "ParseError", t[t.InvalidRequest = -32600] = "InvalidRequest", t[t.MethodNotFound = -32601] = "MethodNotFound", t[t.InvalidParams = -32602] = "InvalidParams", t[t.InternalError = -32603] = "InternalError", t[t.UrlElicitationRequired = -32042] = "UrlElicitationRequired";
})(oe || (oe = {}));
const Cs = W({
  jsonrpc: Q(to),
  id: ro.optional(),
  error: W({
    /**
     * The error type that occurred.
     */
    code: pe().int(),
    /**
     * A short description of the error. The message SHOULD be limited to a concise single sentence.
     */
    message: C(),
    /**
     * Additional information about the error. The value of this member is defined by the sender (e.g. detailed error information, nested errors etc.).
     */
    data: ke().optional()
  })
}).strict(), im = (t) => Cs.safeParse(t).success, In = Se([
  Qc,
  Xc,
  ks,
  Cs
]);
Se([ks, Cs]);
const or = Ze.strict(), am = lt.extend({
  /**
   * The ID of the request to cancel.
   *
   * This MUST correspond to the ID of a request previously issued in the same direction.
   */
  requestId: ro.optional(),
  /**
   * An optional string describing the reason for the cancellation. This MAY be logged or presented to the user.
   */
  reason: C().optional()
}), Ts = dt.extend({
  method: Q("notifications/cancelled"),
  params: am
}), cm = W({
  /**
   * URL or data URI for the icon.
   */
  src: C(),
  /**
   * Optional MIME type for the icon.
   */
  mimeType: C().optional(),
  /**
   * Optional array of strings that specify sizes at which the icon can be used.
   * Each string should be in WxH format (e.g., `"48x48"`, `"96x96"`) or `"any"` for scalable formats like SVG.
   *
   * If not provided, the client should assume that the icon can be used at any size.
   */
  sizes: H(C()).optional(),
  /**
   * Optional specifier for the theme this icon is designed for. `light` indicates
   * the icon is designed to be used with a light background, and `dark` indicates
   * the icon is designed to be used with a dark background.
   *
   * If not provided, the client should assume the icon can be used with any theme.
   */
  theme: ot(["light", "dark"]).optional()
}), Nr = W({
  /**
   * Optional set of sized icons that the client can display in a user interface.
   *
   * Clients that support rendering icons MUST support at least the following MIME types:
   * - `image/png` - PNG images (safe, universal compatibility)
   * - `image/jpeg` (and `image/jpg`) - JPEG images (safe, universal compatibility)
   *
   * Clients that support rendering icons SHOULD also support:
   * - `image/svg+xml` - SVG images (scalable but requires security precautions)
   * - `image/webp` - WebP images (modern, efficient format)
   */
  icons: H(cm).optional()
}), fr = W({
  /** Intended for programmatic or logical use, but used as a display name in past specs or fallback */
  name: C(),
  /**
   * Intended for UI and end-user contexts — optimized to be human-readable and easily understood,
   * even by those unfamiliar with domain-specific terminology.
   *
   * If not provided, the name should be used for display (except for Tool,
   * where `annotations.title` should be given precedence over using `name`,
   * if present).
   */
  title: C().optional()
}), Yc = fr.extend({
  ...fr.shape,
  ...Nr.shape,
  version: C(),
  /**
   * An optional URL of the website for this implementation.
   */
  websiteUrl: C().optional(),
  /**
   * An optional human-readable description of what this implementation does.
   *
   * This can be used by clients or servers to provide context about their purpose
   * and capabilities. For example, a server might describe the types of resources
   * or tools it provides, while a client might describe its intended use case.
   */
  description: C().optional()
}), um = Ss(W({
  applyDefaults: _e().optional()
}), ye(C(), ke())), lm = Gc((t) => t && typeof t == "object" && !Array.isArray(t) && Object.keys(t).length === 0 ? { form: {} } : t, Ss(W({
  form: um.optional(),
  url: Ne.optional()
}), ye(C(), ke()).optional())), dm = Fe({
  /**
   * Present if the client supports listing tasks.
   */
  list: Ne.optional(),
  /**
   * Present if the client supports cancelling tasks.
   */
  cancel: Ne.optional(),
  /**
   * Capabilities for task creation on specific request types.
   */
  requests: Fe({
    /**
     * Task support for sampling requests.
     */
    sampling: Fe({
      createMessage: Ne.optional()
    }).optional(),
    /**
     * Task support for elicitation requests.
     */
    elicitation: Fe({
      create: Ne.optional()
    }).optional()
  }).optional()
}), fm = Fe({
  /**
   * Present if the server supports listing tasks.
   */
  list: Ne.optional(),
  /**
   * Present if the server supports cancelling tasks.
   */
  cancel: Ne.optional(),
  /**
   * Capabilities for task creation on specific request types.
   */
  requests: Fe({
    /**
     * Task support for tool requests.
     */
    tools: Fe({
      call: Ne.optional()
    }).optional()
  }).optional()
}), hm = W({
  /**
   * Experimental, non-standard capabilities that the client supports.
   */
  experimental: ye(C(), Ne).optional(),
  /**
   * Present if the client supports sampling from an LLM.
   */
  sampling: W({
    /**
     * Present if the client supports context inclusion via includeContext parameter.
     * If not declared, servers SHOULD only use `includeContext: "none"` (or omit it).
     */
    context: Ne.optional(),
    /**
     * Present if the client supports tool use via tools and toolChoice parameters.
     */
    tools: Ne.optional()
  }).optional(),
  /**
   * Present if the client supports eliciting user input.
   */
  elicitation: lm.optional(),
  /**
   * Present if the client supports listing roots.
   */
  roots: W({
    /**
     * Whether the client supports issuing notifications for changes to the roots list.
     */
    listChanged: _e().optional()
  }).optional(),
  /**
   * Present if the client supports task creation.
   */
  tasks: dm.optional(),
  /**
   * Extensions that the client supports. Keys are extension identifiers (vendor-prefix/extension-name).
   */
  extensions: ye(C(), Ne).optional()
}), pm = st.extend({
  /**
   * The latest version of the Model Context Protocol that the client supports. The client MAY decide to support older versions as well.
   */
  protocolVersion: C(),
  capabilities: hm,
  clientInfo: Yc
}), mm = Le.extend({
  method: Q("initialize"),
  params: pm
}), gm = W({
  /**
   * Experimental, non-standard capabilities that the server supports.
   */
  experimental: ye(C(), Ne).optional(),
  /**
   * Present if the server supports sending log messages to the client.
   */
  logging: Ne.optional(),
  /**
   * Present if the server supports sending completions to the client.
   */
  completions: Ne.optional(),
  /**
   * Present if the server offers any prompt templates.
   */
  prompts: W({
    /**
     * Whether this server supports issuing notifications for changes to the prompt list.
     */
    listChanged: _e().optional()
  }).optional(),
  /**
   * Present if the server offers any resources to read.
   */
  resources: W({
    /**
     * Whether this server supports clients subscribing to resource updates.
     */
    subscribe: _e().optional(),
    /**
     * Whether this server supports issuing notifications for changes to the resource list.
     */
    listChanged: _e().optional()
  }).optional(),
  /**
   * Present if the server offers any tools to call.
   */
  tools: W({
    /**
     * Whether this server supports issuing notifications for changes to the tool list.
     */
    listChanged: _e().optional()
  }).optional(),
  /**
   * Present if the server supports task creation.
   */
  tasks: fm.optional(),
  /**
   * Extensions that the server supports. Keys are extension identifiers (vendor-prefix/extension-name).
   */
  extensions: ye(C(), Ne).optional()
}), eu = Ze.extend({
  /**
   * The version of the Model Context Protocol that the server wants to use. This may not match the version that the client requested. If the client cannot support this version, it MUST disconnect.
   */
  protocolVersion: C(),
  capabilities: gm,
  serverInfo: Yc,
  /**
   * Instructions describing how to use the server and its features.
   *
   * This can be used by clients to improve the LLM's understanding of available tools, resources, etc. It can be thought of like a "hint" to the model. For example, this information MAY be added to the system prompt.
   */
  instructions: C().optional()
}), tu = dt.extend({
  method: Q("notifications/initialized"),
  params: lt.optional()
}), _m = (t) => tu.safeParse(t).success, Ps = Le.extend({
  method: Q("ping"),
  params: st.optional()
}), ym = W({
  /**
   * The progress thus far. This should increase every time progress is made, even if the total is unknown.
   */
  progress: pe(),
  /**
   * Total number of items to process (or total progress required), if known.
   */
  total: Ee(pe()),
  /**
   * An optional message describing the current progress.
   */
  message: Ee(C())
}), vm = W({
  ...lt.shape,
  ...ym.shape,
  /**
   * The progress token which was given in the initial request, used to associate this notification with the request that is proceeding.
   */
  progressToken: Kc
}), As = dt.extend({
  method: Q("notifications/progress"),
  params: vm
}), wm = st.extend({
  /**
   * An opaque token representing the current pagination position.
   * If provided, the server should return results starting after this cursor.
   */
  cursor: Jc.optional()
}), Mr = Le.extend({
  params: wm.optional()
}), jr = Ze.extend({
  /**
   * An opaque token representing the pagination position after the last returned result.
   * If present, there may be more results available.
   */
  nextCursor: Jc.optional()
}), bm = ot(["working", "input_required", "completed", "failed", "cancelled"]), xr = W({
  taskId: C(),
  status: bm,
  /**
   * Time in milliseconds to keep task results available after completion.
   * If null, the task has unlimited lifetime until manually cleaned up.
   */
  ttl: Se([pe(), Cp()]),
  /**
   * ISO 8601 timestamp when the task was created.
   */
  createdAt: C(),
  /**
   * ISO 8601 timestamp when the task was last updated.
   */
  lastUpdatedAt: C(),
  pollInterval: Ee(pe()),
  /**
   * Optional diagnostic message for failed tasks or other status information.
   */
  statusMessage: Ee(C())
}), Rr = Ze.extend({
  task: xr
}), $m = lt.merge(xr), qn = dt.extend({
  method: Q("notifications/tasks/status"),
  params: $m
}), Rs = Le.extend({
  method: Q("tasks/get"),
  params: st.extend({
    taskId: C()
  })
}), Is = Ze.merge(xr), Os = Le.extend({
  method: Q("tasks/result"),
  params: st.extend({
    taskId: C()
  })
});
Ze.loose();
const zs = Mr.extend({
  method: Q("tasks/list")
}), Ns = jr.extend({
  tasks: H(xr)
}), Ms = Le.extend({
  method: Q("tasks/cancel"),
  params: st.extend({
    taskId: C()
  })
}), Sm = Ze.merge(xr), ru = W({
  /**
   * The URI of this resource.
   */
  uri: C(),
  /**
   * The MIME type of this resource, if known.
   */
  mimeType: Ee(C()),
  /**
   * See [MCP specification](https://github.com/modelcontextprotocol/modelcontextprotocol/blob/47339c03c143bb4ec01a26e721a1b8fe66634ebe/docs/specification/draft/basic/index.mdx#general-fields)
   * for notes on _meta usage.
   */
  _meta: ye(C(), ke()).optional()
}), nu = ru.extend({
  /**
   * The text of the item. This must only be set if the item can actually be represented as text (not binary data).
   */
  text: C()
}), js = C().refine((t) => {
  try {
    return atob(t), !0;
  } catch {
    return !1;
  }
}, { message: "Invalid Base64 string" }), ou = ru.extend({
  /**
   * A base64-encoded string representing the binary data of the item.
   */
  blob: js
}), qr = ot(["user", "assistant"]), mr = W({
  /**
   * Intended audience(s) for the resource.
   */
  audience: H(qr).optional(),
  /**
   * Importance hint for the resource, from 0 (least) to 1 (most).
   */
  priority: pe().min(0).max(1).optional(),
  /**
   * ISO 8601 timestamp for the most recent modification.
   */
  lastModified: xc({ offset: !0 }).optional()
}), su = W({
  ...fr.shape,
  ...Nr.shape,
  /**
   * The URI of this resource.
   */
  uri: C(),
  /**
   * A description of what this resource represents.
   *
   * This can be used by clients to improve the LLM's understanding of available resources. It can be thought of like a "hint" to the model.
   */
  description: Ee(C()),
  /**
   * The MIME type of this resource, if known.
   */
  mimeType: Ee(C()),
  /**
   * The size of the raw resource content, in bytes (i.e., before base64 encoding or any tokenization), if known.
   *
   * This can be used by Hosts to display file sizes and estimate context window usage.
   */
  size: Ee(pe()),
  /**
   * Optional annotations for the client.
   */
  annotations: mr.optional(),
  /**
   * See [MCP specification](https://github.com/modelcontextprotocol/modelcontextprotocol/blob/47339c03c143bb4ec01a26e721a1b8fe66634ebe/docs/specification/draft/basic/index.mdx#general-fields)
   * for notes on _meta usage.
   */
  _meta: Ee(Fe({}))
}), Em = W({
  ...fr.shape,
  ...Nr.shape,
  /**
   * A URI template (according to RFC 6570) that can be used to construct resource URIs.
   */
  uriTemplate: C(),
  /**
   * A description of what this template is for.
   *
   * This can be used by clients to improve the LLM's understanding of available resources. It can be thought of like a "hint" to the model.
   */
  description: Ee(C()),
  /**
   * The MIME type for all resources that match this template. This should only be included if all resources matching this template have the same type.
   */
  mimeType: Ee(C()),
  /**
   * Optional annotations for the client.
   */
  annotations: mr.optional(),
  /**
   * See [MCP specification](https://github.com/modelcontextprotocol/modelcontextprotocol/blob/47339c03c143bb4ec01a26e721a1b8fe66634ebe/docs/specification/draft/basic/index.mdx#general-fields)
   * for notes on _meta usage.
   */
  _meta: Ee(Fe({}))
}), km = Mr.extend({
  method: Q("resources/list")
}), iu = jr.extend({
  resources: H(su)
}), Cm = Mr.extend({
  method: Q("resources/templates/list")
}), au = jr.extend({
  resourceTemplates: H(Em)
}), xs = st.extend({
  /**
   * The URI of the resource to read. The URI can use any protocol; it is up to the server how to interpret it.
   *
   * @format uri
   */
  uri: C()
}), Tm = xs, Pm = Le.extend({
  method: Q("resources/read"),
  params: Tm
}), cu = Ze.extend({
  contents: H(Se([nu, ou]))
}), uu = dt.extend({
  method: Q("notifications/resources/list_changed"),
  params: lt.optional()
}), Am = xs, Rm = Le.extend({
  method: Q("resources/subscribe"),
  params: Am
}), Im = xs, Om = Le.extend({
  method: Q("resources/unsubscribe"),
  params: Im
}), zm = lt.extend({
  /**
   * The URI of the resource that has been updated. This might be a sub-resource of the one that the client actually subscribed to.
   */
  uri: C()
}), Nm = dt.extend({
  method: Q("notifications/resources/updated"),
  params: zm
}), Mm = W({
  /**
   * The name of the argument.
   */
  name: C(),
  /**
   * A human-readable description of the argument.
   */
  description: Ee(C()),
  /**
   * Whether this argument must be provided.
   */
  required: Ee(_e())
}), jm = W({
  ...fr.shape,
  ...Nr.shape,
  /**
   * An optional description of what this prompt provides
   */
  description: Ee(C()),
  /**
   * A list of arguments to use for templating the prompt.
   */
  arguments: Ee(H(Mm)),
  /**
   * See [MCP specification](https://github.com/modelcontextprotocol/modelcontextprotocol/blob/47339c03c143bb4ec01a26e721a1b8fe66634ebe/docs/specification/draft/basic/index.mdx#general-fields)
   * for notes on _meta usage.
   */
  _meta: Ee(Fe({}))
}), xm = Mr.extend({
  method: Q("prompts/list")
}), lu = jr.extend({
  prompts: H(jm)
}), qm = st.extend({
  /**
   * The name of the prompt or prompt template.
   */
  name: C(),
  /**
   * Arguments to use for templating the prompt.
   */
  arguments: ye(C(), C()).optional()
}), Dm = Le.extend({
  method: Q("prompts/get"),
  params: qm
}), qs = W({
  type: Q("text"),
  /**
   * The text content of the message.
   */
  text: C(),
  /**
   * Optional annotations for the client.
   */
  annotations: mr.optional(),
  /**
   * See [MCP specification](https://github.com/modelcontextprotocol/modelcontextprotocol/blob/47339c03c143bb4ec01a26e721a1b8fe66634ebe/docs/specification/draft/basic/index.mdx#general-fields)
   * for notes on _meta usage.
   */
  _meta: ye(C(), ke()).optional()
}), Ds = W({
  type: Q("image"),
  /**
   * The base64-encoded image data.
   */
  data: js,
  /**
   * The MIME type of the image. Different providers may support different image types.
   */
  mimeType: C(),
  /**
   * Optional annotations for the client.
   */
  annotations: mr.optional(),
  /**
   * See [MCP specification](https://github.com/modelcontextprotocol/modelcontextprotocol/blob/47339c03c143bb4ec01a26e721a1b8fe66634ebe/docs/specification/draft/basic/index.mdx#general-fields)
   * for notes on _meta usage.
   */
  _meta: ye(C(), ke()).optional()
}), Us = W({
  type: Q("audio"),
  /**
   * The base64-encoded audio data.
   */
  data: js,
  /**
   * The MIME type of the audio. Different providers may support different audio types.
   */
  mimeType: C(),
  /**
   * Optional annotations for the client.
   */
  annotations: mr.optional(),
  /**
   * See [MCP specification](https://github.com/modelcontextprotocol/modelcontextprotocol/blob/47339c03c143bb4ec01a26e721a1b8fe66634ebe/docs/specification/draft/basic/index.mdx#general-fields)
   * for notes on _meta usage.
   */
  _meta: ye(C(), ke()).optional()
}), Um = W({
  type: Q("tool_use"),
  /**
   * The name of the tool to invoke.
   * Must match a tool name from the request's tools array.
   */
  name: C(),
  /**
   * Unique identifier for this tool call.
   * Used to correlate with ToolResultContent in subsequent messages.
   */
  id: C(),
  /**
   * Arguments to pass to the tool.
   * Must conform to the tool's inputSchema.
   */
  input: ye(C(), ke()),
  /**
   * See [MCP specification](https://github.com/modelcontextprotocol/modelcontextprotocol/blob/47339c03c143bb4ec01a26e721a1b8fe66634ebe/docs/specification/draft/basic/index.mdx#general-fields)
   * for notes on _meta usage.
   */
  _meta: ye(C(), ke()).optional()
}), Fm = W({
  type: Q("resource"),
  resource: Se([nu, ou]),
  /**
   * Optional annotations for the client.
   */
  annotations: mr.optional(),
  /**
   * See [MCP specification](https://github.com/modelcontextprotocol/modelcontextprotocol/blob/47339c03c143bb4ec01a26e721a1b8fe66634ebe/docs/specification/draft/basic/index.mdx#general-fields)
   * for notes on _meta usage.
   */
  _meta: ye(C(), ke()).optional()
}), Lm = su.extend({
  type: Q("resource_link")
}), Fs = Se([
  qs,
  Ds,
  Us,
  Lm,
  Fm
]), Zm = W({
  role: qr,
  content: Fs
}), du = Ze.extend({
  /**
   * An optional description for the prompt.
   */
  description: C().optional(),
  messages: H(Zm)
}), fu = dt.extend({
  method: Q("notifications/prompts/list_changed"),
  params: lt.optional()
}), Vm = W({
  /**
   * A human-readable title for the tool.
   */
  title: C().optional(),
  /**
   * If true, the tool does not modify its environment.
   *
   * Default: false
   */
  readOnlyHint: _e().optional(),
  /**
   * If true, the tool may perform destructive updates to its environment.
   * If false, the tool performs only additive updates.
   *
   * (This property is meaningful only when `readOnlyHint == false`)
   *
   * Default: true
   */
  destructiveHint: _e().optional(),
  /**
   * If true, calling the tool repeatedly with the same arguments
   * will have no additional effect on the its environment.
   *
   * (This property is meaningful only when `readOnlyHint == false`)
   *
   * Default: false
   */
  idempotentHint: _e().optional(),
  /**
   * If true, this tool may interact with an "open world" of external
   * entities. If false, the tool's domain of interaction is closed.
   * For example, the world of a web search tool is open, whereas that
   * of a memory tool is not.
   *
   * Default: true
   */
  openWorldHint: _e().optional()
}), Hm = W({
  /**
   * Indicates the tool's preference for task-augmented execution.
   * - "required": Clients MUST invoke the tool as a task
   * - "optional": Clients MAY invoke the tool as a task or normal request
   * - "forbidden": Clients MUST NOT attempt to invoke the tool as a task
   *
   * If not present, defaults to "forbidden".
   */
  taskSupport: ot(["required", "optional", "forbidden"]).optional()
}), hu = W({
  ...fr.shape,
  ...Nr.shape,
  /**
   * A human-readable description of the tool.
   */
  description: C().optional(),
  /**
   * A JSON Schema 2020-12 object defining the expected parameters for the tool.
   * Must have type: 'object' at the root level per MCP spec.
   */
  inputSchema: W({
    type: Q("object"),
    properties: ye(C(), Ne).optional(),
    required: H(C()).optional()
  }).catchall(ke()),
  /**
   * An optional JSON Schema 2020-12 object defining the structure of the tool's output
   * returned in the structuredContent field of a CallToolResult.
   * Must have type: 'object' at the root level per MCP spec.
   */
  outputSchema: W({
    type: Q("object"),
    properties: ye(C(), Ne).optional(),
    required: H(C()).optional()
  }).catchall(ke()).optional(),
  /**
   * Optional additional tool information.
   */
  annotations: Vm.optional(),
  /**
   * Execution-related properties for this tool.
   */
  execution: Hm.optional(),
  /**
   * See [MCP specification](https://github.com/modelcontextprotocol/modelcontextprotocol/blob/47339c03c143bb4ec01a26e721a1b8fe66634ebe/docs/specification/draft/basic/index.mdx#general-fields)
   * for notes on _meta usage.
   */
  _meta: ye(C(), ke()).optional()
}), Wm = Mr.extend({
  method: Q("tools/list")
}), pu = jr.extend({
  tools: H(hu)
}), no = Ze.extend({
  /**
   * A list of content objects that represent the result of the tool call.
   *
   * If the Tool does not define an outputSchema, this field MUST be present in the result.
   * For backwards compatibility, this field is always present, but it may be empty.
   */
  content: H(Fs).default([]),
  /**
   * An object containing structured tool output.
   *
   * If the Tool defines an outputSchema, this field MUST be present in the result, and contain a JSON object that matches the schema.
   */
  structuredContent: ye(C(), ke()).optional(),
  /**
   * Whether the tool call ended in an error.
   *
   * If not set, this is assumed to be false (the call was successful).
   *
   * Any errors that originate from the tool SHOULD be reported inside the result
   * object, with `isError` set to true, _not_ as an MCP protocol-level error
   * response. Otherwise, the LLM would not be able to see that an error occurred
   * and self-correct.
   *
   * However, any errors in _finding_ the tool, an error indicating that the
   * server does not support tool calls, or any other exceptional conditions,
   * should be reported as an MCP error response.
   */
  isError: _e().optional()
});
no.or(Ze.extend({
  toolResult: ke()
}));
const Bm = zr.extend({
  /**
   * The name of the tool to call.
   */
  name: C(),
  /**
   * Arguments to pass to the tool.
   */
  arguments: ye(C(), ke()).optional()
}), Gm = Le.extend({
  method: Q("tools/call"),
  params: Bm
}), mu = dt.extend({
  method: Q("notifications/tools/list_changed"),
  params: lt.optional()
}), Km = W({
  /**
   * If true, the list will be refreshed automatically when a list changed notification is received.
   * The callback will be called with the updated list.
   *
   * If false, the callback will be called with null items, allowing manual refresh.
   *
   * @default true
   */
  autoRefresh: _e().default(!0),
  /**
   * Debounce time in milliseconds for list changed notification processing.
   *
   * Multiple notifications received within this timeframe will only trigger one refresh.
   * Set to 0 to disable debouncing.
   *
   * @default 300
   */
  debounceMs: pe().int().nonnegative().default(300)
}), gu = ot(["debug", "info", "notice", "warning", "error", "critical", "alert", "emergency"]), Jm = st.extend({
  /**
   * The level of logging that the client wants to receive from the server. The server should send all logs at this level and higher (i.e., more severe) to the client as notifications/logging/message.
   */
  level: gu
}), Qm = Le.extend({
  method: Q("logging/setLevel"),
  params: Jm
}), Xm = lt.extend({
  /**
   * The severity of this log message.
   */
  level: gu,
  /**
   * An optional name of the logger issuing this message.
   */
  logger: C().optional(),
  /**
   * The data to be logged, such as a string message or an object. Any JSON serializable type is allowed here.
   */
  data: ke()
}), _u = dt.extend({
  method: Q("notifications/message"),
  params: Xm
}), Ym = W({
  /**
   * A hint for a model name.
   */
  name: C().optional()
}), eg = W({
  /**
   * Optional hints to use for model selection.
   */
  hints: H(Ym).optional(),
  /**
   * How much to prioritize cost when selecting a model.
   */
  costPriority: pe().min(0).max(1).optional(),
  /**
   * How much to prioritize sampling speed (latency) when selecting a model.
   */
  speedPriority: pe().min(0).max(1).optional(),
  /**
   * How much to prioritize intelligence and capabilities when selecting a model.
   */
  intelligencePriority: pe().min(0).max(1).optional()
}), tg = W({
  /**
   * Controls when tools are used:
   * - "auto": Model decides whether to use tools (default)
   * - "required": Model MUST use at least one tool before completing
   * - "none": Model MUST NOT use any tools
   */
  mode: ot(["auto", "required", "none"]).optional()
}), rg = W({
  type: Q("tool_result"),
  toolUseId: C().describe("The unique identifier for the corresponding tool call."),
  content: H(Fs).default([]),
  structuredContent: W({}).loose().optional(),
  isError: _e().optional(),
  /**
   * See [MCP specification](https://github.com/modelcontextprotocol/modelcontextprotocol/blob/47339c03c143bb4ec01a26e721a1b8fe66634ebe/docs/specification/draft/basic/index.mdx#general-fields)
   * for notes on _meta usage.
   */
  _meta: ye(C(), ke()).optional()
}), ng = Lc("type", [qs, Ds, Us]), Dn = Lc("type", [
  qs,
  Ds,
  Us,
  Um,
  rg
]), og = W({
  role: qr,
  content: Se([Dn, H(Dn)]),
  /**
   * See [MCP specification](https://github.com/modelcontextprotocol/modelcontextprotocol/blob/47339c03c143bb4ec01a26e721a1b8fe66634ebe/docs/specification/draft/basic/index.mdx#general-fields)
   * for notes on _meta usage.
   */
  _meta: ye(C(), ke()).optional()
}), sg = zr.extend({
  messages: H(og),
  /**
   * The server's preferences for which model to select. The client MAY modify or omit this request.
   */
  modelPreferences: eg.optional(),
  /**
   * An optional system prompt the server wants to use for sampling. The client MAY modify or omit this prompt.
   */
  systemPrompt: C().optional(),
  /**
   * A request to include context from one or more MCP servers (including the caller), to be attached to the prompt.
   * The client MAY ignore this request.
   *
   * Default is "none". Values "thisServer" and "allServers" are soft-deprecated. Servers SHOULD only use these values if the client
   * declares ClientCapabilities.sampling.context. These values may be removed in future spec releases.
   */
  includeContext: ot(["none", "thisServer", "allServers"]).optional(),
  temperature: pe().optional(),
  /**
   * The requested maximum number of tokens to sample (to prevent runaway completions).
   *
   * The client MAY choose to sample fewer tokens than the requested maximum.
   */
  maxTokens: pe().int(),
  stopSequences: H(C()).optional(),
  /**
   * Optional metadata to pass through to the LLM provider. The format of this metadata is provider-specific.
   */
  metadata: Ne.optional(),
  /**
   * Tools that the model may use during generation.
   * The client MUST return an error if this field is provided but ClientCapabilities.sampling.tools is not declared.
   */
  tools: H(hu).optional(),
  /**
   * Controls how the model uses tools.
   * The client MUST return an error if this field is provided but ClientCapabilities.sampling.tools is not declared.
   * Default is `{ mode: "auto" }`.
   */
  toolChoice: tg.optional()
}), yu = Le.extend({
  method: Q("sampling/createMessage"),
  params: sg
}), vu = Ze.extend({
  /**
   * The name of the model that generated the message.
   */
  model: C(),
  /**
   * The reason why sampling stopped, if known.
   *
   * Standard values:
   * - "endTurn": Natural end of the assistant's turn
   * - "stopSequence": A stop sequence was encountered
   * - "maxTokens": Maximum token limit was reached
   *
   * This field is an open string to allow for provider-specific stop reasons.
   */
  stopReason: Ee(ot(["endTurn", "stopSequence", "maxTokens"]).or(C())),
  role: qr,
  /**
   * Response content. Single content block (text, image, or audio).
   */
  content: ng
}), wu = Ze.extend({
  /**
   * The name of the model that generated the message.
   */
  model: C(),
  /**
   * The reason why sampling stopped, if known.
   *
   * Standard values:
   * - "endTurn": Natural end of the assistant's turn
   * - "stopSequence": A stop sequence was encountered
   * - "maxTokens": Maximum token limit was reached
   * - "toolUse": The model wants to use one or more tools
   *
   * This field is an open string to allow for provider-specific stop reasons.
   */
  stopReason: Ee(ot(["endTurn", "stopSequence", "maxTokens", "toolUse"]).or(C())),
  role: qr,
  /**
   * Response content. May be a single block or array. May include ToolUseContent if stopReason is "toolUse".
   */
  content: Se([Dn, H(Dn)])
}), ig = W({
  type: Q("boolean"),
  title: C().optional(),
  description: C().optional(),
  default: _e().optional()
}), ag = W({
  type: Q("string"),
  title: C().optional(),
  description: C().optional(),
  minLength: pe().optional(),
  maxLength: pe().optional(),
  format: ot(["email", "uri", "date", "date-time"]).optional(),
  default: C().optional()
}), cg = W({
  type: ot(["number", "integer"]),
  title: C().optional(),
  description: C().optional(),
  minimum: pe().optional(),
  maximum: pe().optional(),
  default: pe().optional()
}), ug = W({
  type: Q("string"),
  title: C().optional(),
  description: C().optional(),
  enum: H(C()),
  default: C().optional()
}), lg = W({
  type: Q("string"),
  title: C().optional(),
  description: C().optional(),
  oneOf: H(W({
    const: C(),
    title: C()
  })),
  default: C().optional()
}), dg = W({
  type: Q("string"),
  title: C().optional(),
  description: C().optional(),
  enum: H(C()),
  enumNames: H(C()).optional(),
  default: C().optional()
}), fg = Se([ug, lg]), hg = W({
  type: Q("array"),
  title: C().optional(),
  description: C().optional(),
  minItems: pe().optional(),
  maxItems: pe().optional(),
  items: W({
    type: Q("string"),
    enum: H(C())
  }),
  default: H(C()).optional()
}), pg = W({
  type: Q("array"),
  title: C().optional(),
  description: C().optional(),
  minItems: pe().optional(),
  maxItems: pe().optional(),
  items: W({
    anyOf: H(W({
      const: C(),
      title: C()
    }))
  }),
  default: H(C()).optional()
}), mg = Se([hg, pg]), gg = Se([dg, fg, mg]), _g = Se([gg, ig, ag, cg]), yg = zr.extend({
  /**
   * The elicitation mode.
   *
   * Optional for backward compatibility. Clients MUST treat missing mode as "form".
   */
  mode: Q("form").optional(),
  /**
   * The message to present to the user describing what information is being requested.
   */
  message: C(),
  /**
   * A restricted subset of JSON Schema.
   * Only top-level properties are allowed, without nesting.
   */
  requestedSchema: W({
    type: Q("object"),
    properties: ye(C(), _g),
    required: H(C()).optional()
  })
}), vg = zr.extend({
  /**
   * The elicitation mode.
   */
  mode: Q("url"),
  /**
   * The message to present to the user explaining why the interaction is needed.
   */
  message: C(),
  /**
   * The ID of the elicitation, which must be unique within the context of the server.
   * The client MUST treat this ID as an opaque value.
   */
  elicitationId: C(),
  /**
   * The URL that the user should navigate to.
   */
  url: C().url()
}), wg = Se([yg, vg]), bu = Le.extend({
  method: Q("elicitation/create"),
  params: wg
}), bg = lt.extend({
  /**
   * The ID of the elicitation that completed.
   */
  elicitationId: C()
}), $g = dt.extend({
  method: Q("notifications/elicitation/complete"),
  params: bg
}), $u = Ze.extend({
  /**
   * The user action in response to the elicitation.
   * - "accept": User submitted the form/confirmed the action
   * - "decline": User explicitly decline the action
   * - "cancel": User dismissed without making an explicit choice
   */
  action: ot(["accept", "decline", "cancel"]),
  /**
   * The submitted form data, only present when action is "accept".
   * Contains values matching the requested schema.
   * Per MCP spec, content is "typically omitted" for decline/cancel actions.
   * We normalize null to undefined for leniency while maintaining type compatibility.
   */
  content: Gc((t) => t === null ? void 0 : t, ye(C(), Se([C(), pe(), _e(), H(C())])).optional())
}), Sg = W({
  type: Q("ref/resource"),
  /**
   * The URI or URI template of the resource.
   */
  uri: C()
}), Eg = W({
  type: Q("ref/prompt"),
  /**
   * The name of the prompt or prompt template
   */
  name: C()
}), kg = st.extend({
  ref: Se([Eg, Sg]),
  /**
   * The argument's information
   */
  argument: W({
    /**
     * The name of the argument
     */
    name: C(),
    /**
     * The value of the argument to use for completion matching.
     */
    value: C()
  }),
  context: W({
    /**
     * Previously-resolved variables in a URI template or prompt.
     */
    arguments: ye(C(), C()).optional()
  }).optional()
}), Cg = Le.extend({
  method: Q("completion/complete"),
  params: kg
}), Su = Ze.extend({
  completion: Fe({
    /**
     * An array of completion values. Must not exceed 100 items.
     */
    values: H(C()).max(100),
    /**
     * The total number of completion options available. This can exceed the number of values actually sent in the response.
     */
    total: Ee(pe().int()),
    /**
     * Indicates whether there are additional completion options beyond those provided in the current response, even if the exact total is unknown.
     */
    hasMore: Ee(_e())
  })
}), Tg = W({
  /**
   * The URI identifying the root. This *must* start with file:// for now.
   */
  uri: C().startsWith("file://"),
  /**
   * An optional name for the root.
   */
  name: C().optional(),
  /**
   * See [MCP specification](https://github.com/modelcontextprotocol/modelcontextprotocol/blob/47339c03c143bb4ec01a26e721a1b8fe66634ebe/docs/specification/draft/basic/index.mdx#general-fields)
   * for notes on _meta usage.
   */
  _meta: ye(C(), ke()).optional()
}), Pg = Le.extend({
  method: Q("roots/list"),
  params: st.optional()
}), Ag = Ze.extend({
  roots: H(Tg)
}), Rg = dt.extend({
  method: Q("notifications/roots/list_changed"),
  params: lt.optional()
});
Se([
  Ps,
  mm,
  Cg,
  Qm,
  Dm,
  xm,
  km,
  Cm,
  Pm,
  Rm,
  Om,
  Gm,
  Wm,
  Rs,
  Os,
  zs,
  Ms
]);
Se([
  Ts,
  As,
  tu,
  Rg,
  qn
]);
Se([
  or,
  vu,
  wu,
  $u,
  Ag,
  Is,
  Ns,
  Rr
]);
Se([
  Ps,
  yu,
  bu,
  Pg,
  Rs,
  Os,
  zs,
  Ms
]);
Se([
  Ts,
  As,
  _u,
  Nm,
  uu,
  mu,
  fu,
  qn,
  $g
]);
Se([
  or,
  eu,
  Su,
  du,
  lu,
  iu,
  au,
  cu,
  no,
  pu,
  Is,
  Ns,
  Rr
]);
class te extends Error {
  constructor(e, r, n) {
    super(`MCP error ${e}: ${r}`), this.code = e, this.data = n, this.name = "McpError";
  }
  /**
   * Factory method to create the appropriate error type based on the error code and data
   */
  static fromError(e, r, n) {
    if (e === oe.UrlElicitationRequired && n) {
      const o = n;
      if (o.elicitations)
        return new Ig(o.elicitations, r);
    }
    return new te(e, r, n);
  }
}
class Ig extends te {
  constructor(e, r = `URL elicitation${e.length > 1 ? "s" : ""} required`) {
    super(oe.UrlElicitationRequired, r, {
      elicitations: e
    });
  }
  get elicitations() {
    var e;
    return ((e = this.data) == null ? void 0 : e.elicitations) ?? [];
  }
}
function Nt(t) {
  return t === "completed" || t === "failed" || t === "cancelled";
}
new Set("ABCDEFGHIJKLMNOPQRSTUVXYZabcdefghijklmnopqrstuvxyz0123456789");
function Ci(t) {
  const e = Mc(t), r = e == null ? void 0 : e.method;
  if (!r)
    throw new Error("Schema is missing a method literal");
  const n = jc(r);
  if (typeof n != "string")
    throw new Error("Schema method literal must be a string");
  return n;
}
function Ti(t, e) {
  const r = Pt(t, e);
  if (!r.success)
    throw r.error;
  return r.data;
}
const Og = 6e4;
class zg {
  constructor(e) {
    this._options = e, this._requestMessageId = 0, this._requestHandlers = /* @__PURE__ */ new Map(), this._requestHandlerAbortControllers = /* @__PURE__ */ new Map(), this._notificationHandlers = /* @__PURE__ */ new Map(), this._responseHandlers = /* @__PURE__ */ new Map(), this._progressHandlers = /* @__PURE__ */ new Map(), this._timeoutInfo = /* @__PURE__ */ new Map(), this._pendingDebouncedNotifications = /* @__PURE__ */ new Set(), this._taskProgressTokens = /* @__PURE__ */ new Map(), this._requestResolvers = /* @__PURE__ */ new Map(), this.setNotificationHandler(Ts, (r) => {
      this._oncancel(r);
    }), this.setNotificationHandler(As, (r) => {
      this._onprogress(r);
    }), this.setRequestHandler(
      Ps,
      // Automatic pong by default.
      (r) => ({})
    ), this._taskStore = e == null ? void 0 : e.taskStore, this._taskMessageQueue = e == null ? void 0 : e.taskMessageQueue, this._taskStore && (this.setRequestHandler(Rs, async (r, n) => {
      const o = await this._taskStore.getTask(r.params.taskId, n.sessionId);
      if (!o)
        throw new te(oe.InvalidParams, "Failed to retrieve task: Task not found");
      return {
        ...o
      };
    }), this.setRequestHandler(Os, async (r, n) => {
      const o = async () => {
        var a;
        const s = r.params.taskId;
        if (this._taskMessageQueue) {
          let c;
          for (; c = await this._taskMessageQueue.dequeue(s, n.sessionId); ) {
            if (c.type === "response" || c.type === "error") {
              const u = c.message, l = u.id, h = this._requestResolvers.get(l);
              if (h)
                if (this._requestResolvers.delete(l), c.type === "response")
                  h(u);
                else {
                  const m = u, _ = new te(m.error.code, m.error.message, m.error.data);
                  h(_);
                }
              else {
                const m = c.type === "response" ? "Response" : "Error";
                this._onerror(new Error(`${m} handler missing for request ${l}`));
              }
              continue;
            }
            await ((a = this._transport) == null ? void 0 : a.send(c.message, { relatedRequestId: n.requestId }));
          }
        }
        const i = await this._taskStore.getTask(s, n.sessionId);
        if (!i)
          throw new te(oe.InvalidParams, `Task not found: ${s}`);
        if (!Nt(i.status))
          return await this._waitForTaskUpdate(s, n.signal), await o();
        if (Nt(i.status)) {
          const c = await this._taskStore.getTaskResult(s, n.sessionId);
          return this._clearTaskQueue(s), {
            ...c,
            _meta: {
              ...c._meta,
              [Ut]: {
                taskId: s
              }
            }
          };
        }
        return await o();
      };
      return await o();
    }), this.setRequestHandler(zs, async (r, n) => {
      var o;
      try {
        const { tasks: s, nextCursor: i } = await this._taskStore.listTasks((o = r.params) == null ? void 0 : o.cursor, n.sessionId);
        return {
          tasks: s,
          nextCursor: i,
          _meta: {}
        };
      } catch (s) {
        throw new te(oe.InvalidParams, `Failed to list tasks: ${s instanceof Error ? s.message : String(s)}`);
      }
    }), this.setRequestHandler(Ms, async (r, n) => {
      try {
        const o = await this._taskStore.getTask(r.params.taskId, n.sessionId);
        if (!o)
          throw new te(oe.InvalidParams, `Task not found: ${r.params.taskId}`);
        if (Nt(o.status))
          throw new te(oe.InvalidParams, `Cannot cancel task in terminal status: ${o.status}`);
        await this._taskStore.updateTaskStatus(r.params.taskId, "cancelled", "Client cancelled task execution.", n.sessionId), this._clearTaskQueue(r.params.taskId);
        const s = await this._taskStore.getTask(r.params.taskId, n.sessionId);
        if (!s)
          throw new te(oe.InvalidParams, `Task not found after cancellation: ${r.params.taskId}`);
        return {
          _meta: {},
          ...s
        };
      } catch (o) {
        throw o instanceof te ? o : new te(oe.InvalidRequest, `Failed to cancel task: ${o instanceof Error ? o.message : String(o)}`);
      }
    }));
  }
  async _oncancel(e) {
    if (!e.params.requestId)
      return;
    const r = this._requestHandlerAbortControllers.get(e.params.requestId);
    r == null || r.abort(e.params.reason);
  }
  _setupTimeout(e, r, n, o, s = !1) {
    this._timeoutInfo.set(e, {
      timeoutId: setTimeout(o, r),
      startTime: Date.now(),
      timeout: r,
      maxTotalTimeout: n,
      resetTimeoutOnProgress: s,
      onTimeout: o
    });
  }
  _resetTimeout(e) {
    const r = this._timeoutInfo.get(e);
    if (!r)
      return !1;
    const n = Date.now() - r.startTime;
    if (r.maxTotalTimeout && n >= r.maxTotalTimeout)
      throw this._timeoutInfo.delete(e), te.fromError(oe.RequestTimeout, "Maximum total timeout exceeded", {
        maxTotalTimeout: r.maxTotalTimeout,
        totalElapsed: n
      });
    return clearTimeout(r.timeoutId), r.timeoutId = setTimeout(r.onTimeout, r.timeout), !0;
  }
  _cleanupTimeout(e) {
    const r = this._timeoutInfo.get(e);
    r && (clearTimeout(r.timeoutId), this._timeoutInfo.delete(e));
  }
  /**
   * Attaches to the given transport, starts it, and starts listening for messages.
   *
   * The Protocol object assumes ownership of the Transport, replacing any callbacks that have already been set, and expects that it is the only user of the Transport instance going forward.
   */
  async connect(e) {
    var s, i, a;
    if (this._transport)
      throw new Error("Already connected to a transport. Call close() before connecting to a new transport, or use a separate Protocol instance per connection.");
    this._transport = e;
    const r = (s = this.transport) == null ? void 0 : s.onclose;
    this._transport.onclose = () => {
      r == null || r(), this._onclose();
    };
    const n = (i = this.transport) == null ? void 0 : i.onerror;
    this._transport.onerror = (c) => {
      n == null || n(c), this._onerror(c);
    };
    const o = (a = this._transport) == null ? void 0 : a.onmessage;
    this._transport.onmessage = (c, u) => {
      o == null || o(c, u), br(c) || im(c) ? this._onresponse(c) : Fo(c) ? this._onrequest(c, u) : sm(c) ? this._onnotification(c) : this._onerror(new Error(`Unknown message type: ${JSON.stringify(c)}`));
    }, await this._transport.start();
  }
  _onclose() {
    var n;
    const e = this._responseHandlers;
    this._responseHandlers = /* @__PURE__ */ new Map(), this._progressHandlers.clear(), this._taskProgressTokens.clear(), this._pendingDebouncedNotifications.clear();
    for (const o of this._timeoutInfo.values())
      clearTimeout(o.timeoutId);
    this._timeoutInfo.clear();
    for (const o of this._requestHandlerAbortControllers.values())
      o.abort();
    this._requestHandlerAbortControllers.clear();
    const r = te.fromError(oe.ConnectionClosed, "Connection closed");
    this._transport = void 0, (n = this.onclose) == null || n.call(this);
    for (const o of e.values())
      o(r);
  }
  _onerror(e) {
    var r;
    (r = this.onerror) == null || r.call(this, e);
  }
  _onnotification(e) {
    const r = this._notificationHandlers.get(e.method) ?? this.fallbackNotificationHandler;
    r !== void 0 && Promise.resolve().then(() => r(e)).catch((n) => this._onerror(new Error(`Uncaught error in notification handler: ${n}`)));
  }
  _onrequest(e, r) {
    var l, h, m, _;
    const n = this._requestHandlers.get(e.method) ?? this.fallbackRequestHandler, o = this._transport, s = (m = (h = (l = e.params) == null ? void 0 : l._meta) == null ? void 0 : h[Ut]) == null ? void 0 : m.taskId;
    if (n === void 0) {
      const S = {
        jsonrpc: "2.0",
        id: e.id,
        error: {
          code: oe.MethodNotFound,
          message: "Method not found"
        }
      };
      s && this._taskMessageQueue ? this._enqueueTaskMessage(s, {
        type: "error",
        message: S,
        timestamp: Date.now()
      }, o == null ? void 0 : o.sessionId).catch(($) => this._onerror(new Error(`Failed to enqueue error response: ${$}`))) : o == null || o.send(S).catch(($) => this._onerror(new Error(`Failed to send an error response: ${$}`)));
      return;
    }
    const i = new AbortController();
    this._requestHandlerAbortControllers.set(e.id, i);
    const a = om(e.params) ? e.params.task : void 0, c = this._taskStore ? this.requestTaskStore(e, o == null ? void 0 : o.sessionId) : void 0, u = {
      signal: i.signal,
      sessionId: o == null ? void 0 : o.sessionId,
      _meta: (_ = e.params) == null ? void 0 : _._meta,
      sendNotification: async (S) => {
        if (i.signal.aborted)
          return;
        const $ = { relatedRequestId: e.id };
        s && ($.relatedTask = { taskId: s }), await this.notification(S, $);
      },
      sendRequest: async (S, $, v) => {
        var w;
        if (i.signal.aborted)
          throw new te(oe.ConnectionClosed, "Request was cancelled");
        const y = { ...v, relatedRequestId: e.id };
        s && !y.relatedTask && (y.relatedTask = { taskId: s });
        const g = ((w = y.relatedTask) == null ? void 0 : w.taskId) ?? s;
        return g && c && await c.updateTaskStatus(g, "input_required"), await this.request(S, $, y);
      },
      authInfo: r == null ? void 0 : r.authInfo,
      requestId: e.id,
      requestInfo: r == null ? void 0 : r.requestInfo,
      taskId: s,
      taskStore: c,
      taskRequestedTtl: a == null ? void 0 : a.ttl,
      closeSSEStream: r == null ? void 0 : r.closeSSEStream,
      closeStandaloneSSEStream: r == null ? void 0 : r.closeStandaloneSSEStream
    };
    Promise.resolve().then(() => {
      a && this.assertTaskHandlerCapability(e.method);
    }).then(() => n(e, u)).then(async (S) => {
      if (i.signal.aborted)
        return;
      const $ = {
        result: S,
        jsonrpc: "2.0",
        id: e.id
      };
      s && this._taskMessageQueue ? await this._enqueueTaskMessage(s, {
        type: "response",
        message: $,
        timestamp: Date.now()
      }, o == null ? void 0 : o.sessionId) : await (o == null ? void 0 : o.send($));
    }, async (S) => {
      if (i.signal.aborted)
        return;
      const $ = {
        jsonrpc: "2.0",
        id: e.id,
        error: {
          code: Number.isSafeInteger(S.code) ? S.code : oe.InternalError,
          message: S.message ?? "Internal error",
          ...S.data !== void 0 && { data: S.data }
        }
      };
      s && this._taskMessageQueue ? await this._enqueueTaskMessage(s, {
        type: "error",
        message: $,
        timestamp: Date.now()
      }, o == null ? void 0 : o.sessionId) : await (o == null ? void 0 : o.send($));
    }).catch((S) => this._onerror(new Error(`Failed to send response: ${S}`))).finally(() => {
      this._requestHandlerAbortControllers.get(e.id) === i && this._requestHandlerAbortControllers.delete(e.id);
    });
  }
  _onprogress(e) {
    const { progressToken: r, ...n } = e.params, o = Number(r), s = this._progressHandlers.get(o);
    if (!s) {
      this._onerror(new Error(`Received a progress notification for an unknown token: ${JSON.stringify(e)}`));
      return;
    }
    const i = this._responseHandlers.get(o), a = this._timeoutInfo.get(o);
    if (a && i && a.resetTimeoutOnProgress)
      try {
        this._resetTimeout(o);
      } catch (c) {
        this._responseHandlers.delete(o), this._progressHandlers.delete(o), this._cleanupTimeout(o), i(c);
        return;
      }
    s(n);
  }
  _onresponse(e) {
    const r = Number(e.id), n = this._requestResolvers.get(r);
    if (n) {
      if (this._requestResolvers.delete(r), br(e))
        n(e);
      else {
        const i = new te(e.error.code, e.error.message, e.error.data);
        n(i);
      }
      return;
    }
    const o = this._responseHandlers.get(r);
    if (o === void 0) {
      this._onerror(new Error(`Received a response for an unknown message ID: ${JSON.stringify(e)}`));
      return;
    }
    this._responseHandlers.delete(r), this._cleanupTimeout(r);
    let s = !1;
    if (br(e) && e.result && typeof e.result == "object") {
      const i = e.result;
      if (i.task && typeof i.task == "object") {
        const a = i.task;
        typeof a.taskId == "string" && (s = !0, this._taskProgressTokens.set(a.taskId, r));
      }
    }
    if (s || this._progressHandlers.delete(r), br(e))
      o(e);
    else {
      const i = te.fromError(e.error.code, e.error.message, e.error.data);
      o(i);
    }
  }
  get transport() {
    return this._transport;
  }
  /**
   * Closes the connection.
   */
  async close() {
    var e;
    await ((e = this._transport) == null ? void 0 : e.close());
  }
  /**
   * Sends a request and returns an AsyncGenerator that yields response messages.
   * The generator is guaranteed to end with either a 'result' or 'error' message.
   *
   * @example
   * ```typescript
   * const stream = protocol.requestStream(request, resultSchema, options);
   * for await (const message of stream) {
   *   switch (message.type) {
   *     case 'taskCreated':
   *       console.log('Task created:', message.task.taskId);
   *       break;
   *     case 'taskStatus':
   *       console.log('Task status:', message.task.status);
   *       break;
   *     case 'result':
   *       console.log('Final result:', message.result);
   *       break;
   *     case 'error':
   *       console.error('Error:', message.error);
   *       break;
   *   }
   * }
   * ```
   *
   * @experimental Use `client.experimental.tasks.requestStream()` to access this method.
   */
  async *requestStream(e, r, n) {
    var i, a;
    const { task: o } = n ?? {};
    if (!o) {
      try {
        yield { type: "result", result: await this.request(e, r, n) };
      } catch (c) {
        yield {
          type: "error",
          error: c instanceof te ? c : new te(oe.InternalError, String(c))
        };
      }
      return;
    }
    let s;
    try {
      const c = await this.request(e, Rr, n);
      if (c.task)
        s = c.task.taskId, yield { type: "taskCreated", task: c.task };
      else
        throw new te(oe.InternalError, "Task creation did not return a task");
      for (; ; ) {
        const u = await this.getTask({ taskId: s }, n);
        if (yield { type: "taskStatus", task: u }, Nt(u.status)) {
          u.status === "completed" ? yield { type: "result", result: await this.getTaskResult({ taskId: s }, r, n) } : u.status === "failed" ? yield {
            type: "error",
            error: new te(oe.InternalError, `Task ${s} failed`)
          } : u.status === "cancelled" && (yield {
            type: "error",
            error: new te(oe.InternalError, `Task ${s} was cancelled`)
          });
          return;
        }
        if (u.status === "input_required") {
          yield { type: "result", result: await this.getTaskResult({ taskId: s }, r, n) };
          return;
        }
        const l = u.pollInterval ?? ((i = this._options) == null ? void 0 : i.defaultTaskPollInterval) ?? 1e3;
        await new Promise((h) => setTimeout(h, l)), (a = n == null ? void 0 : n.signal) == null || a.throwIfAborted();
      }
    } catch (c) {
      yield {
        type: "error",
        error: c instanceof te ? c : new te(oe.InternalError, String(c))
      };
    }
  }
  /**
   * Sends a request and waits for a response.
   *
   * Do not use this method to emit notifications! Use notification() instead.
   */
  request(e, r, n) {
    const { relatedRequestId: o, resumptionToken: s, onresumptiontoken: i, task: a, relatedTask: c } = n ?? {};
    return new Promise((u, l) => {
      var g, w, k, f, d;
      const h = (p) => {
        l(p);
      };
      if (!this._transport) {
        h(new Error("Not connected"));
        return;
      }
      if (((g = this._options) == null ? void 0 : g.enforceStrictCapabilities) === !0)
        try {
          this.assertCapabilityForMethod(e.method), a && this.assertTaskCapability(e.method);
        } catch (p) {
          h(p);
          return;
        }
      (w = n == null ? void 0 : n.signal) == null || w.throwIfAborted();
      const m = this._requestMessageId++, _ = {
        ...e,
        jsonrpc: "2.0",
        id: m
      };
      n != null && n.onprogress && (this._progressHandlers.set(m, n.onprogress), _.params = {
        ...e.params,
        _meta: {
          ...((k = e.params) == null ? void 0 : k._meta) || {},
          progressToken: m
        }
      }), a && (_.params = {
        ..._.params,
        task: a
      }), c && (_.params = {
        ..._.params,
        _meta: {
          ...((f = _.params) == null ? void 0 : f._meta) || {},
          [Ut]: c
        }
      });
      const S = (p) => {
        var I;
        this._responseHandlers.delete(m), this._progressHandlers.delete(m), this._cleanupTimeout(m), (I = this._transport) == null || I.send({
          jsonrpc: "2.0",
          method: "notifications/cancelled",
          params: {
            requestId: m,
            reason: String(p)
          }
        }, { relatedRequestId: o, resumptionToken: s, onresumptiontoken: i }).catch((R) => this._onerror(new Error(`Failed to send cancellation: ${R}`)));
        const E = p instanceof te ? p : new te(oe.RequestTimeout, String(p));
        l(E);
      };
      this._responseHandlers.set(m, (p) => {
        var E;
        if (!((E = n == null ? void 0 : n.signal) != null && E.aborted)) {
          if (p instanceof Error)
            return l(p);
          try {
            const I = Pt(r, p.result);
            I.success ? u(I.data) : l(I.error);
          } catch (I) {
            l(I);
          }
        }
      }), (d = n == null ? void 0 : n.signal) == null || d.addEventListener("abort", () => {
        var p;
        S((p = n == null ? void 0 : n.signal) == null ? void 0 : p.reason);
      });
      const $ = (n == null ? void 0 : n.timeout) ?? Og, v = () => S(te.fromError(oe.RequestTimeout, "Request timed out", { timeout: $ }));
      this._setupTimeout(m, $, n == null ? void 0 : n.maxTotalTimeout, v, (n == null ? void 0 : n.resetTimeoutOnProgress) ?? !1);
      const y = c == null ? void 0 : c.taskId;
      if (y) {
        const p = (E) => {
          const I = this._responseHandlers.get(m);
          I ? I(E) : this._onerror(new Error(`Response handler missing for side-channeled request ${m}`));
        };
        this._requestResolvers.set(m, p), this._enqueueTaskMessage(y, {
          type: "request",
          message: _,
          timestamp: Date.now()
        }).catch((E) => {
          this._cleanupTimeout(m), l(E);
        });
      } else
        this._transport.send(_, { relatedRequestId: o, resumptionToken: s, onresumptiontoken: i }).catch((p) => {
          this._cleanupTimeout(m), l(p);
        });
    });
  }
  /**
   * Gets the current status of a task.
   *
   * @experimental Use `client.experimental.tasks.getTask()` to access this method.
   */
  async getTask(e, r) {
    return this.request({ method: "tasks/get", params: e }, Is, r);
  }
  /**
   * Retrieves the result of a completed task.
   *
   * @experimental Use `client.experimental.tasks.getTaskResult()` to access this method.
   */
  async getTaskResult(e, r, n) {
    return this.request({ method: "tasks/result", params: e }, r, n);
  }
  /**
   * Lists tasks, optionally starting from a pagination cursor.
   *
   * @experimental Use `client.experimental.tasks.listTasks()` to access this method.
   */
  async listTasks(e, r) {
    return this.request({ method: "tasks/list", params: e }, Ns, r);
  }
  /**
   * Cancels a specific task.
   *
   * @experimental Use `client.experimental.tasks.cancelTask()` to access this method.
   */
  async cancelTask(e, r) {
    return this.request({ method: "tasks/cancel", params: e }, Sm, r);
  }
  /**
   * Emits a notification, which is a one-way message that does not expect a response.
   */
  async notification(e, r) {
    var a, c, u, l;
    if (!this._transport)
      throw new Error("Not connected");
    this.assertNotificationCapability(e.method);
    const n = (a = r == null ? void 0 : r.relatedTask) == null ? void 0 : a.taskId;
    if (n) {
      const h = {
        ...e,
        jsonrpc: "2.0",
        params: {
          ...e.params,
          _meta: {
            ...((c = e.params) == null ? void 0 : c._meta) || {},
            [Ut]: r.relatedTask
          }
        }
      };
      await this._enqueueTaskMessage(n, {
        type: "notification",
        message: h,
        timestamp: Date.now()
      });
      return;
    }
    if ((((u = this._options) == null ? void 0 : u.debouncedNotificationMethods) ?? []).includes(e.method) && !e.params && !(r != null && r.relatedRequestId) && !(r != null && r.relatedTask)) {
      if (this._pendingDebouncedNotifications.has(e.method))
        return;
      this._pendingDebouncedNotifications.add(e.method), Promise.resolve().then(() => {
        var m, _;
        if (this._pendingDebouncedNotifications.delete(e.method), !this._transport)
          return;
        let h = {
          ...e,
          jsonrpc: "2.0"
        };
        r != null && r.relatedTask && (h = {
          ...h,
          params: {
            ...h.params,
            _meta: {
              ...((m = h.params) == null ? void 0 : m._meta) || {},
              [Ut]: r.relatedTask
            }
          }
        }), (_ = this._transport) == null || _.send(h, r).catch((S) => this._onerror(S));
      });
      return;
    }
    let i = {
      ...e,
      jsonrpc: "2.0"
    };
    r != null && r.relatedTask && (i = {
      ...i,
      params: {
        ...i.params,
        _meta: {
          ...((l = i.params) == null ? void 0 : l._meta) || {},
          [Ut]: r.relatedTask
        }
      }
    }), await this._transport.send(i, r);
  }
  /**
   * Registers a handler to invoke when this protocol object receives a request with the given method.
   *
   * Note that this will replace any previous request handler for the same method.
   */
  setRequestHandler(e, r) {
    const n = Ci(e);
    this.assertRequestHandlerCapability(n), this._requestHandlers.set(n, (o, s) => {
      const i = Ti(e, o);
      return Promise.resolve(r(i, s));
    });
  }
  /**
   * Removes the request handler for the given method.
   */
  removeRequestHandler(e) {
    this._requestHandlers.delete(e);
  }
  /**
   * Asserts that a request handler has not already been set for the given method, in preparation for a new one being automatically installed.
   */
  assertCanSetRequestHandler(e) {
    if (this._requestHandlers.has(e))
      throw new Error(`A request handler for ${e} already exists, which would be overridden`);
  }
  /**
   * Registers a handler to invoke when this protocol object receives a notification with the given method.
   *
   * Note that this will replace any previous notification handler for the same method.
   */
  setNotificationHandler(e, r) {
    const n = Ci(e);
    this._notificationHandlers.set(n, (o) => {
      const s = Ti(e, o);
      return Promise.resolve(r(s));
    });
  }
  /**
   * Removes the notification handler for the given method.
   */
  removeNotificationHandler(e) {
    this._notificationHandlers.delete(e);
  }
  /**
   * Cleans up the progress handler associated with a task.
   * This should be called when a task reaches a terminal status.
   */
  _cleanupTaskProgressHandler(e) {
    const r = this._taskProgressTokens.get(e);
    r !== void 0 && (this._progressHandlers.delete(r), this._taskProgressTokens.delete(e));
  }
  /**
   * Enqueues a task-related message for side-channel delivery via tasks/result.
   * @param taskId The task ID to associate the message with
   * @param message The message to enqueue
   * @param sessionId Optional session ID for binding the operation to a specific session
   * @throws Error if taskStore is not configured or if enqueue fails (e.g., queue overflow)
   *
   * Note: If enqueue fails, it's the TaskMessageQueue implementation's responsibility to handle
   * the error appropriately (e.g., by failing the task, logging, etc.). The Protocol layer
   * simply propagates the error.
   */
  async _enqueueTaskMessage(e, r, n) {
    var s;
    if (!this._taskStore || !this._taskMessageQueue)
      throw new Error("Cannot enqueue task message: taskStore and taskMessageQueue are not configured");
    const o = (s = this._options) == null ? void 0 : s.maxTaskQueueSize;
    await this._taskMessageQueue.enqueue(e, r, n, o);
  }
  /**
   * Clears the message queue for a task and rejects any pending request resolvers.
   * @param taskId The task ID whose queue should be cleared
   * @param sessionId Optional session ID for binding the operation to a specific session
   */
  async _clearTaskQueue(e, r) {
    if (this._taskMessageQueue) {
      const n = await this._taskMessageQueue.dequeueAll(e, r);
      for (const o of n)
        if (o.type === "request" && Fo(o.message)) {
          const s = o.message.id, i = this._requestResolvers.get(s);
          i ? (i(new te(oe.InternalError, "Task cancelled or completed")), this._requestResolvers.delete(s)) : this._onerror(new Error(`Resolver missing for request ${s} during task ${e} cleanup`));
        }
    }
  }
  /**
   * Waits for a task update (new messages or status change) with abort signal support.
   * Uses polling to check for updates at the task's configured poll interval.
   * @param taskId The task ID to wait for
   * @param signal Abort signal to cancel the wait
   * @returns Promise that resolves when an update occurs or rejects if aborted
   */
  async _waitForTaskUpdate(e, r) {
    var o, s;
    let n = ((o = this._options) == null ? void 0 : o.defaultTaskPollInterval) ?? 1e3;
    try {
      const i = await ((s = this._taskStore) == null ? void 0 : s.getTask(e));
      i != null && i.pollInterval && (n = i.pollInterval);
    } catch {
    }
    return new Promise((i, a) => {
      if (r.aborted) {
        a(new te(oe.InvalidRequest, "Request cancelled"));
        return;
      }
      const c = setTimeout(i, n);
      r.addEventListener("abort", () => {
        clearTimeout(c), a(new te(oe.InvalidRequest, "Request cancelled"));
      }, { once: !0 });
    });
  }
  requestTaskStore(e, r) {
    const n = this._taskStore;
    if (!n)
      throw new Error("No task store configured");
    return {
      createTask: async (o) => {
        if (!e)
          throw new Error("No request provided");
        return await n.createTask(o, e.id, {
          method: e.method,
          params: e.params
        }, r);
      },
      getTask: async (o) => {
        const s = await n.getTask(o, r);
        if (!s)
          throw new te(oe.InvalidParams, "Failed to retrieve task: Task not found");
        return s;
      },
      storeTaskResult: async (o, s, i) => {
        await n.storeTaskResult(o, s, i, r);
        const a = await n.getTask(o, r);
        if (a) {
          const c = qn.parse({
            method: "notifications/tasks/status",
            params: a
          });
          await this.notification(c), Nt(a.status) && this._cleanupTaskProgressHandler(o);
        }
      },
      getTaskResult: (o) => n.getTaskResult(o, r),
      updateTaskStatus: async (o, s, i) => {
        const a = await n.getTask(o, r);
        if (!a)
          throw new te(oe.InvalidParams, `Task "${o}" not found - it may have been cleaned up`);
        if (Nt(a.status))
          throw new te(oe.InvalidParams, `Cannot update task "${o}" from terminal status "${a.status}" to "${s}". Terminal states (completed, failed, cancelled) cannot transition to other states.`);
        await n.updateTaskStatus(o, s, i, r);
        const c = await n.getTask(o, r);
        if (c) {
          const u = qn.parse({
            method: "notifications/tasks/status",
            params: c
          });
          await this.notification(u), Nt(c.status) && this._cleanupTaskProgressHandler(o);
        }
      },
      listTasks: (o) => n.listTasks(o, r)
    };
  }
}
function Pi(t) {
  return t !== null && typeof t == "object" && !Array.isArray(t);
}
function Ng(t, e) {
  const r = { ...t };
  for (const n in e) {
    const o = n, s = e[o];
    if (s === void 0)
      continue;
    const i = r[o];
    Pi(i) && Pi(s) ? r[o] = { ...i, ...s } : r[o] = s;
  }
  return r;
}
var Zr = { exports: {} }, _o = {}, yt = {}, Mt = {}, yo = {}, vo = {}, wo = {}, Ai;
function Un() {
  return Ai || (Ai = 1, function(t) {
    Object.defineProperty(t, "__esModule", { value: !0 }), t.regexpCode = t.getEsmExportName = t.getProperty = t.safeStringify = t.stringify = t.strConcat = t.addCodeArg = t.str = t._ = t.nil = t._Code = t.Name = t.IDENTIFIER = t._CodeOrName = void 0;
    class e {
    }
    t._CodeOrName = e, t.IDENTIFIER = /^[a-z$_][a-z$_0-9]*$/i;
    class r extends e {
      constructor(g) {
        if (super(), !t.IDENTIFIER.test(g))
          throw new Error("CodeGen: name must be a valid identifier");
        this.str = g;
      }
      toString() {
        return this.str;
      }
      emptyStr() {
        return !1;
      }
      get names() {
        return { [this.str]: 1 };
      }
    }
    t.Name = r;
    class n extends e {
      constructor(g) {
        super(), this._items = typeof g == "string" ? [g] : g;
      }
      toString() {
        return this.str;
      }
      emptyStr() {
        if (this._items.length > 1)
          return !1;
        const g = this._items[0];
        return g === "" || g === '""';
      }
      get str() {
        var g;
        return (g = this._str) !== null && g !== void 0 ? g : this._str = this._items.reduce((w, k) => `${w}${k}`, "");
      }
      get names() {
        var g;
        return (g = this._names) !== null && g !== void 0 ? g : this._names = this._items.reduce((w, k) => (k instanceof r && (w[k.str] = (w[k.str] || 0) + 1), w), {});
      }
    }
    t._Code = n, t.nil = new n("");
    function o(y, ...g) {
      const w = [y[0]];
      let k = 0;
      for (; k < g.length; )
        a(w, g[k]), w.push(y[++k]);
      return new n(w);
    }
    t._ = o;
    const s = new n("+");
    function i(y, ...g) {
      const w = [_(y[0])];
      let k = 0;
      for (; k < g.length; )
        w.push(s), a(w, g[k]), w.push(s, _(y[++k]));
      return c(w), new n(w);
    }
    t.str = i;
    function a(y, g) {
      g instanceof n ? y.push(...g._items) : g instanceof r ? y.push(g) : y.push(h(g));
    }
    t.addCodeArg = a;
    function c(y) {
      let g = 1;
      for (; g < y.length - 1; ) {
        if (y[g] === s) {
          const w = u(y[g - 1], y[g + 1]);
          if (w !== void 0) {
            y.splice(g - 1, 3, w);
            continue;
          }
          y[g++] = "+";
        }
        g++;
      }
    }
    function u(y, g) {
      if (g === '""')
        return y;
      if (y === '""')
        return g;
      if (typeof y == "string")
        return g instanceof r || y[y.length - 1] !== '"' ? void 0 : typeof g != "string" ? `${y.slice(0, -1)}${g}"` : g[0] === '"' ? y.slice(0, -1) + g.slice(1) : void 0;
      if (typeof g == "string" && g[0] === '"' && !(y instanceof r))
        return `"${y}${g.slice(1)}`;
    }
    function l(y, g) {
      return g.emptyStr() ? y : y.emptyStr() ? g : i`${y}${g}`;
    }
    t.strConcat = l;
    function h(y) {
      return typeof y == "number" || typeof y == "boolean" || y === null ? y : _(Array.isArray(y) ? y.join(",") : y);
    }
    function m(y) {
      return new n(_(y));
    }
    t.stringify = m;
    function _(y) {
      return JSON.stringify(y).replace(/\u2028/g, "\\u2028").replace(/\u2029/g, "\\u2029");
    }
    t.safeStringify = _;
    function S(y) {
      return typeof y == "string" && t.IDENTIFIER.test(y) ? new n(`.${y}`) : o`[${y}]`;
    }
    t.getProperty = S;
    function $(y) {
      if (typeof y == "string" && t.IDENTIFIER.test(y))
        return new n(`${y}`);
      throw new Error(`CodeGen: invalid export name: ${y}, use explicit $id name mapping`);
    }
    t.getEsmExportName = $;
    function v(y) {
      return new n(y.toString());
    }
    t.regexpCode = v;
  }(wo)), wo;
}
var bo = {}, Ri;
function Ii() {
  return Ri || (Ri = 1, function(t) {
    Object.defineProperty(t, "__esModule", { value: !0 }), t.ValueScope = t.ValueScopeName = t.Scope = t.varKinds = t.UsedValueState = void 0;
    const e = /* @__PURE__ */ Un();
    class r extends Error {
      constructor(u) {
        super(`CodeGen: "code" for ${u} not defined`), this.value = u.value;
      }
    }
    var n;
    (function(c) {
      c[c.Started = 0] = "Started", c[c.Completed = 1] = "Completed";
    })(n || (t.UsedValueState = n = {})), t.varKinds = {
      const: new e.Name("const"),
      let: new e.Name("let"),
      var: new e.Name("var")
    };
    class o {
      constructor({ prefixes: u, parent: l } = {}) {
        this._names = {}, this._prefixes = u, this._parent = l;
      }
      toName(u) {
        return u instanceof e.Name ? u : this.name(u);
      }
      name(u) {
        return new e.Name(this._newName(u));
      }
      _newName(u) {
        const l = this._names[u] || this._nameGroup(u);
        return `${u}${l.index++}`;
      }
      _nameGroup(u) {
        var l, h;
        if (!((h = (l = this._parent) === null || l === void 0 ? void 0 : l._prefixes) === null || h === void 0) && h.has(u) || this._prefixes && !this._prefixes.has(u))
          throw new Error(`CodeGen: prefix "${u}" is not allowed in this scope`);
        return this._names[u] = { prefix: u, index: 0 };
      }
    }
    t.Scope = o;
    class s extends e.Name {
      constructor(u, l) {
        super(l), this.prefix = u;
      }
      setValue(u, { property: l, itemIndex: h }) {
        this.value = u, this.scopePath = (0, e._)`.${new e.Name(l)}[${h}]`;
      }
    }
    t.ValueScopeName = s;
    const i = (0, e._)`\n`;
    class a extends o {
      constructor(u) {
        super(u), this._values = {}, this._scope = u.scope, this.opts = { ...u, _n: u.lines ? i : e.nil };
      }
      get() {
        return this._scope;
      }
      name(u) {
        return new s(u, this._newName(u));
      }
      value(u, l) {
        var h;
        if (l.ref === void 0)
          throw new Error("CodeGen: ref must be passed in value");
        const m = this.toName(u), { prefix: _ } = m, S = (h = l.key) !== null && h !== void 0 ? h : l.ref;
        let $ = this._values[_];
        if ($) {
          const g = $.get(S);
          if (g)
            return g;
        } else
          $ = this._values[_] = /* @__PURE__ */ new Map();
        $.set(S, m);
        const v = this._scope[_] || (this._scope[_] = []), y = v.length;
        return v[y] = l.ref, m.setValue(l, { property: _, itemIndex: y }), m;
      }
      getValue(u, l) {
        const h = this._values[u];
        if (h)
          return h.get(l);
      }
      scopeRefs(u, l = this._values) {
        return this._reduceValues(l, (h) => {
          if (h.scopePath === void 0)
            throw new Error(`CodeGen: name "${h}" has no value`);
          return (0, e._)`${u}${h.scopePath}`;
        });
      }
      scopeCode(u = this._values, l, h) {
        return this._reduceValues(u, (m) => {
          if (m.value === void 0)
            throw new Error(`CodeGen: name "${m}" has no value`);
          return m.value.code;
        }, l, h);
      }
      _reduceValues(u, l, h = {}, m) {
        let _ = e.nil;
        for (const S in u) {
          const $ = u[S];
          if (!$)
            continue;
          const v = h[S] = h[S] || /* @__PURE__ */ new Map();
          $.forEach((y) => {
            if (v.has(y))
              return;
            v.set(y, n.Started);
            let g = l(y);
            if (g) {
              const w = this.opts.es5 ? t.varKinds.var : t.varKinds.const;
              _ = (0, e._)`${_}${w} ${y} = ${g};${this.opts._n}`;
            } else if (g = m == null ? void 0 : m(y))
              _ = (0, e._)`${_}${g}${this.opts._n}`;
            else
              throw new r(y);
            v.set(y, n.Completed);
          });
        }
        return _;
      }
    }
    t.ValueScope = a;
  }(bo)), bo;
}
var Oi;
function ie() {
  return Oi || (Oi = 1, function(t) {
    Object.defineProperty(t, "__esModule", { value: !0 }), t.or = t.and = t.not = t.CodeGen = t.operators = t.varKinds = t.ValueScopeName = t.ValueScope = t.Scope = t.Name = t.regexpCode = t.stringify = t.getProperty = t.nil = t.strConcat = t.str = t._ = void 0;
    const e = /* @__PURE__ */ Un(), r = /* @__PURE__ */ Ii();
    var n = /* @__PURE__ */ Un();
    Object.defineProperty(t, "_", { enumerable: !0, get: function() {
      return n._;
    } }), Object.defineProperty(t, "str", { enumerable: !0, get: function() {
      return n.str;
    } }), Object.defineProperty(t, "strConcat", { enumerable: !0, get: function() {
      return n.strConcat;
    } }), Object.defineProperty(t, "nil", { enumerable: !0, get: function() {
      return n.nil;
    } }), Object.defineProperty(t, "getProperty", { enumerable: !0, get: function() {
      return n.getProperty;
    } }), Object.defineProperty(t, "stringify", { enumerable: !0, get: function() {
      return n.stringify;
    } }), Object.defineProperty(t, "regexpCode", { enumerable: !0, get: function() {
      return n.regexpCode;
    } }), Object.defineProperty(t, "Name", { enumerable: !0, get: function() {
      return n.Name;
    } });
    var o = /* @__PURE__ */ Ii();
    Object.defineProperty(t, "Scope", { enumerable: !0, get: function() {
      return o.Scope;
    } }), Object.defineProperty(t, "ValueScope", { enumerable: !0, get: function() {
      return o.ValueScope;
    } }), Object.defineProperty(t, "ValueScopeName", { enumerable: !0, get: function() {
      return o.ValueScopeName;
    } }), Object.defineProperty(t, "varKinds", { enumerable: !0, get: function() {
      return o.varKinds;
    } }), t.operators = {
      GT: new e._Code(">"),
      GTE: new e._Code(">="),
      LT: new e._Code("<"),
      LTE: new e._Code("<="),
      EQ: new e._Code("==="),
      NEQ: new e._Code("!=="),
      NOT: new e._Code("!"),
      OR: new e._Code("||"),
      AND: new e._Code("&&"),
      ADD: new e._Code("+")
    };
    class s {
      optimizeNodes() {
        return this;
      }
      optimizeNames(b, T) {
        return this;
      }
    }
    class i extends s {
      constructor(b, T, D) {
        super(), this.varKind = b, this.name = T, this.rhs = D;
      }
      render({ es5: b, _n: T }) {
        const D = b ? r.varKinds.var : this.varKind, J = this.rhs === void 0 ? "" : ` = ${this.rhs}`;
        return `${D} ${this.name}${J};` + T;
      }
      optimizeNames(b, T) {
        if (b[this.name.str])
          return this.rhs && (this.rhs = x(this.rhs, b, T)), this;
      }
      get names() {
        return this.rhs instanceof e._CodeOrName ? this.rhs.names : {};
      }
    }
    class a extends s {
      constructor(b, T, D) {
        super(), this.lhs = b, this.rhs = T, this.sideEffects = D;
      }
      render({ _n: b }) {
        return `${this.lhs} = ${this.rhs};` + b;
      }
      optimizeNames(b, T) {
        if (!(this.lhs instanceof e.Name && !b[this.lhs.str] && !this.sideEffects))
          return this.rhs = x(this.rhs, b, T), this;
      }
      get names() {
        const b = this.lhs instanceof e.Name ? {} : { ...this.lhs.names };
        return P(b, this.rhs);
      }
    }
    class c extends a {
      constructor(b, T, D, J) {
        super(b, D, J), this.op = T;
      }
      render({ _n: b }) {
        return `${this.lhs} ${this.op}= ${this.rhs};` + b;
      }
    }
    class u extends s {
      constructor(b) {
        super(), this.label = b, this.names = {};
      }
      render({ _n: b }) {
        return `${this.label}:` + b;
      }
    }
    class l extends s {
      constructor(b) {
        super(), this.label = b, this.names = {};
      }
      render({ _n: b }) {
        return `break${this.label ? ` ${this.label}` : ""};` + b;
      }
    }
    class h extends s {
      constructor(b) {
        super(), this.error = b;
      }
      render({ _n: b }) {
        return `throw ${this.error};` + b;
      }
      get names() {
        return this.error.names;
      }
    }
    class m extends s {
      constructor(b) {
        super(), this.code = b;
      }
      render({ _n: b }) {
        return `${this.code};` + b;
      }
      optimizeNodes() {
        return `${this.code}` ? this : void 0;
      }
      optimizeNames(b, T) {
        return this.code = x(this.code, b, T), this;
      }
      get names() {
        return this.code instanceof e._CodeOrName ? this.code.names : {};
      }
    }
    class _ extends s {
      constructor(b = []) {
        super(), this.nodes = b;
      }
      render(b) {
        return this.nodes.reduce((T, D) => T + D.render(b), "");
      }
      optimizeNodes() {
        const { nodes: b } = this;
        let T = b.length;
        for (; T--; ) {
          const D = b[T].optimizeNodes();
          Array.isArray(D) ? b.splice(T, 1, ...D) : D ? b[T] = D : b.splice(T, 1);
        }
        return b.length > 0 ? this : void 0;
      }
      optimizeNames(b, T) {
        const { nodes: D } = this;
        let J = D.length;
        for (; J--; ) {
          const Y = D[J];
          Y.optimizeNames(b, T) || (G(b, Y.names), D.splice(J, 1));
        }
        return D.length > 0 ? this : void 0;
      }
      get names() {
        return this.nodes.reduce((b, T) => M(b, T.names), {});
      }
    }
    class S extends _ {
      render(b) {
        return "{" + b._n + super.render(b) + "}" + b._n;
      }
    }
    class $ extends _ {
    }
    class v extends S {
    }
    v.kind = "else";
    class y extends S {
      constructor(b, T) {
        super(T), this.condition = b;
      }
      render(b) {
        let T = `if(${this.condition})` + super.render(b);
        return this.else && (T += "else " + this.else.render(b)), T;
      }
      optimizeNodes() {
        super.optimizeNodes();
        const b = this.condition;
        if (b === !0)
          return this.nodes;
        let T = this.else;
        if (T) {
          const D = T.optimizeNodes();
          T = this.else = Array.isArray(D) ? new v(D) : D;
        }
        if (T)
          return b === !1 ? T instanceof y ? T : T.nodes : this.nodes.length ? this : new y(fe(b), T instanceof y ? [T] : T.nodes);
        if (!(b === !1 || !this.nodes.length))
          return this;
      }
      optimizeNames(b, T) {
        var D;
        if (this.else = (D = this.else) === null || D === void 0 ? void 0 : D.optimizeNames(b, T), !!(super.optimizeNames(b, T) || this.else))
          return this.condition = x(this.condition, b, T), this;
      }
      get names() {
        const b = super.names;
        return P(b, this.condition), this.else && M(b, this.else.names), b;
      }
    }
    y.kind = "if";
    class g extends S {
    }
    g.kind = "for";
    class w extends g {
      constructor(b) {
        super(), this.iteration = b;
      }
      render(b) {
        return `for(${this.iteration})` + super.render(b);
      }
      optimizeNames(b, T) {
        if (super.optimizeNames(b, T))
          return this.iteration = x(this.iteration, b, T), this;
      }
      get names() {
        return M(super.names, this.iteration.names);
      }
    }
    class k extends g {
      constructor(b, T, D, J) {
        super(), this.varKind = b, this.name = T, this.from = D, this.to = J;
      }
      render(b) {
        const T = b.es5 ? r.varKinds.var : this.varKind, { name: D, from: J, to: Y } = this;
        return `for(${T} ${D}=${J}; ${D}<${Y}; ${D}++)` + super.render(b);
      }
      get names() {
        const b = P(super.names, this.from);
        return P(b, this.to);
      }
    }
    class f extends g {
      constructor(b, T, D, J) {
        super(), this.loop = b, this.varKind = T, this.name = D, this.iterable = J;
      }
      render(b) {
        return `for(${this.varKind} ${this.name} ${this.loop} ${this.iterable})` + super.render(b);
      }
      optimizeNames(b, T) {
        if (super.optimizeNames(b, T))
          return this.iterable = x(this.iterable, b, T), this;
      }
      get names() {
        return M(super.names, this.iterable.names);
      }
    }
    class d extends S {
      constructor(b, T, D) {
        super(), this.name = b, this.args = T, this.async = D;
      }
      render(b) {
        return `${this.async ? "async " : ""}function ${this.name}(${this.args})` + super.render(b);
      }
    }
    d.kind = "func";
    class p extends _ {
      render(b) {
        return "return " + super.render(b);
      }
    }
    p.kind = "return";
    class E extends S {
      render(b) {
        let T = "try" + super.render(b);
        return this.catch && (T += this.catch.render(b)), this.finally && (T += this.finally.render(b)), T;
      }
      optimizeNodes() {
        var b, T;
        return super.optimizeNodes(), (b = this.catch) === null || b === void 0 || b.optimizeNodes(), (T = this.finally) === null || T === void 0 || T.optimizeNodes(), this;
      }
      optimizeNames(b, T) {
        var D, J;
        return super.optimizeNames(b, T), (D = this.catch) === null || D === void 0 || D.optimizeNames(b, T), (J = this.finally) === null || J === void 0 || J.optimizeNames(b, T), this;
      }
      get names() {
        const b = super.names;
        return this.catch && M(b, this.catch.names), this.finally && M(b, this.finally.names), b;
      }
    }
    class I extends S {
      constructor(b) {
        super(), this.error = b;
      }
      render(b) {
        return `catch(${this.error})` + super.render(b);
      }
    }
    I.kind = "catch";
    class R extends S {
      render(b) {
        return "finally" + super.render(b);
      }
    }
    R.kind = "finally";
    class A {
      constructor(b, T = {}) {
        this._values = {}, this._blockStarts = [], this._constants = {}, this.opts = { ...T, _n: T.lines ? `
` : "" }, this._extScope = b, this._scope = new r.Scope({ parent: b }), this._nodes = [new $()];
      }
      toString() {
        return this._root.render(this.opts);
      }
      // returns unique name in the internal scope
      name(b) {
        return this._scope.name(b);
      }
      // reserves unique name in the external scope
      scopeName(b) {
        return this._extScope.name(b);
      }
      // reserves unique name in the external scope and assigns value to it
      scopeValue(b, T) {
        const D = this._extScope.value(b, T);
        return (this._values[D.prefix] || (this._values[D.prefix] = /* @__PURE__ */ new Set())).add(D), D;
      }
      getScopeValue(b, T) {
        return this._extScope.getValue(b, T);
      }
      // return code that assigns values in the external scope to the names that are used internally
      // (same names that were returned by gen.scopeName or gen.scopeValue)
      scopeRefs(b) {
        return this._extScope.scopeRefs(b, this._values);
      }
      scopeCode() {
        return this._extScope.scopeCode(this._values);
      }
      _def(b, T, D, J) {
        const Y = this._scope.toName(T);
        return D !== void 0 && J && (this._constants[Y.str] = D), this._leafNode(new i(b, Y, D)), Y;
      }
      // `const` declaration (`var` in es5 mode)
      const(b, T, D) {
        return this._def(r.varKinds.const, b, T, D);
      }
      // `let` declaration with optional assignment (`var` in es5 mode)
      let(b, T, D) {
        return this._def(r.varKinds.let, b, T, D);
      }
      // `var` declaration with optional assignment
      var(b, T, D) {
        return this._def(r.varKinds.var, b, T, D);
      }
      // assignment code
      assign(b, T, D) {
        return this._leafNode(new a(b, T, D));
      }
      // `+=` code
      add(b, T) {
        return this._leafNode(new c(b, t.operators.ADD, T));
      }
      // appends passed SafeExpr to code or executes Block
      code(b) {
        return typeof b == "function" ? b() : b !== e.nil && this._leafNode(new m(b)), this;
      }
      // returns code for object literal for the passed argument list of key-value pairs
      object(...b) {
        const T = ["{"];
        for (const [D, J] of b)
          T.length > 1 && T.push(","), T.push(D), (D !== J || this.opts.es5) && (T.push(":"), (0, e.addCodeArg)(T, J));
        return T.push("}"), new e._Code(T);
      }
      // `if` clause (or statement if `thenBody` and, optionally, `elseBody` are passed)
      if(b, T, D) {
        if (this._blockNode(new y(b)), T && D)
          this.code(T).else().code(D).endIf();
        else if (T)
          this.code(T).endIf();
        else if (D)
          throw new Error('CodeGen: "else" body without "then" body');
        return this;
      }
      // `else if` clause - invalid without `if` or after `else` clauses
      elseIf(b) {
        return this._elseNode(new y(b));
      }
      // `else` clause - only valid after `if` or `else if` clauses
      else() {
        return this._elseNode(new v());
      }
      // end `if` statement (needed if gen.if was used only with condition)
      endIf() {
        return this._endBlockNode(y, v);
      }
      _for(b, T) {
        return this._blockNode(b), T && this.code(T).endFor(), this;
      }
      // a generic `for` clause (or statement if `forBody` is passed)
      for(b, T) {
        return this._for(new w(b), T);
      }
      // `for` statement for a range of values
      forRange(b, T, D, J, Y = this.opts.es5 ? r.varKinds.var : r.varKinds.let) {
        const he = this._scope.toName(b);
        return this._for(new k(Y, he, T, D), () => J(he));
      }
      // `for-of` statement (in es5 mode replace with a normal for loop)
      forOf(b, T, D, J = r.varKinds.const) {
        const Y = this._scope.toName(b);
        if (this.opts.es5) {
          const he = T instanceof e.Name ? T : this.var("_arr", T);
          return this.forRange("_i", 0, (0, e._)`${he}.length`, (le) => {
            this.var(Y, (0, e._)`${he}[${le}]`), D(Y);
          });
        }
        return this._for(new f("of", J, Y, T), () => D(Y));
      }
      // `for-in` statement.
      // With option `ownProperties` replaced with a `for-of` loop for object keys
      forIn(b, T, D, J = this.opts.es5 ? r.varKinds.var : r.varKinds.const) {
        if (this.opts.ownProperties)
          return this.forOf(b, (0, e._)`Object.keys(${T})`, D);
        const Y = this._scope.toName(b);
        return this._for(new f("in", J, Y, T), () => D(Y));
      }
      // end `for` loop
      endFor() {
        return this._endBlockNode(g);
      }
      // `label` statement
      label(b) {
        return this._leafNode(new u(b));
      }
      // `break` statement
      break(b) {
        return this._leafNode(new l(b));
      }
      // `return` statement
      return(b) {
        const T = new p();
        if (this._blockNode(T), this.code(b), T.nodes.length !== 1)
          throw new Error('CodeGen: "return" should have one node');
        return this._endBlockNode(p);
      }
      // `try` statement
      try(b, T, D) {
        if (!T && !D)
          throw new Error('CodeGen: "try" without "catch" and "finally"');
        const J = new E();
        if (this._blockNode(J), this.code(b), T) {
          const Y = this.name("e");
          this._currNode = J.catch = new I(Y), T(Y);
        }
        return D && (this._currNode = J.finally = new R(), this.code(D)), this._endBlockNode(I, R);
      }
      // `throw` statement
      throw(b) {
        return this._leafNode(new h(b));
      }
      // start self-balancing block
      block(b, T) {
        return this._blockStarts.push(this._nodes.length), b && this.code(b).endBlock(T), this;
      }
      // end the current self-balancing block
      endBlock(b) {
        const T = this._blockStarts.pop();
        if (T === void 0)
          throw new Error("CodeGen: not in self-balancing block");
        const D = this._nodes.length - T;
        if (D < 0 || b !== void 0 && D !== b)
          throw new Error(`CodeGen: wrong number of nodes: ${D} vs ${b} expected`);
        return this._nodes.length = T, this;
      }
      // `function` heading (or definition if funcBody is passed)
      func(b, T = e.nil, D, J) {
        return this._blockNode(new d(b, T, D)), J && this.code(J).endFunc(), this;
      }
      // end function definition
      endFunc() {
        return this._endBlockNode(d);
      }
      optimize(b = 1) {
        for (; b-- > 0; )
          this._root.optimizeNodes(), this._root.optimizeNames(this._root.names, this._constants);
      }
      _leafNode(b) {
        return this._currNode.nodes.push(b), this;
      }
      _blockNode(b) {
        this._currNode.nodes.push(b), this._nodes.push(b);
      }
      _endBlockNode(b, T) {
        const D = this._currNode;
        if (D instanceof b || T && D instanceof T)
          return this._nodes.pop(), this;
        throw new Error(`CodeGen: not in block "${T ? `${b.kind}/${T.kind}` : b.kind}"`);
      }
      _elseNode(b) {
        const T = this._currNode;
        if (!(T instanceof y))
          throw new Error('CodeGen: "else" without "if"');
        return this._currNode = T.else = b, this;
      }
      get _root() {
        return this._nodes[0];
      }
      get _currNode() {
        const b = this._nodes;
        return b[b.length - 1];
      }
      set _currNode(b) {
        const T = this._nodes;
        T[T.length - 1] = b;
      }
    }
    t.CodeGen = A;
    function M(j, b) {
      for (const T in b)
        j[T] = (j[T] || 0) + (b[T] || 0);
      return j;
    }
    function P(j, b) {
      return b instanceof e._CodeOrName ? M(j, b.names) : j;
    }
    function x(j, b, T) {
      if (j instanceof e.Name)
        return D(j);
      if (!J(j))
        return j;
      return new e._Code(j._items.reduce((Y, he) => (he instanceof e.Name && (he = D(he)), he instanceof e._Code ? Y.push(...he._items) : Y.push(he), Y), []));
      function D(Y) {
        const he = T[Y.str];
        return he === void 0 || b[Y.str] !== 1 ? Y : (delete b[Y.str], he);
      }
      function J(Y) {
        return Y instanceof e._Code && Y._items.some((he) => he instanceof e.Name && b[he.str] === 1 && T[he.str] !== void 0);
      }
    }
    function G(j, b) {
      for (const T in b)
        j[T] = (j[T] || 0) - (b[T] || 0);
    }
    function fe(j) {
      return typeof j == "boolean" || typeof j == "number" || j === null ? !j : (0, e._)`!${U(j)}`;
    }
    t.not = fe;
    const ue = z(t.operators.AND);
    function ee(...j) {
      return j.reduce(ue);
    }
    t.and = ee;
    const Pe = z(t.operators.OR);
    function L(...j) {
      return j.reduce(Pe);
    }
    t.or = L;
    function z(j) {
      return (b, T) => b === e.nil ? T : T === e.nil ? b : (0, e._)`${U(b)} ${j} ${U(T)}`;
    }
    function U(j) {
      return j instanceof e.Name ? j : (0, e._)`(${j})`;
    }
  }(vo)), vo;
}
var se = {}, zi;
function de() {
  if (zi) return se;
  zi = 1, Object.defineProperty(se, "__esModule", { value: !0 }), se.checkStrictMode = se.getErrorPath = se.Type = se.useFunc = se.setEvaluated = se.evaluatedPropsToName = se.mergeEvaluated = se.eachItem = se.unescapeJsonPointer = se.escapeJsonPointer = se.escapeFragment = se.unescapeFragment = se.schemaRefOrVal = se.schemaHasRulesButRef = se.schemaHasRules = se.checkUnknownRules = se.alwaysValidSchema = se.toHash = void 0;
  const t = /* @__PURE__ */ ie(), e = /* @__PURE__ */ Un();
  function r(f) {
    const d = {};
    for (const p of f)
      d[p] = !0;
    return d;
  }
  se.toHash = r;
  function n(f, d) {
    return typeof d == "boolean" ? d : Object.keys(d).length === 0 ? !0 : (o(f, d), !s(d, f.self.RULES.all));
  }
  se.alwaysValidSchema = n;
  function o(f, d = f.schema) {
    const { opts: p, self: E } = f;
    if (!p.strictSchema || typeof d == "boolean")
      return;
    const I = E.RULES.keywords;
    for (const R in d)
      I[R] || k(f, `unknown keyword: "${R}"`);
  }
  se.checkUnknownRules = o;
  function s(f, d) {
    if (typeof f == "boolean")
      return !f;
    for (const p in f)
      if (d[p])
        return !0;
    return !1;
  }
  se.schemaHasRules = s;
  function i(f, d) {
    if (typeof f == "boolean")
      return !f;
    for (const p in f)
      if (p !== "$ref" && d.all[p])
        return !0;
    return !1;
  }
  se.schemaHasRulesButRef = i;
  function a({ topSchemaRef: f, schemaPath: d }, p, E, I) {
    if (!I) {
      if (typeof p == "number" || typeof p == "boolean")
        return p;
      if (typeof p == "string")
        return (0, t._)`${p}`;
    }
    return (0, t._)`${f}${d}${(0, t.getProperty)(E)}`;
  }
  se.schemaRefOrVal = a;
  function c(f) {
    return h(decodeURIComponent(f));
  }
  se.unescapeFragment = c;
  function u(f) {
    return encodeURIComponent(l(f));
  }
  se.escapeFragment = u;
  function l(f) {
    return typeof f == "number" ? `${f}` : f.replace(/~/g, "~0").replace(/\//g, "~1");
  }
  se.escapeJsonPointer = l;
  function h(f) {
    return f.replace(/~1/g, "/").replace(/~0/g, "~");
  }
  se.unescapeJsonPointer = h;
  function m(f, d) {
    if (Array.isArray(f))
      for (const p of f)
        d(p);
    else
      d(f);
  }
  se.eachItem = m;
  function _({ mergeNames: f, mergeToName: d, mergeValues: p, resultToName: E }) {
    return (I, R, A, M) => {
      const P = A === void 0 ? R : A instanceof t.Name ? (R instanceof t.Name ? f(I, R, A) : d(I, R, A), A) : R instanceof t.Name ? (d(I, A, R), R) : p(R, A);
      return M === t.Name && !(P instanceof t.Name) ? E(I, P) : P;
    };
  }
  se.mergeEvaluated = {
    props: _({
      mergeNames: (f, d, p) => f.if((0, t._)`${p} !== true && ${d} !== undefined`, () => {
        f.if((0, t._)`${d} === true`, () => f.assign(p, !0), () => f.assign(p, (0, t._)`${p} || {}`).code((0, t._)`Object.assign(${p}, ${d})`));
      }),
      mergeToName: (f, d, p) => f.if((0, t._)`${p} !== true`, () => {
        d === !0 ? f.assign(p, !0) : (f.assign(p, (0, t._)`${p} || {}`), $(f, p, d));
      }),
      mergeValues: (f, d) => f === !0 ? !0 : { ...f, ...d },
      resultToName: S
    }),
    items: _({
      mergeNames: (f, d, p) => f.if((0, t._)`${p} !== true && ${d} !== undefined`, () => f.assign(p, (0, t._)`${d} === true ? true : ${p} > ${d} ? ${p} : ${d}`)),
      mergeToName: (f, d, p) => f.if((0, t._)`${p} !== true`, () => f.assign(p, d === !0 ? !0 : (0, t._)`${p} > ${d} ? ${p} : ${d}`)),
      mergeValues: (f, d) => f === !0 ? !0 : Math.max(f, d),
      resultToName: (f, d) => f.var("items", d)
    })
  };
  function S(f, d) {
    if (d === !0)
      return f.var("props", !0);
    const p = f.var("props", (0, t._)`{}`);
    return d !== void 0 && $(f, p, d), p;
  }
  se.evaluatedPropsToName = S;
  function $(f, d, p) {
    Object.keys(p).forEach((E) => f.assign((0, t._)`${d}${(0, t.getProperty)(E)}`, !0));
  }
  se.setEvaluated = $;
  const v = {};
  function y(f, d) {
    return f.scopeValue("func", {
      ref: d,
      code: v[d.code] || (v[d.code] = new e._Code(d.code))
    });
  }
  se.useFunc = y;
  var g;
  (function(f) {
    f[f.Num = 0] = "Num", f[f.Str = 1] = "Str";
  })(g || (se.Type = g = {}));
  function w(f, d, p) {
    if (f instanceof t.Name) {
      const E = d === g.Num;
      return p ? E ? (0, t._)`"[" + ${f} + "]"` : (0, t._)`"['" + ${f} + "']"` : E ? (0, t._)`"/" + ${f}` : (0, t._)`"/" + ${f}.replace(/~/g, "~0").replace(/\\//g, "~1")`;
    }
    return p ? (0, t.getProperty)(f).toString() : "/" + l(f);
  }
  se.getErrorPath = w;
  function k(f, d, p = f.opts.strictSchema) {
    if (p) {
      if (d = `strict mode: ${d}`, p === !0)
        throw new Error(d);
      f.self.logger.warn(d);
    }
  }
  return se.checkStrictMode = k, se;
}
var Vr = {}, Ni;
function zt() {
  if (Ni) return Vr;
  Ni = 1, Object.defineProperty(Vr, "__esModule", { value: !0 });
  const t = /* @__PURE__ */ ie(), e = {
    // validation function arguments
    data: new t.Name("data"),
    // data passed to validation function
    // args passed from referencing schema
    valCxt: new t.Name("valCxt"),
    // validation/data context - should not be used directly, it is destructured to the names below
    instancePath: new t.Name("instancePath"),
    parentData: new t.Name("parentData"),
    parentDataProperty: new t.Name("parentDataProperty"),
    rootData: new t.Name("rootData"),
    // root data - same as the data passed to the first/top validation function
    dynamicAnchors: new t.Name("dynamicAnchors"),
    // used to support recursiveRef and dynamicRef
    // function scoped variables
    vErrors: new t.Name("vErrors"),
    // null or array of validation errors
    errors: new t.Name("errors"),
    // counter of validation errors
    this: new t.Name("this"),
    // "globals"
    self: new t.Name("self"),
    scope: new t.Name("scope"),
    // JTD serialize/parse name for JSON string and position
    json: new t.Name("json"),
    jsonPos: new t.Name("jsonPos"),
    jsonLen: new t.Name("jsonLen"),
    jsonPart: new t.Name("jsonPart")
  };
  return Vr.default = e, Vr;
}
var Mi;
function oo() {
  return Mi || (Mi = 1, function(t) {
    Object.defineProperty(t, "__esModule", { value: !0 }), t.extendErrors = t.resetErrorsCount = t.reportExtraError = t.reportError = t.keyword$DataError = t.keywordError = void 0;
    const e = /* @__PURE__ */ ie(), r = /* @__PURE__ */ de(), n = /* @__PURE__ */ zt();
    t.keywordError = {
      message: ({ keyword: v }) => (0, e.str)`must pass "${v}" keyword validation`
    }, t.keyword$DataError = {
      message: ({ keyword: v, schemaType: y }) => y ? (0, e.str)`"${v}" keyword must be ${y} ($data)` : (0, e.str)`"${v}" keyword is invalid ($data)`
    };
    function o(v, y = t.keywordError, g, w) {
      const { it: k } = v, { gen: f, compositeRule: d, allErrors: p } = k, E = h(v, y, g);
      w ?? (d || p) ? c(f, E) : u(k, (0, e._)`[${E}]`);
    }
    t.reportError = o;
    function s(v, y = t.keywordError, g) {
      const { it: w } = v, { gen: k, compositeRule: f, allErrors: d } = w, p = h(v, y, g);
      c(k, p), f || d || u(w, n.default.vErrors);
    }
    t.reportExtraError = s;
    function i(v, y) {
      v.assign(n.default.errors, y), v.if((0, e._)`${n.default.vErrors} !== null`, () => v.if(y, () => v.assign((0, e._)`${n.default.vErrors}.length`, y), () => v.assign(n.default.vErrors, null)));
    }
    t.resetErrorsCount = i;
    function a({ gen: v, keyword: y, schemaValue: g, data: w, errsCount: k, it: f }) {
      if (k === void 0)
        throw new Error("ajv implementation error");
      const d = v.name("err");
      v.forRange("i", k, n.default.errors, (p) => {
        v.const(d, (0, e._)`${n.default.vErrors}[${p}]`), v.if((0, e._)`${d}.instancePath === undefined`, () => v.assign((0, e._)`${d}.instancePath`, (0, e.strConcat)(n.default.instancePath, f.errorPath))), v.assign((0, e._)`${d}.schemaPath`, (0, e.str)`${f.errSchemaPath}/${y}`), f.opts.verbose && (v.assign((0, e._)`${d}.schema`, g), v.assign((0, e._)`${d}.data`, w));
      });
    }
    t.extendErrors = a;
    function c(v, y) {
      const g = v.const("err", y);
      v.if((0, e._)`${n.default.vErrors} === null`, () => v.assign(n.default.vErrors, (0, e._)`[${g}]`), (0, e._)`${n.default.vErrors}.push(${g})`), v.code((0, e._)`${n.default.errors}++`);
    }
    function u(v, y) {
      const { gen: g, validateName: w, schemaEnv: k } = v;
      k.$async ? g.throw((0, e._)`new ${v.ValidationError}(${y})`) : (g.assign((0, e._)`${w}.errors`, y), g.return(!1));
    }
    const l = {
      keyword: new e.Name("keyword"),
      schemaPath: new e.Name("schemaPath"),
      // also used in JTD errors
      params: new e.Name("params"),
      propertyName: new e.Name("propertyName"),
      message: new e.Name("message"),
      schema: new e.Name("schema"),
      parentSchema: new e.Name("parentSchema")
    };
    function h(v, y, g) {
      const { createErrors: w } = v.it;
      return w === !1 ? (0, e._)`{}` : m(v, y, g);
    }
    function m(v, y, g = {}) {
      const { gen: w, it: k } = v, f = [
        _(k, g),
        S(v, g)
      ];
      return $(v, y, f), w.object(...f);
    }
    function _({ errorPath: v }, { instancePath: y }) {
      const g = y ? (0, e.str)`${v}${(0, r.getErrorPath)(y, r.Type.Str)}` : v;
      return [n.default.instancePath, (0, e.strConcat)(n.default.instancePath, g)];
    }
    function S({ keyword: v, it: { errSchemaPath: y } }, { schemaPath: g, parentSchema: w }) {
      let k = w ? y : (0, e.str)`${y}/${v}`;
      return g && (k = (0, e.str)`${k}${(0, r.getErrorPath)(g, r.Type.Str)}`), [l.schemaPath, k];
    }
    function $(v, { params: y, message: g }, w) {
      const { keyword: k, data: f, schemaValue: d, it: p } = v, { opts: E, propertyName: I, topSchemaRef: R, schemaPath: A } = p;
      w.push([l.keyword, k], [l.params, typeof y == "function" ? y(v) : y || (0, e._)`{}`]), E.messages && w.push([l.message, typeof g == "function" ? g(v) : g]), E.verbose && w.push([l.schema, d], [l.parentSchema, (0, e._)`${R}${A}`], [n.default.data, f]), I && w.push([l.propertyName, I]);
    }
  }(yo)), yo;
}
var ji;
function Mg() {
  if (ji) return Mt;
  ji = 1, Object.defineProperty(Mt, "__esModule", { value: !0 }), Mt.boolOrEmptySchema = Mt.topBoolOrEmptySchema = void 0;
  const t = /* @__PURE__ */ oo(), e = /* @__PURE__ */ ie(), r = /* @__PURE__ */ zt(), n = {
    message: "boolean schema is false"
  };
  function o(a) {
    const { gen: c, schema: u, validateName: l } = a;
    u === !1 ? i(a, !1) : typeof u == "object" && u.$async === !0 ? c.return(r.default.data) : (c.assign((0, e._)`${l}.errors`, null), c.return(!0));
  }
  Mt.topBoolOrEmptySchema = o;
  function s(a, c) {
    const { gen: u, schema: l } = a;
    l === !1 ? (u.var(c, !1), i(a)) : u.var(c, !0);
  }
  Mt.boolOrEmptySchema = s;
  function i(a, c) {
    const { gen: u, data: l } = a, h = {
      gen: u,
      keyword: "false schema",
      data: l,
      schema: !1,
      schemaCode: !1,
      schemaValue: !1,
      params: {},
      it: a
    };
    (0, t.reportError)(h, n, void 0, c);
  }
  return Mt;
}
var De = {}, jt = {}, xi;
function Eu() {
  if (xi) return jt;
  xi = 1, Object.defineProperty(jt, "__esModule", { value: !0 }), jt.getRules = jt.isJSONType = void 0;
  const t = ["string", "number", "integer", "boolean", "null", "object", "array"], e = new Set(t);
  function r(o) {
    return typeof o == "string" && e.has(o);
  }
  jt.isJSONType = r;
  function n() {
    const o = {
      number: { type: "number", rules: [] },
      string: { type: "string", rules: [] },
      array: { type: "array", rules: [] },
      object: { type: "object", rules: [] }
    };
    return {
      types: { ...o, integer: !0, boolean: !0, null: !0 },
      rules: [{ rules: [] }, o.number, o.string, o.array, o.object],
      post: { rules: [] },
      all: {},
      keywords: {}
    };
  }
  return jt.getRules = n, jt;
}
var vt = {}, qi;
function ku() {
  if (qi) return vt;
  qi = 1, Object.defineProperty(vt, "__esModule", { value: !0 }), vt.shouldUseRule = vt.shouldUseGroup = vt.schemaHasRulesForType = void 0;
  function t({ schema: n, self: o }, s) {
    const i = o.RULES.types[s];
    return i && i !== !0 && e(n, i);
  }
  vt.schemaHasRulesForType = t;
  function e(n, o) {
    return o.rules.some((s) => r(n, s));
  }
  vt.shouldUseGroup = e;
  function r(n, o) {
    var s;
    return n[o.keyword] !== void 0 || ((s = o.definition.implements) === null || s === void 0 ? void 0 : s.some((i) => n[i] !== void 0));
  }
  return vt.shouldUseRule = r, vt;
}
var Di;
function Fn() {
  if (Di) return De;
  Di = 1, Object.defineProperty(De, "__esModule", { value: !0 }), De.reportTypeError = De.checkDataTypes = De.checkDataType = De.coerceAndCheckDataType = De.getJSONTypes = De.getSchemaTypes = De.DataType = void 0;
  const t = /* @__PURE__ */ Eu(), e = /* @__PURE__ */ ku(), r = /* @__PURE__ */ oo(), n = /* @__PURE__ */ ie(), o = /* @__PURE__ */ de();
  var s;
  (function(g) {
    g[g.Correct = 0] = "Correct", g[g.Wrong = 1] = "Wrong";
  })(s || (De.DataType = s = {}));
  function i(g) {
    const w = a(g.type);
    if (w.includes("null")) {
      if (g.nullable === !1)
        throw new Error("type: null contradicts nullable: false");
    } else {
      if (!w.length && g.nullable !== void 0)
        throw new Error('"nullable" cannot be used without "type"');
      g.nullable === !0 && w.push("null");
    }
    return w;
  }
  De.getSchemaTypes = i;
  function a(g) {
    const w = Array.isArray(g) ? g : g ? [g] : [];
    if (w.every(t.isJSONType))
      return w;
    throw new Error("type must be JSONType or JSONType[]: " + w.join(","));
  }
  De.getJSONTypes = a;
  function c(g, w) {
    const { gen: k, data: f, opts: d } = g, p = l(w, d.coerceTypes), E = w.length > 0 && !(p.length === 0 && w.length === 1 && (0, e.schemaHasRulesForType)(g, w[0]));
    if (E) {
      const I = S(w, f, d.strictNumbers, s.Wrong);
      k.if(I, () => {
        p.length ? h(g, w, p) : v(g);
      });
    }
    return E;
  }
  De.coerceAndCheckDataType = c;
  const u = /* @__PURE__ */ new Set(["string", "number", "integer", "boolean", "null"]);
  function l(g, w) {
    return w ? g.filter((k) => u.has(k) || w === "array" && k === "array") : [];
  }
  function h(g, w, k) {
    const { gen: f, data: d, opts: p } = g, E = f.let("dataType", (0, n._)`typeof ${d}`), I = f.let("coerced", (0, n._)`undefined`);
    p.coerceTypes === "array" && f.if((0, n._)`${E} == 'object' && Array.isArray(${d}) && ${d}.length == 1`, () => f.assign(d, (0, n._)`${d}[0]`).assign(E, (0, n._)`typeof ${d}`).if(S(w, d, p.strictNumbers), () => f.assign(I, d))), f.if((0, n._)`${I} !== undefined`);
    for (const A of k)
      (u.has(A) || A === "array" && p.coerceTypes === "array") && R(A);
    f.else(), v(g), f.endIf(), f.if((0, n._)`${I} !== undefined`, () => {
      f.assign(d, I), m(g, I);
    });
    function R(A) {
      switch (A) {
        case "string":
          f.elseIf((0, n._)`${E} == "number" || ${E} == "boolean"`).assign(I, (0, n._)`"" + ${d}`).elseIf((0, n._)`${d} === null`).assign(I, (0, n._)`""`);
          return;
        case "number":
          f.elseIf((0, n._)`${E} == "boolean" || ${d} === null
              || (${E} == "string" && ${d} && ${d} == +${d})`).assign(I, (0, n._)`+${d}`);
          return;
        case "integer":
          f.elseIf((0, n._)`${E} === "boolean" || ${d} === null
              || (${E} === "string" && ${d} && ${d} == +${d} && !(${d} % 1))`).assign(I, (0, n._)`+${d}`);
          return;
        case "boolean":
          f.elseIf((0, n._)`${d} === "false" || ${d} === 0 || ${d} === null`).assign(I, !1).elseIf((0, n._)`${d} === "true" || ${d} === 1`).assign(I, !0);
          return;
        case "null":
          f.elseIf((0, n._)`${d} === "" || ${d} === 0 || ${d} === false`), f.assign(I, null);
          return;
        case "array":
          f.elseIf((0, n._)`${E} === "string" || ${E} === "number"
              || ${E} === "boolean" || ${d} === null`).assign(I, (0, n._)`[${d}]`);
      }
    }
  }
  function m({ gen: g, parentData: w, parentDataProperty: k }, f) {
    g.if((0, n._)`${w} !== undefined`, () => g.assign((0, n._)`${w}[${k}]`, f));
  }
  function _(g, w, k, f = s.Correct) {
    const d = f === s.Correct ? n.operators.EQ : n.operators.NEQ;
    let p;
    switch (g) {
      case "null":
        return (0, n._)`${w} ${d} null`;
      case "array":
        p = (0, n._)`Array.isArray(${w})`;
        break;
      case "object":
        p = (0, n._)`${w} && typeof ${w} == "object" && !Array.isArray(${w})`;
        break;
      case "integer":
        p = E((0, n._)`!(${w} % 1) && !isNaN(${w})`);
        break;
      case "number":
        p = E();
        break;
      default:
        return (0, n._)`typeof ${w} ${d} ${g}`;
    }
    return f === s.Correct ? p : (0, n.not)(p);
    function E(I = n.nil) {
      return (0, n.and)((0, n._)`typeof ${w} == "number"`, I, k ? (0, n._)`isFinite(${w})` : n.nil);
    }
  }
  De.checkDataType = _;
  function S(g, w, k, f) {
    if (g.length === 1)
      return _(g[0], w, k, f);
    let d;
    const p = (0, o.toHash)(g);
    if (p.array && p.object) {
      const E = (0, n._)`typeof ${w} != "object"`;
      d = p.null ? E : (0, n._)`!${w} || ${E}`, delete p.null, delete p.array, delete p.object;
    } else
      d = n.nil;
    p.number && delete p.integer;
    for (const E in p)
      d = (0, n.and)(d, _(E, w, k, f));
    return d;
  }
  De.checkDataTypes = S;
  const $ = {
    message: ({ schema: g }) => `must be ${g}`,
    params: ({ schema: g, schemaValue: w }) => typeof g == "string" ? (0, n._)`{type: ${g}}` : (0, n._)`{type: ${w}}`
  };
  function v(g) {
    const w = y(g);
    (0, r.reportError)(w, $);
  }
  De.reportTypeError = v;
  function y(g) {
    const { gen: w, data: k, schema: f } = g, d = (0, o.schemaRefOrVal)(g, f, "type");
    return {
      gen: w,
      keyword: "type",
      data: k,
      schema: f.type,
      schemaCode: d,
      schemaValue: d,
      parentSchema: f,
      params: {},
      it: g
    };
  }
  return De;
}
var _r = {}, Ui;
function jg() {
  if (Ui) return _r;
  Ui = 1, Object.defineProperty(_r, "__esModule", { value: !0 }), _r.assignDefaults = void 0;
  const t = /* @__PURE__ */ ie(), e = /* @__PURE__ */ de();
  function r(o, s) {
    const { properties: i, items: a } = o.schema;
    if (s === "object" && i)
      for (const c in i)
        n(o, c, i[c].default);
    else s === "array" && Array.isArray(a) && a.forEach((c, u) => n(o, u, c.default));
  }
  _r.assignDefaults = r;
  function n(o, s, i) {
    const { gen: a, compositeRule: c, data: u, opts: l } = o;
    if (i === void 0)
      return;
    const h = (0, t._)`${u}${(0, t.getProperty)(s)}`;
    if (c) {
      (0, e.checkStrictMode)(o, `default is ignored for: ${h}`);
      return;
    }
    let m = (0, t._)`${h} === undefined`;
    l.useDefaults === "empty" && (m = (0, t._)`${m} || ${h} === null || ${h} === ""`), a.if(m, (0, t._)`${h} = ${(0, t.stringify)(i)}`);
  }
  return _r;
}
var ht = {}, me = {}, Fi;
function _t() {
  if (Fi) return me;
  Fi = 1, Object.defineProperty(me, "__esModule", { value: !0 }), me.validateUnion = me.validateArray = me.usePattern = me.callValidateCode = me.schemaProperties = me.allSchemaProperties = me.noPropertyInData = me.propertyInData = me.isOwnProperty = me.hasPropFunc = me.reportMissingProp = me.checkMissingProp = me.checkReportMissingProp = void 0;
  const t = /* @__PURE__ */ ie(), e = /* @__PURE__ */ de(), r = /* @__PURE__ */ zt(), n = /* @__PURE__ */ de();
  function o(g, w) {
    const { gen: k, data: f, it: d } = g;
    k.if(l(k, f, w, d.opts.ownProperties), () => {
      g.setParams({ missingProperty: (0, t._)`${w}` }, !0), g.error();
    });
  }
  me.checkReportMissingProp = o;
  function s({ gen: g, data: w, it: { opts: k } }, f, d) {
    return (0, t.or)(...f.map((p) => (0, t.and)(l(g, w, p, k.ownProperties), (0, t._)`${d} = ${p}`)));
  }
  me.checkMissingProp = s;
  function i(g, w) {
    g.setParams({ missingProperty: w }, !0), g.error();
  }
  me.reportMissingProp = i;
  function a(g) {
    return g.scopeValue("func", {
      // eslint-disable-next-line @typescript-eslint/unbound-method
      ref: Object.prototype.hasOwnProperty,
      code: (0, t._)`Object.prototype.hasOwnProperty`
    });
  }
  me.hasPropFunc = a;
  function c(g, w, k) {
    return (0, t._)`${a(g)}.call(${w}, ${k})`;
  }
  me.isOwnProperty = c;
  function u(g, w, k, f) {
    const d = (0, t._)`${w}${(0, t.getProperty)(k)} !== undefined`;
    return f ? (0, t._)`${d} && ${c(g, w, k)}` : d;
  }
  me.propertyInData = u;
  function l(g, w, k, f) {
    const d = (0, t._)`${w}${(0, t.getProperty)(k)} === undefined`;
    return f ? (0, t.or)(d, (0, t.not)(c(g, w, k))) : d;
  }
  me.noPropertyInData = l;
  function h(g) {
    return g ? Object.keys(g).filter((w) => w !== "__proto__") : [];
  }
  me.allSchemaProperties = h;
  function m(g, w) {
    return h(w).filter((k) => !(0, e.alwaysValidSchema)(g, w[k]));
  }
  me.schemaProperties = m;
  function _({ schemaCode: g, data: w, it: { gen: k, topSchemaRef: f, schemaPath: d, errorPath: p }, it: E }, I, R, A) {
    const M = A ? (0, t._)`${g}, ${w}, ${f}${d}` : w, P = [
      [r.default.instancePath, (0, t.strConcat)(r.default.instancePath, p)],
      [r.default.parentData, E.parentData],
      [r.default.parentDataProperty, E.parentDataProperty],
      [r.default.rootData, r.default.rootData]
    ];
    E.opts.dynamicRef && P.push([r.default.dynamicAnchors, r.default.dynamicAnchors]);
    const x = (0, t._)`${M}, ${k.object(...P)}`;
    return R !== t.nil ? (0, t._)`${I}.call(${R}, ${x})` : (0, t._)`${I}(${x})`;
  }
  me.callValidateCode = _;
  const S = (0, t._)`new RegExp`;
  function $({ gen: g, it: { opts: w } }, k) {
    const f = w.unicodeRegExp ? "u" : "", { regExp: d } = w.code, p = d(k, f);
    return g.scopeValue("pattern", {
      key: p.toString(),
      ref: p,
      code: (0, t._)`${d.code === "new RegExp" ? S : (0, n.useFunc)(g, d)}(${k}, ${f})`
    });
  }
  me.usePattern = $;
  function v(g) {
    const { gen: w, data: k, keyword: f, it: d } = g, p = w.name("valid");
    if (d.allErrors) {
      const I = w.let("valid", !0);
      return E(() => w.assign(I, !1)), I;
    }
    return w.var(p, !0), E(() => w.break()), p;
    function E(I) {
      const R = w.const("len", (0, t._)`${k}.length`);
      w.forRange("i", 0, R, (A) => {
        g.subschema({
          keyword: f,
          dataProp: A,
          dataPropType: e.Type.Num
        }, p), w.if((0, t.not)(p), I);
      });
    }
  }
  me.validateArray = v;
  function y(g) {
    const { gen: w, schema: k, keyword: f, it: d } = g;
    if (!Array.isArray(k))
      throw new Error("ajv implementation error");
    if (k.some((R) => (0, e.alwaysValidSchema)(d, R)) && !d.opts.unevaluated)
      return;
    const E = w.let("valid", !1), I = w.name("_valid");
    w.block(() => k.forEach((R, A) => {
      const M = g.subschema({
        keyword: f,
        schemaProp: A,
        compositeRule: !0
      }, I);
      w.assign(E, (0, t._)`${E} || ${I}`), g.mergeValidEvaluated(M, I) || w.if((0, t.not)(E));
    })), g.result(E, () => g.reset(), () => g.error(!0));
  }
  return me.validateUnion = y, me;
}
var Li;
function xg() {
  if (Li) return ht;
  Li = 1, Object.defineProperty(ht, "__esModule", { value: !0 }), ht.validateKeywordUsage = ht.validSchemaType = ht.funcKeywordCode = ht.macroKeywordCode = void 0;
  const t = /* @__PURE__ */ ie(), e = /* @__PURE__ */ zt(), r = /* @__PURE__ */ _t(), n = /* @__PURE__ */ oo();
  function o(m, _) {
    const { gen: S, keyword: $, schema: v, parentSchema: y, it: g } = m, w = _.macro.call(g.self, v, y, g), k = u(S, $, w);
    g.opts.validateSchema !== !1 && g.self.validateSchema(w, !0);
    const f = S.name("valid");
    m.subschema({
      schema: w,
      schemaPath: t.nil,
      errSchemaPath: `${g.errSchemaPath}/${$}`,
      topSchemaRef: k,
      compositeRule: !0
    }, f), m.pass(f, () => m.error(!0));
  }
  ht.macroKeywordCode = o;
  function s(m, _) {
    var S;
    const { gen: $, keyword: v, schema: y, parentSchema: g, $data: w, it: k } = m;
    c(k, _);
    const f = !w && _.compile ? _.compile.call(k.self, y, g, k) : _.validate, d = u($, v, f), p = $.let("valid");
    m.block$data(p, E), m.ok((S = _.valid) !== null && S !== void 0 ? S : p);
    function E() {
      if (_.errors === !1)
        A(), _.modifying && i(m), M(() => m.error());
      else {
        const P = _.async ? I() : R();
        _.modifying && i(m), M(() => a(m, P));
      }
    }
    function I() {
      const P = $.let("ruleErrs", null);
      return $.try(() => A((0, t._)`await `), (x) => $.assign(p, !1).if((0, t._)`${x} instanceof ${k.ValidationError}`, () => $.assign(P, (0, t._)`${x}.errors`), () => $.throw(x))), P;
    }
    function R() {
      const P = (0, t._)`${d}.errors`;
      return $.assign(P, null), A(t.nil), P;
    }
    function A(P = _.async ? (0, t._)`await ` : t.nil) {
      const x = k.opts.passContext ? e.default.this : e.default.self, G = !("compile" in _ && !w || _.schema === !1);
      $.assign(p, (0, t._)`${P}${(0, r.callValidateCode)(m, d, x, G)}`, _.modifying);
    }
    function M(P) {
      var x;
      $.if((0, t.not)((x = _.valid) !== null && x !== void 0 ? x : p), P);
    }
  }
  ht.funcKeywordCode = s;
  function i(m) {
    const { gen: _, data: S, it: $ } = m;
    _.if($.parentData, () => _.assign(S, (0, t._)`${$.parentData}[${$.parentDataProperty}]`));
  }
  function a(m, _) {
    const { gen: S } = m;
    S.if((0, t._)`Array.isArray(${_})`, () => {
      S.assign(e.default.vErrors, (0, t._)`${e.default.vErrors} === null ? ${_} : ${e.default.vErrors}.concat(${_})`).assign(e.default.errors, (0, t._)`${e.default.vErrors}.length`), (0, n.extendErrors)(m);
    }, () => m.error());
  }
  function c({ schemaEnv: m }, _) {
    if (_.async && !m.$async)
      throw new Error("async keyword in sync schema");
  }
  function u(m, _, S) {
    if (S === void 0)
      throw new Error(`keyword "${_}" failed to compile`);
    return m.scopeValue("keyword", typeof S == "function" ? { ref: S } : { ref: S, code: (0, t.stringify)(S) });
  }
  function l(m, _, S = !1) {
    return !_.length || _.some(($) => $ === "array" ? Array.isArray(m) : $ === "object" ? m && typeof m == "object" && !Array.isArray(m) : typeof m == $ || S && typeof m > "u");
  }
  ht.validSchemaType = l;
  function h({ schema: m, opts: _, self: S, errSchemaPath: $ }, v, y) {
    if (Array.isArray(v.keyword) ? !v.keyword.includes(y) : v.keyword !== y)
      throw new Error("ajv implementation error");
    const g = v.dependencies;
    if (g != null && g.some((w) => !Object.prototype.hasOwnProperty.call(m, w)))
      throw new Error(`parent schema must have dependencies of ${y}: ${g.join(",")}`);
    if (v.validateSchema && !v.validateSchema(m[y])) {
      const k = `keyword "${y}" value is invalid at path "${$}": ` + S.errorsText(v.validateSchema.errors);
      if (_.validateSchema === "log")
        S.logger.error(k);
      else
        throw new Error(k);
    }
  }
  return ht.validateKeywordUsage = h, ht;
}
var wt = {}, Zi;
function qg() {
  if (Zi) return wt;
  Zi = 1, Object.defineProperty(wt, "__esModule", { value: !0 }), wt.extendSubschemaMode = wt.extendSubschemaData = wt.getSubschema = void 0;
  const t = /* @__PURE__ */ ie(), e = /* @__PURE__ */ de();
  function r(s, { keyword: i, schemaProp: a, schema: c, schemaPath: u, errSchemaPath: l, topSchemaRef: h }) {
    if (i !== void 0 && c !== void 0)
      throw new Error('both "keyword" and "schema" passed, only one allowed');
    if (i !== void 0) {
      const m = s.schema[i];
      return a === void 0 ? {
        schema: m,
        schemaPath: (0, t._)`${s.schemaPath}${(0, t.getProperty)(i)}`,
        errSchemaPath: `${s.errSchemaPath}/${i}`
      } : {
        schema: m[a],
        schemaPath: (0, t._)`${s.schemaPath}${(0, t.getProperty)(i)}${(0, t.getProperty)(a)}`,
        errSchemaPath: `${s.errSchemaPath}/${i}/${(0, e.escapeFragment)(a)}`
      };
    }
    if (c !== void 0) {
      if (u === void 0 || l === void 0 || h === void 0)
        throw new Error('"schemaPath", "errSchemaPath" and "topSchemaRef" are required with "schema"');
      return {
        schema: c,
        schemaPath: u,
        topSchemaRef: h,
        errSchemaPath: l
      };
    }
    throw new Error('either "keyword" or "schema" must be passed');
  }
  wt.getSubschema = r;
  function n(s, i, { dataProp: a, dataPropType: c, data: u, dataTypes: l, propertyName: h }) {
    if (u !== void 0 && a !== void 0)
      throw new Error('both "data" and "dataProp" passed, only one allowed');
    const { gen: m } = i;
    if (a !== void 0) {
      const { errorPath: S, dataPathArr: $, opts: v } = i, y = m.let("data", (0, t._)`${i.data}${(0, t.getProperty)(a)}`, !0);
      _(y), s.errorPath = (0, t.str)`${S}${(0, e.getErrorPath)(a, c, v.jsPropertySyntax)}`, s.parentDataProperty = (0, t._)`${a}`, s.dataPathArr = [...$, s.parentDataProperty];
    }
    if (u !== void 0) {
      const S = u instanceof t.Name ? u : m.let("data", u, !0);
      _(S), h !== void 0 && (s.propertyName = h);
    }
    l && (s.dataTypes = l);
    function _(S) {
      s.data = S, s.dataLevel = i.dataLevel + 1, s.dataTypes = [], i.definedProperties = /* @__PURE__ */ new Set(), s.parentData = i.data, s.dataNames = [...i.dataNames, S];
    }
  }
  wt.extendSubschemaData = n;
  function o(s, { jtdDiscriminator: i, jtdMetadata: a, compositeRule: c, createErrors: u, allErrors: l }) {
    c !== void 0 && (s.compositeRule = c), u !== void 0 && (s.createErrors = u), l !== void 0 && (s.allErrors = l), s.jtdDiscriminator = i, s.jtdMetadata = a;
  }
  return wt.extendSubschemaMode = o, wt;
}
var We = {}, $o, Vi;
function Cu() {
  return Vi || (Vi = 1, $o = function t(e, r) {
    if (e === r) return !0;
    if (e && r && typeof e == "object" && typeof r == "object") {
      if (e.constructor !== r.constructor) return !1;
      var n, o, s;
      if (Array.isArray(e)) {
        if (n = e.length, n != r.length) return !1;
        for (o = n; o-- !== 0; )
          if (!t(e[o], r[o])) return !1;
        return !0;
      }
      if (e.constructor === RegExp) return e.source === r.source && e.flags === r.flags;
      if (e.valueOf !== Object.prototype.valueOf) return e.valueOf() === r.valueOf();
      if (e.toString !== Object.prototype.toString) return e.toString() === r.toString();
      if (s = Object.keys(e), n = s.length, n !== Object.keys(r).length) return !1;
      for (o = n; o-- !== 0; )
        if (!Object.prototype.hasOwnProperty.call(r, s[o])) return !1;
      for (o = n; o-- !== 0; ) {
        var i = s[o];
        if (!t(e[i], r[i])) return !1;
      }
      return !0;
    }
    return e !== e && r !== r;
  }), $o;
}
var So = { exports: {} }, Hi;
function Dg() {
  if (Hi) return So.exports;
  Hi = 1;
  var t = So.exports = function(n, o, s) {
    typeof o == "function" && (s = o, o = {}), s = o.cb || s;
    var i = typeof s == "function" ? s : s.pre || function() {
    }, a = s.post || function() {
    };
    e(o, i, a, n, "", n);
  };
  t.keywords = {
    additionalItems: !0,
    items: !0,
    contains: !0,
    additionalProperties: !0,
    propertyNames: !0,
    not: !0,
    if: !0,
    then: !0,
    else: !0
  }, t.arrayKeywords = {
    items: !0,
    allOf: !0,
    anyOf: !0,
    oneOf: !0
  }, t.propsKeywords = {
    $defs: !0,
    definitions: !0,
    properties: !0,
    patternProperties: !0,
    dependencies: !0
  }, t.skipKeywords = {
    default: !0,
    enum: !0,
    const: !0,
    required: !0,
    maximum: !0,
    minimum: !0,
    exclusiveMaximum: !0,
    exclusiveMinimum: !0,
    multipleOf: !0,
    maxLength: !0,
    minLength: !0,
    pattern: !0,
    format: !0,
    maxItems: !0,
    minItems: !0,
    uniqueItems: !0,
    maxProperties: !0,
    minProperties: !0
  };
  function e(n, o, s, i, a, c, u, l, h, m) {
    if (i && typeof i == "object" && !Array.isArray(i)) {
      o(i, a, c, u, l, h, m);
      for (var _ in i) {
        var S = i[_];
        if (Array.isArray(S)) {
          if (_ in t.arrayKeywords)
            for (var $ = 0; $ < S.length; $++)
              e(n, o, s, S[$], a + "/" + _ + "/" + $, c, a, _, i, $);
        } else if (_ in t.propsKeywords) {
          if (S && typeof S == "object")
            for (var v in S)
              e(n, o, s, S[v], a + "/" + _ + "/" + r(v), c, a, _, i, v);
        } else (_ in t.keywords || n.allKeys && !(_ in t.skipKeywords)) && e(n, o, s, S, a + "/" + _, c, a, _, i);
      }
      s(i, a, c, u, l, h, m);
    }
  }
  function r(n) {
    return n.replace(/~/g, "~0").replace(/\//g, "~1");
  }
  return So.exports;
}
var Wi;
function so() {
  if (Wi) return We;
  Wi = 1, Object.defineProperty(We, "__esModule", { value: !0 }), We.getSchemaRefs = We.resolveUrl = We.normalizeId = We._getFullPath = We.getFullPath = We.inlineRef = void 0;
  const t = /* @__PURE__ */ de(), e = Cu(), r = Dg(), n = /* @__PURE__ */ new Set([
    "type",
    "format",
    "pattern",
    "maxLength",
    "minLength",
    "maxProperties",
    "minProperties",
    "maxItems",
    "minItems",
    "maximum",
    "minimum",
    "uniqueItems",
    "multipleOf",
    "required",
    "enum",
    "const"
  ]);
  function o($, v = !0) {
    return typeof $ == "boolean" ? !0 : v === !0 ? !i($) : v ? a($) <= v : !1;
  }
  We.inlineRef = o;
  const s = /* @__PURE__ */ new Set([
    "$ref",
    "$recursiveRef",
    "$recursiveAnchor",
    "$dynamicRef",
    "$dynamicAnchor"
  ]);
  function i($) {
    for (const v in $) {
      if (s.has(v))
        return !0;
      const y = $[v];
      if (Array.isArray(y) && y.some(i) || typeof y == "object" && i(y))
        return !0;
    }
    return !1;
  }
  function a($) {
    let v = 0;
    for (const y in $) {
      if (y === "$ref")
        return 1 / 0;
      if (v++, !n.has(y) && (typeof $[y] == "object" && (0, t.eachItem)($[y], (g) => v += a(g)), v === 1 / 0))
        return 1 / 0;
    }
    return v;
  }
  function c($, v = "", y) {
    y !== !1 && (v = h(v));
    const g = $.parse(v);
    return u($, g);
  }
  We.getFullPath = c;
  function u($, v) {
    return $.serialize(v).split("#")[0] + "#";
  }
  We._getFullPath = u;
  const l = /#\/?$/;
  function h($) {
    return $ ? $.replace(l, "") : "";
  }
  We.normalizeId = h;
  function m($, v, y) {
    return y = h(y), $.resolve(v, y);
  }
  We.resolveUrl = m;
  const _ = /^[a-z_][-a-z0-9._]*$/i;
  function S($, v) {
    if (typeof $ == "boolean")
      return {};
    const { schemaId: y, uriResolver: g } = this.opts, w = h($[y] || v), k = { "": w }, f = c(g, w, !1), d = {}, p = /* @__PURE__ */ new Set();
    return r($, { allKeys: !0 }, (R, A, M, P) => {
      if (P === void 0)
        return;
      const x = f + A;
      let G = k[P];
      typeof R[y] == "string" && (G = fe.call(this, R[y])), ue.call(this, R.$anchor), ue.call(this, R.$dynamicAnchor), k[A] = G;
      function fe(ee) {
        const Pe = this.opts.uriResolver.resolve;
        if (ee = h(G ? Pe(G, ee) : ee), p.has(ee))
          throw I(ee);
        p.add(ee);
        let L = this.refs[ee];
        return typeof L == "string" && (L = this.refs[L]), typeof L == "object" ? E(R, L.schema, ee) : ee !== h(x) && (ee[0] === "#" ? (E(R, d[ee], ee), d[ee] = R) : this.refs[ee] = x), ee;
      }
      function ue(ee) {
        if (typeof ee == "string") {
          if (!_.test(ee))
            throw new Error(`invalid anchor "${ee}"`);
          fe.call(this, `#${ee}`);
        }
      }
    }), d;
    function E(R, A, M) {
      if (A !== void 0 && !e(R, A))
        throw I(M);
    }
    function I(R) {
      return new Error(`reference "${R}" resolves to more than one schema`);
    }
  }
  return We.getSchemaRefs = S, We;
}
var Bi;
function io() {
  if (Bi) return yt;
  Bi = 1, Object.defineProperty(yt, "__esModule", { value: !0 }), yt.getData = yt.KeywordCxt = yt.validateFunctionCode = void 0;
  const t = /* @__PURE__ */ Mg(), e = /* @__PURE__ */ Fn(), r = /* @__PURE__ */ ku(), n = /* @__PURE__ */ Fn(), o = /* @__PURE__ */ jg(), s = /* @__PURE__ */ xg(), i = /* @__PURE__ */ qg(), a = /* @__PURE__ */ ie(), c = /* @__PURE__ */ zt(), u = /* @__PURE__ */ so(), l = /* @__PURE__ */ de(), h = /* @__PURE__ */ oo();
  function m(O) {
    if (f(O) && (p(O), k(O))) {
      v(O);
      return;
    }
    _(O, () => (0, t.topBoolOrEmptySchema)(O));
  }
  yt.validateFunctionCode = m;
  function _({ gen: O, validateName: N, schema: F, schemaEnv: V, opts: X }, ae) {
    X.code.es5 ? O.func(N, (0, a._)`${c.default.data}, ${c.default.valCxt}`, V.$async, () => {
      O.code((0, a._)`"use strict"; ${g(F, X)}`), $(O, X), O.code(ae);
    }) : O.func(N, (0, a._)`${c.default.data}, ${S(X)}`, V.$async, () => O.code(g(F, X)).code(ae));
  }
  function S(O) {
    return (0, a._)`{${c.default.instancePath}="", ${c.default.parentData}, ${c.default.parentDataProperty}, ${c.default.rootData}=${c.default.data}${O.dynamicRef ? (0, a._)`, ${c.default.dynamicAnchors}={}` : a.nil}}={}`;
  }
  function $(O, N) {
    O.if(c.default.valCxt, () => {
      O.var(c.default.instancePath, (0, a._)`${c.default.valCxt}.${c.default.instancePath}`), O.var(c.default.parentData, (0, a._)`${c.default.valCxt}.${c.default.parentData}`), O.var(c.default.parentDataProperty, (0, a._)`${c.default.valCxt}.${c.default.parentDataProperty}`), O.var(c.default.rootData, (0, a._)`${c.default.valCxt}.${c.default.rootData}`), N.dynamicRef && O.var(c.default.dynamicAnchors, (0, a._)`${c.default.valCxt}.${c.default.dynamicAnchors}`);
    }, () => {
      O.var(c.default.instancePath, (0, a._)`""`), O.var(c.default.parentData, (0, a._)`undefined`), O.var(c.default.parentDataProperty, (0, a._)`undefined`), O.var(c.default.rootData, c.default.data), N.dynamicRef && O.var(c.default.dynamicAnchors, (0, a._)`{}`);
    });
  }
  function v(O) {
    const { schema: N, opts: F, gen: V } = O;
    _(O, () => {
      F.$comment && N.$comment && P(O), R(O), V.let(c.default.vErrors, null), V.let(c.default.errors, 0), F.unevaluated && y(O), E(O), x(O);
    });
  }
  function y(O) {
    const { gen: N, validateName: F } = O;
    O.evaluated = N.const("evaluated", (0, a._)`${F}.evaluated`), N.if((0, a._)`${O.evaluated}.dynamicProps`, () => N.assign((0, a._)`${O.evaluated}.props`, (0, a._)`undefined`)), N.if((0, a._)`${O.evaluated}.dynamicItems`, () => N.assign((0, a._)`${O.evaluated}.items`, (0, a._)`undefined`));
  }
  function g(O, N) {
    const F = typeof O == "object" && O[N.schemaId];
    return F && (N.code.source || N.code.process) ? (0, a._)`/*# sourceURL=${F} */` : a.nil;
  }
  function w(O, N) {
    if (f(O) && (p(O), k(O))) {
      d(O, N);
      return;
    }
    (0, t.boolOrEmptySchema)(O, N);
  }
  function k({ schema: O, self: N }) {
    if (typeof O == "boolean")
      return !O;
    for (const F in O)
      if (N.RULES.all[F])
        return !0;
    return !1;
  }
  function f(O) {
    return typeof O.schema != "boolean";
  }
  function d(O, N) {
    const { schema: F, gen: V, opts: X } = O;
    X.$comment && F.$comment && P(O), A(O), M(O);
    const ae = V.const("_errs", c.default.errors);
    E(O, ae), V.var(N, (0, a._)`${ae} === ${c.default.errors}`);
  }
  function p(O) {
    (0, l.checkUnknownRules)(O), I(O);
  }
  function E(O, N) {
    if (O.opts.jtd)
      return fe(O, [], !1, N);
    const F = (0, e.getSchemaTypes)(O.schema), V = (0, e.coerceAndCheckDataType)(O, F);
    fe(O, F, !V, N);
  }
  function I(O) {
    const { schema: N, errSchemaPath: F, opts: V, self: X } = O;
    N.$ref && V.ignoreKeywordsWithRef && (0, l.schemaHasRulesButRef)(N, X.RULES) && X.logger.warn(`$ref: keywords ignored in schema at path "${F}"`);
  }
  function R(O) {
    const { schema: N, opts: F } = O;
    N.default !== void 0 && F.useDefaults && F.strictSchema && (0, l.checkStrictMode)(O, "default is ignored in the schema root");
  }
  function A(O) {
    const N = O.schema[O.opts.schemaId];
    N && (O.baseId = (0, u.resolveUrl)(O.opts.uriResolver, O.baseId, N));
  }
  function M(O) {
    if (O.schema.$async && !O.schemaEnv.$async)
      throw new Error("async schema in sync schema");
  }
  function P({ gen: O, schemaEnv: N, schema: F, errSchemaPath: V, opts: X }) {
    const ae = F.$comment;
    if (X.$comment === !0)
      O.code((0, a._)`${c.default.self}.logger.log(${ae})`);
    else if (typeof X.$comment == "function") {
      const xe = (0, a.str)`${V}/$comment`, ft = O.scopeValue("root", { ref: N.root });
      O.code((0, a._)`${c.default.self}.opts.$comment(${ae}, ${xe}, ${ft}.schema)`);
    }
  }
  function x(O) {
    const { gen: N, schemaEnv: F, validateName: V, ValidationError: X, opts: ae } = O;
    F.$async ? N.if((0, a._)`${c.default.errors} === 0`, () => N.return(c.default.data), () => N.throw((0, a._)`new ${X}(${c.default.vErrors})`)) : (N.assign((0, a._)`${V}.errors`, c.default.vErrors), ae.unevaluated && G(O), N.return((0, a._)`${c.default.errors} === 0`));
  }
  function G({ gen: O, evaluated: N, props: F, items: V }) {
    F instanceof a.Name && O.assign((0, a._)`${N}.props`, F), V instanceof a.Name && O.assign((0, a._)`${N}.items`, V);
  }
  function fe(O, N, F, V) {
    const { gen: X, schema: ae, data: xe, allErrors: ft, opts: Qe, self: Xe } = O, { RULES: qe } = Xe;
    if (ae.$ref && (Qe.ignoreKeywordsWithRef || !(0, l.schemaHasRulesButRef)(ae, qe))) {
      X.block(() => J(O, "$ref", qe.all.$ref.definition));
      return;
    }
    Qe.jtd || ee(O, N), X.block(() => {
      for (const it of qe.rules)
        Kt(it);
      Kt(qe.post);
    });
    function Kt(it) {
      (0, r.shouldUseGroup)(ae, it) && (it.type ? (X.if((0, n.checkDataType)(it.type, xe, Qe.strictNumbers)), ue(O, it), N.length === 1 && N[0] === it.type && F && (X.else(), (0, n.reportTypeError)(O)), X.endIf()) : ue(O, it), ft || X.if((0, a._)`${c.default.errors} === ${V || 0}`));
    }
  }
  function ue(O, N) {
    const { gen: F, schema: V, opts: { useDefaults: X } } = O;
    X && (0, o.assignDefaults)(O, N.type), F.block(() => {
      for (const ae of N.rules)
        (0, r.shouldUseRule)(V, ae) && J(O, ae.keyword, ae.definition, N.type);
    });
  }
  function ee(O, N) {
    O.schemaEnv.meta || !O.opts.strictTypes || (Pe(O, N), O.opts.allowUnionTypes || L(O, N), z(O, O.dataTypes));
  }
  function Pe(O, N) {
    if (N.length) {
      if (!O.dataTypes.length) {
        O.dataTypes = N;
        return;
      }
      N.forEach((F) => {
        j(O.dataTypes, F) || T(O, `type "${F}" not allowed by context "${O.dataTypes.join(",")}"`);
      }), b(O, N);
    }
  }
  function L(O, N) {
    N.length > 1 && !(N.length === 2 && N.includes("null")) && T(O, "use allowUnionTypes to allow union type keyword");
  }
  function z(O, N) {
    const F = O.self.RULES.all;
    for (const V in F) {
      const X = F[V];
      if (typeof X == "object" && (0, r.shouldUseRule)(O.schema, X)) {
        const { type: ae } = X.definition;
        ae.length && !ae.some((xe) => U(N, xe)) && T(O, `missing type "${ae.join(",")}" for keyword "${V}"`);
      }
    }
  }
  function U(O, N) {
    return O.includes(N) || N === "number" && O.includes("integer");
  }
  function j(O, N) {
    return O.includes(N) || N === "integer" && O.includes("number");
  }
  function b(O, N) {
    const F = [];
    for (const V of O.dataTypes)
      j(N, V) ? F.push(V) : N.includes("integer") && V === "number" && F.push("integer");
    O.dataTypes = F;
  }
  function T(O, N) {
    const F = O.schemaEnv.baseId + O.errSchemaPath;
    N += ` at "${F}" (strictTypes)`, (0, l.checkStrictMode)(O, N, O.opts.strictTypes);
  }
  class D {
    constructor(N, F, V) {
      if ((0, s.validateKeywordUsage)(N, F, V), this.gen = N.gen, this.allErrors = N.allErrors, this.keyword = V, this.data = N.data, this.schema = N.schema[V], this.$data = F.$data && N.opts.$data && this.schema && this.schema.$data, this.schemaValue = (0, l.schemaRefOrVal)(N, this.schema, V, this.$data), this.schemaType = F.schemaType, this.parentSchema = N.schema, this.params = {}, this.it = N, this.def = F, this.$data)
        this.schemaCode = N.gen.const("vSchema", le(this.$data, N));
      else if (this.schemaCode = this.schemaValue, !(0, s.validSchemaType)(this.schema, F.schemaType, F.allowUndefined))
        throw new Error(`${V} value must be ${JSON.stringify(F.schemaType)}`);
      ("code" in F ? F.trackErrors : F.errors !== !1) && (this.errsCount = N.gen.const("_errs", c.default.errors));
    }
    result(N, F, V) {
      this.failResult((0, a.not)(N), F, V);
    }
    failResult(N, F, V) {
      this.gen.if(N), V ? V() : this.error(), F ? (this.gen.else(), F(), this.allErrors && this.gen.endIf()) : this.allErrors ? this.gen.endIf() : this.gen.else();
    }
    pass(N, F) {
      this.failResult((0, a.not)(N), void 0, F);
    }
    fail(N) {
      if (N === void 0) {
        this.error(), this.allErrors || this.gen.if(!1);
        return;
      }
      this.gen.if(N), this.error(), this.allErrors ? this.gen.endIf() : this.gen.else();
    }
    fail$data(N) {
      if (!this.$data)
        return this.fail(N);
      const { schemaCode: F } = this;
      this.fail((0, a._)`${F} !== undefined && (${(0, a.or)(this.invalid$data(), N)})`);
    }
    error(N, F, V) {
      if (F) {
        this.setParams(F), this._error(N, V), this.setParams({});
        return;
      }
      this._error(N, V);
    }
    _error(N, F) {
      (N ? h.reportExtraError : h.reportError)(this, this.def.error, F);
    }
    $dataError() {
      (0, h.reportError)(this, this.def.$dataError || h.keyword$DataError);
    }
    reset() {
      if (this.errsCount === void 0)
        throw new Error('add "trackErrors" to keyword definition');
      (0, h.resetErrorsCount)(this.gen, this.errsCount);
    }
    ok(N) {
      this.allErrors || this.gen.if(N);
    }
    setParams(N, F) {
      F ? Object.assign(this.params, N) : this.params = N;
    }
    block$data(N, F, V = a.nil) {
      this.gen.block(() => {
        this.check$data(N, V), F();
      });
    }
    check$data(N = a.nil, F = a.nil) {
      if (!this.$data)
        return;
      const { gen: V, schemaCode: X, schemaType: ae, def: xe } = this;
      V.if((0, a.or)((0, a._)`${X} === undefined`, F)), N !== a.nil && V.assign(N, !0), (ae.length || xe.validateSchema) && (V.elseIf(this.invalid$data()), this.$dataError(), N !== a.nil && V.assign(N, !1)), V.else();
    }
    invalid$data() {
      const { gen: N, schemaCode: F, schemaType: V, def: X, it: ae } = this;
      return (0, a.or)(xe(), ft());
      function xe() {
        if (V.length) {
          if (!(F instanceof a.Name))
            throw new Error("ajv implementation error");
          const Qe = Array.isArray(V) ? V : [V];
          return (0, a._)`${(0, n.checkDataTypes)(Qe, F, ae.opts.strictNumbers, n.DataType.Wrong)}`;
        }
        return a.nil;
      }
      function ft() {
        if (X.validateSchema) {
          const Qe = N.scopeValue("validate$data", { ref: X.validateSchema });
          return (0, a._)`!${Qe}(${F})`;
        }
        return a.nil;
      }
    }
    subschema(N, F) {
      const V = (0, i.getSubschema)(this.it, N);
      (0, i.extendSubschemaData)(V, this.it, N), (0, i.extendSubschemaMode)(V, N);
      const X = { ...this.it, ...V, items: void 0, props: void 0 };
      return w(X, F), X;
    }
    mergeEvaluated(N, F) {
      const { it: V, gen: X } = this;
      V.opts.unevaluated && (V.props !== !0 && N.props !== void 0 && (V.props = l.mergeEvaluated.props(X, N.props, V.props, F)), V.items !== !0 && N.items !== void 0 && (V.items = l.mergeEvaluated.items(X, N.items, V.items, F)));
    }
    mergeValidEvaluated(N, F) {
      const { it: V, gen: X } = this;
      if (V.opts.unevaluated && (V.props !== !0 || V.items !== !0))
        return X.if(F, () => this.mergeEvaluated(N, a.Name)), !0;
    }
  }
  yt.KeywordCxt = D;
  function J(O, N, F, V) {
    const X = new D(O, F, N);
    "code" in F ? F.code(X, V) : X.$data && F.validate ? (0, s.funcKeywordCode)(X, F) : "macro" in F ? (0, s.macroKeywordCode)(X, F) : (F.compile || F.validate) && (0, s.funcKeywordCode)(X, F);
  }
  const Y = /^\/(?:[^~]|~0|~1)*$/, he = /^([0-9]+)(#|\/(?:[^~]|~0|~1)*)?$/;
  function le(O, { dataLevel: N, dataNames: F, dataPathArr: V }) {
    let X, ae;
    if (O === "")
      return c.default.rootData;
    if (O[0] === "/") {
      if (!Y.test(O))
        throw new Error(`Invalid JSON-pointer: ${O}`);
      X = O, ae = c.default.rootData;
    } else {
      const Xe = he.exec(O);
      if (!Xe)
        throw new Error(`Invalid JSON-pointer: ${O}`);
      const qe = +Xe[1];
      if (X = Xe[2], X === "#") {
        if (qe >= N)
          throw new Error(Qe("property/index", qe));
        return V[N - qe];
      }
      if (qe > N)
        throw new Error(Qe("data", qe));
      if (ae = F[N - qe], !X)
        return ae;
    }
    let xe = ae;
    const ft = X.split("/");
    for (const Xe of ft)
      Xe && (ae = (0, a._)`${ae}${(0, a.getProperty)((0, l.unescapeJsonPointer)(Xe))}`, xe = (0, a._)`${xe} && ${ae}`);
    return xe;
    function Qe(Xe, qe) {
      return `Cannot access ${Xe} ${qe} levels up, current level is ${N}`;
    }
  }
  return yt.getData = le, yt;
}
var Hr = {}, Gi;
function Ls() {
  if (Gi) return Hr;
  Gi = 1, Object.defineProperty(Hr, "__esModule", { value: !0 });
  class t extends Error {
    constructor(r) {
      super("validation failed"), this.errors = r, this.ajv = this.validation = !0;
    }
  }
  return Hr.default = t, Hr;
}
var Wr = {}, Ki;
function ao() {
  if (Ki) return Wr;
  Ki = 1, Object.defineProperty(Wr, "__esModule", { value: !0 });
  const t = /* @__PURE__ */ so();
  class e extends Error {
    constructor(n, o, s, i) {
      super(i || `can't resolve reference ${s} from id ${o}`), this.missingRef = (0, t.resolveUrl)(n, o, s), this.missingSchema = (0, t.normalizeId)((0, t.getFullPath)(n, this.missingRef));
    }
  }
  return Wr.default = e, Wr;
}
var rt = {}, Ji;
function Zs() {
  if (Ji) return rt;
  Ji = 1, Object.defineProperty(rt, "__esModule", { value: !0 }), rt.resolveSchema = rt.getCompilingSchema = rt.resolveRef = rt.compileSchema = rt.SchemaEnv = void 0;
  const t = /* @__PURE__ */ ie(), e = /* @__PURE__ */ Ls(), r = /* @__PURE__ */ zt(), n = /* @__PURE__ */ so(), o = /* @__PURE__ */ de(), s = /* @__PURE__ */ io();
  class i {
    constructor(y) {
      var g;
      this.refs = {}, this.dynamicAnchors = {};
      let w;
      typeof y.schema == "object" && (w = y.schema), this.schema = y.schema, this.schemaId = y.schemaId, this.root = y.root || this, this.baseId = (g = y.baseId) !== null && g !== void 0 ? g : (0, n.normalizeId)(w == null ? void 0 : w[y.schemaId || "$id"]), this.schemaPath = y.schemaPath, this.localRefs = y.localRefs, this.meta = y.meta, this.$async = w == null ? void 0 : w.$async, this.refs = {};
    }
  }
  rt.SchemaEnv = i;
  function a(v) {
    const y = l.call(this, v);
    if (y)
      return y;
    const g = (0, n.getFullPath)(this.opts.uriResolver, v.root.baseId), { es5: w, lines: k } = this.opts.code, { ownProperties: f } = this.opts, d = new t.CodeGen(this.scope, { es5: w, lines: k, ownProperties: f });
    let p;
    v.$async && (p = d.scopeValue("Error", {
      ref: e.default,
      code: (0, t._)`require("ajv/dist/runtime/validation_error").default`
    }));
    const E = d.scopeName("validate");
    v.validateName = E;
    const I = {
      gen: d,
      allErrors: this.opts.allErrors,
      data: r.default.data,
      parentData: r.default.parentData,
      parentDataProperty: r.default.parentDataProperty,
      dataNames: [r.default.data],
      dataPathArr: [t.nil],
      // TODO can its length be used as dataLevel if nil is removed?
      dataLevel: 0,
      dataTypes: [],
      definedProperties: /* @__PURE__ */ new Set(),
      topSchemaRef: d.scopeValue("schema", this.opts.code.source === !0 ? { ref: v.schema, code: (0, t.stringify)(v.schema) } : { ref: v.schema }),
      validateName: E,
      ValidationError: p,
      schema: v.schema,
      schemaEnv: v,
      rootId: g,
      baseId: v.baseId || g,
      schemaPath: t.nil,
      errSchemaPath: v.schemaPath || (this.opts.jtd ? "" : "#"),
      errorPath: (0, t._)`""`,
      opts: this.opts,
      self: this
    };
    let R;
    try {
      this._compilations.add(v), (0, s.validateFunctionCode)(I), d.optimize(this.opts.code.optimize);
      const A = d.toString();
      R = `${d.scopeRefs(r.default.scope)}return ${A}`, this.opts.code.process && (R = this.opts.code.process(R, v));
      const P = new Function(`${r.default.self}`, `${r.default.scope}`, R)(this, this.scope.get());
      if (this.scope.value(E, { ref: P }), P.errors = null, P.schema = v.schema, P.schemaEnv = v, v.$async && (P.$async = !0), this.opts.code.source === !0 && (P.source = { validateName: E, validateCode: A, scopeValues: d._values }), this.opts.unevaluated) {
        const { props: x, items: G } = I;
        P.evaluated = {
          props: x instanceof t.Name ? void 0 : x,
          items: G instanceof t.Name ? void 0 : G,
          dynamicProps: x instanceof t.Name,
          dynamicItems: G instanceof t.Name
        }, P.source && (P.source.evaluated = (0, t.stringify)(P.evaluated));
      }
      return v.validate = P, v;
    } catch (A) {
      throw delete v.validate, delete v.validateName, R && this.logger.error("Error compiling schema, function code:", R), A;
    } finally {
      this._compilations.delete(v);
    }
  }
  rt.compileSchema = a;
  function c(v, y, g) {
    var w;
    g = (0, n.resolveUrl)(this.opts.uriResolver, y, g);
    const k = v.refs[g];
    if (k)
      return k;
    let f = m.call(this, v, g);
    if (f === void 0) {
      const d = (w = v.localRefs) === null || w === void 0 ? void 0 : w[g], { schemaId: p } = this.opts;
      d && (f = new i({ schema: d, schemaId: p, root: v, baseId: y }));
    }
    if (f !== void 0)
      return v.refs[g] = u.call(this, f);
  }
  rt.resolveRef = c;
  function u(v) {
    return (0, n.inlineRef)(v.schema, this.opts.inlineRefs) ? v.schema : v.validate ? v : a.call(this, v);
  }
  function l(v) {
    for (const y of this._compilations)
      if (h(y, v))
        return y;
  }
  rt.getCompilingSchema = l;
  function h(v, y) {
    return v.schema === y.schema && v.root === y.root && v.baseId === y.baseId;
  }
  function m(v, y) {
    let g;
    for (; typeof (g = this.refs[y]) == "string"; )
      y = g;
    return g || this.schemas[y] || _.call(this, v, y);
  }
  function _(v, y) {
    const g = this.opts.uriResolver.parse(y), w = (0, n._getFullPath)(this.opts.uriResolver, g);
    let k = (0, n.getFullPath)(this.opts.uriResolver, v.baseId, void 0);
    if (Object.keys(v.schema).length > 0 && w === k)
      return $.call(this, g, v);
    const f = (0, n.normalizeId)(w), d = this.refs[f] || this.schemas[f];
    if (typeof d == "string") {
      const p = _.call(this, v, d);
      return typeof (p == null ? void 0 : p.schema) != "object" ? void 0 : $.call(this, g, p);
    }
    if (typeof (d == null ? void 0 : d.schema) == "object") {
      if (d.validate || a.call(this, d), f === (0, n.normalizeId)(y)) {
        const { schema: p } = d, { schemaId: E } = this.opts, I = p[E];
        return I && (k = (0, n.resolveUrl)(this.opts.uriResolver, k, I)), new i({ schema: p, schemaId: E, root: v, baseId: k });
      }
      return $.call(this, g, d);
    }
  }
  rt.resolveSchema = _;
  const S = /* @__PURE__ */ new Set([
    "properties",
    "patternProperties",
    "enum",
    "dependencies",
    "definitions"
  ]);
  function $(v, { baseId: y, schema: g, root: w }) {
    var k;
    if (((k = v.fragment) === null || k === void 0 ? void 0 : k[0]) !== "/")
      return;
    for (const p of v.fragment.slice(1).split("/")) {
      if (typeof g == "boolean")
        return;
      const E = g[(0, o.unescapeFragment)(p)];
      if (E === void 0)
        return;
      g = E;
      const I = typeof g == "object" && g[this.opts.schemaId];
      !S.has(p) && I && (y = (0, n.resolveUrl)(this.opts.uriResolver, y, I));
    }
    let f;
    if (typeof g != "boolean" && g.$ref && !(0, o.schemaHasRulesButRef)(g, this.RULES)) {
      const p = (0, n.resolveUrl)(this.opts.uriResolver, y, g.$ref);
      f = _.call(this, w, p);
    }
    const { schemaId: d } = this.opts;
    if (f = f || new i({ schema: g, schemaId: d, root: w, baseId: y }), f.schema !== f.root.schema)
      return f;
  }
  return rt;
}
const Ug = "https://raw.githubusercontent.com/ajv-validator/ajv/master/lib/refs/data.json#", Fg = "Meta-schema for $data reference (JSON AnySchema extension proposal)", Lg = "object", Zg = ["$data"], Vg = { $data: { type: "string", anyOf: [{ format: "relative-json-pointer" }, { format: "json-pointer" }] } }, Hg = !1, Wg = {
  $id: Ug,
  description: Fg,
  type: Lg,
  required: Zg,
  properties: Vg,
  additionalProperties: Hg
};
var Br = {}, yr = { exports: {} }, Eo, Qi;
function Tu() {
  if (Qi) return Eo;
  Qi = 1;
  const t = RegExp.prototype.test.bind(/^[\da-f]{8}-[\da-f]{4}-[\da-f]{4}-[\da-f]{4}-[\da-f]{12}$/iu), e = RegExp.prototype.test.bind(/^(?:(?:25[0-5]|2[0-4]\d|1\d{2}|[1-9]\d|\d)\.){3}(?:25[0-5]|2[0-4]\d|1\d{2}|[1-9]\d|\d)$/u), r = RegExp.prototype.test.bind(/^[\da-f]{2}$/iu), n = RegExp.prototype.test.bind(/^[\da-z\-._~]$/iu), o = RegExp.prototype.test.bind(/^[\da-z\-._~!$&'()*+,;=:@/]$/iu);
  function s(f) {
    let d = "", p = 0, E = 0;
    for (E = 0; E < f.length; E++)
      if (p = f[E].charCodeAt(0), p !== 48) {
        if (!(p >= 48 && p <= 57 || p >= 65 && p <= 70 || p >= 97 && p <= 102))
          return "";
        d += f[E];
        break;
      }
    for (E += 1; E < f.length; E++) {
      if (p = f[E].charCodeAt(0), !(p >= 48 && p <= 57 || p >= 65 && p <= 70 || p >= 97 && p <= 102))
        return "";
      d += f[E];
    }
    return d;
  }
  const i = RegExp.prototype.test.bind(/[^!"$&'()*+,\-.;=_`a-z{}~]/u);
  function a(f) {
    return f.length = 0, !0;
  }
  function c(f, d, p) {
    if (f.length) {
      const E = s(f);
      if (E !== "")
        d.push(E);
      else
        return p.error = !0, !1;
      f.length = 0;
    }
    return !0;
  }
  function u(f) {
    let d = 0;
    const p = { error: !1, address: "", zone: "" }, E = [], I = [];
    let R = !1, A = !1, M = c;
    for (let P = 0; P < f.length; P++) {
      const x = f[P];
      if (!(x === "[" || x === "]"))
        if (x === ":") {
          if (R === !0 && (A = !0), !M(I, E, p))
            break;
          if (++d > 7) {
            p.error = !0;
            break;
          }
          P > 0 && f[P - 1] === ":" && (R = !0), E.push(":");
          continue;
        } else if (x === "%") {
          if (!M(I, E, p))
            break;
          M = a;
        } else {
          I.push(x);
          continue;
        }
    }
    return I.length && (M === a ? p.zone = I.join("") : A ? E.push(I.join("")) : E.push(s(I))), p.address = E.join(""), p;
  }
  function l(f) {
    if (h(f, ":") < 2)
      return { host: f, isIPV6: !1 };
    const d = u(f);
    if (d.error)
      return { host: f, isIPV6: !1 };
    {
      let p = d.address, E = d.address;
      return d.zone && (p += "%" + d.zone, E += "%25" + d.zone), { host: p, isIPV6: !0, escapedHost: E };
    }
  }
  function h(f, d) {
    let p = 0;
    for (let E = 0; E < f.length; E++)
      f[E] === d && p++;
    return p;
  }
  function m(f) {
    let d = f;
    const p = [];
    let E = -1, I = 0;
    for (; I = d.length; ) {
      if (I === 1) {
        if (d === ".")
          break;
        if (d === "/") {
          p.push("/");
          break;
        } else {
          p.push(d);
          break;
        }
      } else if (I === 2) {
        if (d[0] === ".") {
          if (d[1] === ".")
            break;
          if (d[1] === "/") {
            d = d.slice(2);
            continue;
          }
        } else if (d[0] === "/" && (d[1] === "." || d[1] === "/")) {
          p.push("/");
          break;
        }
      } else if (I === 3 && d === "/..") {
        p.length !== 0 && p.pop(), p.push("/");
        break;
      }
      if (d[0] === ".") {
        if (d[1] === ".") {
          if (d[2] === "/") {
            d = d.slice(3);
            continue;
          }
        } else if (d[1] === "/") {
          d = d.slice(2);
          continue;
        }
      } else if (d[0] === "/" && d[1] === ".") {
        if (d[2] === "/") {
          d = d.slice(2);
          continue;
        } else if (d[2] === "." && d[3] === "/") {
          d = d.slice(3), p.length !== 0 && p.pop();
          continue;
        }
      }
      if ((E = d.indexOf("/", 1)) === -1) {
        p.push(d);
        break;
      } else
        p.push(d.slice(0, E)), d = d.slice(E);
    }
    return p.join("");
  }
  const _ = { "@": "%40", "/": "%2F", "?": "%3F", "#": "%23", ":": "%3A" }, S = /[@/?#:]/g, $ = /[@/?#]/g;
  function v(f, d) {
    const p = d ? $ : S;
    return p.lastIndex = 0, f.replace(p, (E) => _[E]);
  }
  function y(f, d = !1) {
    if (f.indexOf("%") === -1)
      return f;
    let p = "";
    for (let E = 0; E < f.length; E++) {
      if (f[E] === "%" && E + 2 < f.length) {
        const I = f.slice(E + 1, E + 3);
        if (r(I)) {
          const R = I.toUpperCase(), A = String.fromCharCode(parseInt(R, 16));
          d && n(A) ? p += A : p += "%" + R, E += 2;
          continue;
        }
      }
      p += f[E];
    }
    return p;
  }
  function g(f) {
    let d = "";
    for (let p = 0; p < f.length; p++) {
      if (f[p] === "%" && p + 2 < f.length) {
        const E = f.slice(p + 1, p + 3);
        if (r(E)) {
          const I = E.toUpperCase(), R = String.fromCharCode(parseInt(I, 16));
          R !== "." && n(R) ? d += R : d += "%" + I, p += 2;
          continue;
        }
      }
      o(f[p]) ? d += f[p] : d += escape(f[p]);
    }
    return d;
  }
  function w(f) {
    let d = "";
    for (let p = 0; p < f.length; p++) {
      if (f[p] === "%" && p + 2 < f.length) {
        const E = f.slice(p + 1, p + 3);
        if (r(E)) {
          d += "%" + E.toUpperCase(), p += 2;
          continue;
        }
      }
      d += escape(f[p]);
    }
    return d;
  }
  function k(f) {
    const d = [];
    if (f.userinfo !== void 0 && (d.push(f.userinfo), d.push("@")), f.host !== void 0) {
      let p = unescape(f.host);
      if (!e(p)) {
        const E = l(p);
        E.isIPV6 === !0 ? p = `[${E.escapedHost}]` : p = v(p, !1);
      }
      d.push(p);
    }
    return (typeof f.port == "number" || typeof f.port == "string") && (d.push(":"), d.push(String(f.port))), d.length ? d.join("") : void 0;
  }
  return Eo = {
    nonSimpleDomain: i,
    recomposeAuthority: k,
    reescapeHostDelimiters: v,
    normalizePercentEncoding: y,
    normalizePathEncoding: g,
    escapePreservingEscapes: w,
    removeDotSegments: m,
    isIPv4: e,
    isUUID: t,
    normalizeIPv6: l,
    stringArrayToHexStripped: s
  }, Eo;
}
var ko, Xi;
function Bg() {
  if (Xi) return ko;
  Xi = 1;
  const { isUUID: t } = Tu(), e = /([\da-z][\d\-a-z]{0,31}):((?:[\w!$'()*+,\-.:;=@]|%[\da-f]{2})+)/iu, r = (
    /** @type {const} */
    [
      "http",
      "https",
      "ws",
      "wss",
      "urn",
      "urn:uuid"
    ]
  );
  function n(f) {
    return r.indexOf(
      /** @type {*} */
      f
    ) !== -1;
  }
  function o(f) {
    return f.secure === !0 ? !0 : f.secure === !1 ? !1 : f.scheme ? f.scheme.length === 3 && (f.scheme[0] === "w" || f.scheme[0] === "W") && (f.scheme[1] === "s" || f.scheme[1] === "S") && (f.scheme[2] === "s" || f.scheme[2] === "S") : !1;
  }
  function s(f) {
    return f.host || (f.error = f.error || "HTTP URIs must have a host."), f;
  }
  function i(f) {
    const d = String(f.scheme).toLowerCase() === "https";
    return (f.port === (d ? 443 : 80) || f.port === "") && (f.port = void 0), f.path || (f.path = "/"), f;
  }
  function a(f) {
    return f.secure = o(f), f.resourceName = (f.path || "/") + (f.query ? "?" + f.query : ""), f.path = void 0, f.query = void 0, f;
  }
  function c(f) {
    if ((f.port === (o(f) ? 443 : 80) || f.port === "") && (f.port = void 0), typeof f.secure == "boolean" && (f.scheme = f.secure ? "wss" : "ws", f.secure = void 0), f.resourceName) {
      const [d, p] = f.resourceName.split("?");
      f.path = d && d !== "/" ? d : void 0, f.query = p, f.resourceName = void 0;
    }
    return f.fragment = void 0, f;
  }
  function u(f, d) {
    if (!f.path)
      return f.error = "URN can not be parsed", f;
    const p = f.path.match(e);
    if (p) {
      const E = d.scheme || f.scheme || "urn";
      f.nid = p[1].toLowerCase(), f.nss = p[2];
      const I = `${E}:${d.nid || f.nid}`, R = k(I);
      f.path = void 0, R && (f = R.parse(f, d));
    } else
      f.error = f.error || "URN can not be parsed.";
    return f;
  }
  function l(f, d) {
    if (f.nid === void 0)
      throw new Error("URN without nid cannot be serialized");
    const p = d.scheme || f.scheme || "urn", E = f.nid.toLowerCase(), I = `${p}:${d.nid || E}`, R = k(I);
    R && (f = R.serialize(f, d));
    const A = f, M = f.nss;
    return A.path = `${E || d.nid}:${M}`, d.skipEscape = !0, A;
  }
  function h(f, d) {
    const p = f;
    return p.uuid = p.nss, p.nss = void 0, !d.tolerant && (!p.uuid || !t(p.uuid)) && (p.error = p.error || "UUID is not valid."), p;
  }
  function m(f) {
    const d = f;
    return d.nss = (f.uuid || "").toLowerCase(), d;
  }
  const _ = (
    /** @type {SchemeHandler} */
    {
      scheme: "http",
      domainHost: !0,
      parse: s,
      serialize: i
    }
  ), S = (
    /** @type {SchemeHandler} */
    {
      scheme: "https",
      domainHost: _.domainHost,
      parse: s,
      serialize: i
    }
  ), $ = (
    /** @type {SchemeHandler} */
    {
      scheme: "ws",
      domainHost: !0,
      parse: a,
      serialize: c
    }
  ), v = (
    /** @type {SchemeHandler} */
    {
      scheme: "wss",
      domainHost: $.domainHost,
      parse: $.parse,
      serialize: $.serialize
    }
  ), w = (
    /** @type {Record<SchemeName, SchemeHandler>} */
    {
      http: _,
      https: S,
      ws: $,
      wss: v,
      urn: (
        /** @type {SchemeHandler} */
        {
          scheme: "urn",
          parse: u,
          serialize: l,
          skipNormalize: !0
        }
      ),
      "urn:uuid": (
        /** @type {SchemeHandler} */
        {
          scheme: "urn:uuid",
          parse: h,
          serialize: m,
          skipNormalize: !0
        }
      )
    }
  );
  Object.setPrototypeOf(w, null);
  function k(f) {
    return f && (w[
      /** @type {SchemeName} */
      f
    ] || w[
      /** @type {SchemeName} */
      f.toLowerCase()
    ]) || void 0;
  }
  return ko = {
    wsIsSecure: o,
    SCHEMES: w,
    isValidSchemeName: n,
    getSchemeHandler: k
  }, ko;
}
var Yi;
function Gg() {
  if (Yi) return yr.exports;
  Yi = 1;
  const { normalizeIPv6: t, removeDotSegments: e, recomposeAuthority: r, normalizePercentEncoding: n, normalizePathEncoding: o, escapePreservingEscapes: s, reescapeHostDelimiters: i, isIPv4: a, nonSimpleDomain: c } = Tu(), { SCHEMES: u, getSchemeHandler: l } = Bg();
  function h(R, A) {
    return typeof R == "string" ? R = /** @type {T} */
    d(R, A) : typeof R == "object" && (R = /** @type {T} */
    f($(R, A), A)), R;
  }
  function m(R, A, M) {
    const P = M ? Object.assign({ scheme: "null" }, M) : { scheme: "null" }, { parsed: x, malformedAuthorityOrPort: G } = k(R, P), { parsed: fe, malformedAuthorityOrPort: ue } = k(A, P);
    if (G || ue)
      throw new Error(x.error || fe.error || "URI is malformed.");
    const ee = _(x, fe, P, !0);
    return P.skipEscape = !0, $(ee, P);
  }
  function _(R, A, M, P) {
    const x = {};
    return P || (R = f($(R, M), M), A = f($(A, M), M)), M = M || {}, !M.tolerant && A.scheme ? (x.scheme = A.scheme, x.userinfo = A.userinfo, x.host = A.host, x.port = A.port, x.path = e(A.path || ""), x.query = A.query) : (A.userinfo !== void 0 || A.host !== void 0 || A.port !== void 0 ? (x.userinfo = A.userinfo, x.host = A.host, x.port = A.port, x.path = e(A.path || ""), x.query = A.query) : (A.path ? (A.path[0] === "/" ? x.path = e(A.path) : ((R.userinfo !== void 0 || R.host !== void 0 || R.port !== void 0) && !R.path ? x.path = "/" + A.path : R.path ? x.path = R.path.slice(0, R.path.lastIndexOf("/") + 1) + A.path : x.path = A.path, x.path = e(x.path)), x.query = A.query) : (x.path = R.path, A.query !== void 0 ? x.query = A.query : x.query = R.query), x.userinfo = R.userinfo, x.host = R.host, x.port = R.port), x.scheme = R.scheme), x.fragment = A.fragment, x;
  }
  function S(R, A, M) {
    const P = E(R, M), x = E(A, M);
    return P !== void 0 && x !== void 0 && P.toLowerCase() === x.toLowerCase();
  }
  function $(R, A) {
    const M = {
      host: R.host,
      scheme: R.scheme,
      userinfo: R.userinfo,
      port: R.port,
      path: R.path,
      query: R.query,
      nid: R.nid,
      nss: R.nss,
      uuid: R.uuid,
      fragment: R.fragment,
      reference: R.reference,
      resourceName: R.resourceName,
      secure: R.secure,
      error: ""
    }, P = Object.assign({}, A), x = [], G = l(P.scheme || M.scheme);
    G && G.serialize && G.serialize(M, P), M.path !== void 0 && (P.skipEscape ? M.path = n(M.path) : (M.path = s(M.path), M.scheme !== void 0 && (M.path = M.path.split("%3A").join(":")))), P.reference !== "suffix" && M.scheme && x.push(M.scheme, ":");
    const fe = r(M);
    if (fe !== void 0 && (P.reference !== "suffix" && x.push("//"), x.push(fe), M.path && M.path[0] !== "/" && x.push("/")), M.path !== void 0) {
      let ue = M.path;
      !P.absolutePath && (!G || !G.absolutePath) && (ue = e(ue)), fe === void 0 && ue[0] === "/" && ue[1] === "/" && (ue = "/%2F" + ue.slice(2)), x.push(ue);
    }
    return M.query !== void 0 && x.push("?", M.query), M.fragment !== void 0 && x.push("#", M.fragment), x.join("");
  }
  const v = /^(?:([^#/:?]+):)?(?:\/\/((?:([^#/?@]*)@)?(\[[^#/?\]]+\]|[^#/:?]*)(?::(\d*))?))?([^#?]*)(?:\?([^#]*))?(?:#((?:.|[\n\r])*))?/u, y = /^(?:[^#/:?]+:)?\/\/([^/?#]*)/, g = /^(?:[^#/:?]+:)?([/\\\t\n\r]*)/;
  function w(R, A) {
    if (A[2] !== void 0 && R.path && R.path[0] !== "/")
      return 'URI path must start with "/" when authority is present.';
    if (typeof R.port == "number" && (R.port < 0 || R.port > 65535))
      return "URI port is malformed.";
  }
  function k(R, A) {
    const M = Object.assign({}, A), P = {
      scheme: void 0,
      userinfo: void 0,
      host: "",
      port: void 0,
      path: "",
      query: void 0,
      fragment: void 0
    };
    let x = !1, G = !1;
    M.reference === "suffix" && (M.scheme ? R = M.scheme + ":" + R : R = "//" + R);
    const fe = R.match(y);
    fe !== null && fe[1].indexOf("\\") !== -1 && (P.error = "URI authority must not contain a literal backslash.", x = !0);
    const ue = R.match(g);
    if (ue !== null) {
      const Pe = ue[1], L = Pe.replace(/[\t\n\r]/g, "");
      L.length >= 2 && (L.slice(0, 2) !== "//" ? (P.error = P.error || "URI authority must not contain a literal backslash.", x = !0) : Pe.length !== L.length && (P.error = P.error || "URI authority introducer must not contain whitespace.", x = !0));
    }
    const ee = R.match(v);
    if (ee) {
      P.scheme = ee[1], P.userinfo = ee[3], P.host = ee[4], P.port = parseInt(ee[5], 10), P.path = ee[6] || "", P.query = ee[7], P.fragment = ee[8], isNaN(P.port) && (P.port = ee[5]);
      const Pe = w(P, ee);
      if (Pe !== void 0 && (P.error = P.error || Pe, x = !0), P.host)
        if (a(P.host) === !1) {
          const U = t(P.host);
          P.host = U.host.toLowerCase(), G = U.isIPV6;
        } else
          G = !0;
      P.scheme === void 0 && P.userinfo === void 0 && P.host === void 0 && P.port === void 0 && P.query === void 0 && !P.path ? P.reference = "same-document" : P.scheme === void 0 ? P.reference = "relative" : P.fragment === void 0 ? P.reference = "absolute" : P.reference = "uri", M.reference && M.reference !== "suffix" && M.reference !== P.reference && (P.error = P.error || "URI is not a " + M.reference + " reference.");
      const L = l(M.scheme || P.scheme);
      if (!M.unicodeSupport && (!L || !L.unicodeSupport) && P.host && (M.domainHost || L && L.domainHost) && G === !1 && c(P.host))
        try {
          P.host = new URL("http://" + P.host).hostname;
        } catch (z) {
          P.error = P.error || "Host's domain name can not be converted to ASCII: " + z;
        }
      if ((!L || L && !L.skipNormalize) && (R.indexOf("%") !== -1 && (P.scheme !== void 0 && (P.scheme = unescape(P.scheme)), P.host !== void 0 && (P.host = i(unescape(P.host), G))), P.path && (P.path = o(P.path)), P.fragment))
        try {
          P.fragment = encodeURI(decodeURIComponent(P.fragment));
        } catch {
          P.error = P.error || "URI malformed";
        }
      L && L.parse && L.parse(P, M);
    } else
      P.error = P.error || "URI can not be parsed.";
    return { parsed: P, malformedAuthorityOrPort: x };
  }
  function f(R, A) {
    return k(R, A).parsed;
  }
  function d(R, A) {
    return p(R, A).normalized;
  }
  function p(R, A) {
    const { parsed: M, malformedAuthorityOrPort: P } = k(R, A);
    return {
      normalized: P ? R : $(M, A),
      malformedAuthorityOrPort: P
    };
  }
  function E(R, A) {
    if (typeof R == "string") {
      const { normalized: M, malformedAuthorityOrPort: P } = p(R, A);
      return P ? void 0 : M;
    }
    if (typeof R == "object")
      return $(R, A);
  }
  const I = {
    SCHEMES: u,
    normalize: h,
    resolve: m,
    resolveComponent: _,
    equal: S,
    serialize: $,
    parse: f
  };
  return yr.exports = I, yr.exports.default = I, yr.exports.fastUri = I, yr.exports;
}
var ea;
function Kg() {
  if (ea) return Br;
  ea = 1, Object.defineProperty(Br, "__esModule", { value: !0 });
  const t = Gg();
  return t.code = 'require("ajv/dist/runtime/uri").default', Br.default = t, Br;
}
var ta;
function Jg() {
  return ta || (ta = 1, function(t) {
    Object.defineProperty(t, "__esModule", { value: !0 }), t.CodeGen = t.Name = t.nil = t.stringify = t.str = t._ = t.KeywordCxt = void 0;
    var e = /* @__PURE__ */ io();
    Object.defineProperty(t, "KeywordCxt", { enumerable: !0, get: function() {
      return e.KeywordCxt;
    } });
    var r = /* @__PURE__ */ ie();
    Object.defineProperty(t, "_", { enumerable: !0, get: function() {
      return r._;
    } }), Object.defineProperty(t, "str", { enumerable: !0, get: function() {
      return r.str;
    } }), Object.defineProperty(t, "stringify", { enumerable: !0, get: function() {
      return r.stringify;
    } }), Object.defineProperty(t, "nil", { enumerable: !0, get: function() {
      return r.nil;
    } }), Object.defineProperty(t, "Name", { enumerable: !0, get: function() {
      return r.Name;
    } }), Object.defineProperty(t, "CodeGen", { enumerable: !0, get: function() {
      return r.CodeGen;
    } });
    const n = /* @__PURE__ */ Ls(), o = /* @__PURE__ */ ao(), s = /* @__PURE__ */ Eu(), i = /* @__PURE__ */ Zs(), a = /* @__PURE__ */ ie(), c = /* @__PURE__ */ so(), u = /* @__PURE__ */ Fn(), l = /* @__PURE__ */ de(), h = Wg, m = /* @__PURE__ */ Kg(), _ = (L, z) => new RegExp(L, z);
    _.code = "new RegExp";
    const S = ["removeAdditional", "useDefaults", "coerceTypes"], $ = /* @__PURE__ */ new Set([
      "validate",
      "serialize",
      "parse",
      "wrapper",
      "root",
      "schema",
      "keyword",
      "pattern",
      "formats",
      "validate$data",
      "func",
      "obj",
      "Error"
    ]), v = {
      errorDataPath: "",
      format: "`validateFormats: false` can be used instead.",
      nullable: '"nullable" keyword is supported by default.',
      jsonPointers: "Deprecated jsPropertySyntax can be used instead.",
      extendRefs: "Deprecated ignoreKeywordsWithRef can be used instead.",
      missingRefs: "Pass empty schema with $id that should be ignored to ajv.addSchema.",
      processCode: "Use option `code: {process: (code, schemaEnv: object) => string}`",
      sourceCode: "Use option `code: {source: true}`",
      strictDefaults: "It is default now, see option `strict`.",
      strictKeywords: "It is default now, see option `strict`.",
      uniqueItems: '"uniqueItems" keyword is always validated.',
      unknownFormats: "Disable strict mode or pass `true` to `ajv.addFormat` (or `formats` option).",
      cache: "Map is used as cache, schema object as key.",
      serialize: "Map is used as cache, schema object as key.",
      ajvErrors: "It is default now."
    }, y = {
      ignoreKeywordsWithRef: "",
      jsPropertySyntax: "",
      unicode: '"minLength"/"maxLength" account for unicode characters by default.'
    }, g = 200;
    function w(L) {
      var z, U, j, b, T, D, J, Y, he, le, O, N, F, V, X, ae, xe, ft, Qe, Xe, qe, Kt, it, uo, lo;
      const gr = L.strict, fo = (z = L.code) === null || z === void 0 ? void 0 : z.optimize, Ks = fo === !0 || fo === void 0 ? 1 : fo || 0, Js = (j = (U = L.code) === null || U === void 0 ? void 0 : U.regExp) !== null && j !== void 0 ? j : _, Ju = (b = L.uriResolver) !== null && b !== void 0 ? b : m.default;
      return {
        strictSchema: (D = (T = L.strictSchema) !== null && T !== void 0 ? T : gr) !== null && D !== void 0 ? D : !0,
        strictNumbers: (Y = (J = L.strictNumbers) !== null && J !== void 0 ? J : gr) !== null && Y !== void 0 ? Y : !0,
        strictTypes: (le = (he = L.strictTypes) !== null && he !== void 0 ? he : gr) !== null && le !== void 0 ? le : "log",
        strictTuples: (N = (O = L.strictTuples) !== null && O !== void 0 ? O : gr) !== null && N !== void 0 ? N : "log",
        strictRequired: (V = (F = L.strictRequired) !== null && F !== void 0 ? F : gr) !== null && V !== void 0 ? V : !1,
        code: L.code ? { ...L.code, optimize: Ks, regExp: Js } : { optimize: Ks, regExp: Js },
        loopRequired: (X = L.loopRequired) !== null && X !== void 0 ? X : g,
        loopEnum: (ae = L.loopEnum) !== null && ae !== void 0 ? ae : g,
        meta: (xe = L.meta) !== null && xe !== void 0 ? xe : !0,
        messages: (ft = L.messages) !== null && ft !== void 0 ? ft : !0,
        inlineRefs: (Qe = L.inlineRefs) !== null && Qe !== void 0 ? Qe : !0,
        schemaId: (Xe = L.schemaId) !== null && Xe !== void 0 ? Xe : "$id",
        addUsedSchema: (qe = L.addUsedSchema) !== null && qe !== void 0 ? qe : !0,
        validateSchema: (Kt = L.validateSchema) !== null && Kt !== void 0 ? Kt : !0,
        validateFormats: (it = L.validateFormats) !== null && it !== void 0 ? it : !0,
        unicodeRegExp: (uo = L.unicodeRegExp) !== null && uo !== void 0 ? uo : !0,
        int32range: (lo = L.int32range) !== null && lo !== void 0 ? lo : !0,
        uriResolver: Ju
      };
    }
    class k {
      constructor(z = {}) {
        this.schemas = {}, this.refs = {}, this.formats = /* @__PURE__ */ Object.create(null), this._compilations = /* @__PURE__ */ new Set(), this._loading = {}, this._cache = /* @__PURE__ */ new Map(), z = this.opts = { ...z, ...w(z) };
        const { es5: U, lines: j } = this.opts.code;
        this.scope = new a.ValueScope({ scope: {}, prefixes: $, es5: U, lines: j }), this.logger = M(z.logger);
        const b = z.validateFormats;
        z.validateFormats = !1, this.RULES = (0, s.getRules)(), f.call(this, v, z, "NOT SUPPORTED"), f.call(this, y, z, "DEPRECATED", "warn"), this._metaOpts = R.call(this), z.formats && E.call(this), this._addVocabularies(), this._addDefaultMetaSchema(), z.keywords && I.call(this, z.keywords), typeof z.meta == "object" && this.addMetaSchema(z.meta), p.call(this), z.validateFormats = b;
      }
      _addVocabularies() {
        this.addKeyword("$async");
      }
      _addDefaultMetaSchema() {
        const { $data: z, meta: U, schemaId: j } = this.opts;
        let b = h;
        j === "id" && (b = { ...h }, b.id = b.$id, delete b.$id), U && z && this.addMetaSchema(b, b[j], !1);
      }
      defaultMeta() {
        const { meta: z, schemaId: U } = this.opts;
        return this.opts.defaultMeta = typeof z == "object" ? z[U] || z : void 0;
      }
      validate(z, U) {
        let j;
        if (typeof z == "string") {
          if (j = this.getSchema(z), !j)
            throw new Error(`no schema with key or ref "${z}"`);
        } else
          j = this.compile(z);
        const b = j(U);
        return "$async" in j || (this.errors = j.errors), b;
      }
      compile(z, U) {
        const j = this._addSchema(z, U);
        return j.validate || this._compileSchemaEnv(j);
      }
      compileAsync(z, U) {
        if (typeof this.opts.loadSchema != "function")
          throw new Error("options.loadSchema should be a function");
        const { loadSchema: j } = this.opts;
        return b.call(this, z, U);
        async function b(le, O) {
          await T.call(this, le.$schema);
          const N = this._addSchema(le, O);
          return N.validate || D.call(this, N);
        }
        async function T(le) {
          le && !this.getSchema(le) && await b.call(this, { $ref: le }, !0);
        }
        async function D(le) {
          try {
            return this._compileSchemaEnv(le);
          } catch (O) {
            if (!(O instanceof o.default))
              throw O;
            return J.call(this, O), await Y.call(this, O.missingSchema), D.call(this, le);
          }
        }
        function J({ missingSchema: le, missingRef: O }) {
          if (this.refs[le])
            throw new Error(`AnySchema ${le} is loaded but ${O} cannot be resolved`);
        }
        async function Y(le) {
          const O = await he.call(this, le);
          this.refs[le] || await T.call(this, O.$schema), this.refs[le] || this.addSchema(O, le, U);
        }
        async function he(le) {
          const O = this._loading[le];
          if (O)
            return O;
          try {
            return await (this._loading[le] = j(le));
          } finally {
            delete this._loading[le];
          }
        }
      }
      // Adds schema to the instance
      addSchema(z, U, j, b = this.opts.validateSchema) {
        if (Array.isArray(z)) {
          for (const D of z)
            this.addSchema(D, void 0, j, b);
          return this;
        }
        let T;
        if (typeof z == "object") {
          const { schemaId: D } = this.opts;
          if (T = z[D], T !== void 0 && typeof T != "string")
            throw new Error(`schema ${D} must be string`);
        }
        return U = (0, c.normalizeId)(U || T), this._checkUnique(U), this.schemas[U] = this._addSchema(z, j, U, b, !0), this;
      }
      // Add schema that will be used to validate other schemas
      // options in META_IGNORE_OPTIONS are alway set to false
      addMetaSchema(z, U, j = this.opts.validateSchema) {
        return this.addSchema(z, U, !0, j), this;
      }
      //  Validate schema against its meta-schema
      validateSchema(z, U) {
        if (typeof z == "boolean")
          return !0;
        let j;
        if (j = z.$schema, j !== void 0 && typeof j != "string")
          throw new Error("$schema must be a string");
        if (j = j || this.opts.defaultMeta || this.defaultMeta(), !j)
          return this.logger.warn("meta-schema not available"), this.errors = null, !0;
        const b = this.validate(j, z);
        if (!b && U) {
          const T = "schema is invalid: " + this.errorsText();
          if (this.opts.validateSchema === "log")
            this.logger.error(T);
          else
            throw new Error(T);
        }
        return b;
      }
      // Get compiled schema by `key` or `ref`.
      // (`key` that was passed to `addSchema` or full schema reference - `schema.$id` or resolved id)
      getSchema(z) {
        let U;
        for (; typeof (U = d.call(this, z)) == "string"; )
          z = U;
        if (U === void 0) {
          const { schemaId: j } = this.opts, b = new i.SchemaEnv({ schema: {}, schemaId: j });
          if (U = i.resolveSchema.call(this, b, z), !U)
            return;
          this.refs[z] = U;
        }
        return U.validate || this._compileSchemaEnv(U);
      }
      // Remove cached schema(s).
      // If no parameter is passed all schemas but meta-schemas are removed.
      // If RegExp is passed all schemas with key/id matching pattern but meta-schemas are removed.
      // Even if schema is referenced by other schemas it still can be removed as other schemas have local references.
      removeSchema(z) {
        if (z instanceof RegExp)
          return this._removeAllSchemas(this.schemas, z), this._removeAllSchemas(this.refs, z), this;
        switch (typeof z) {
          case "undefined":
            return this._removeAllSchemas(this.schemas), this._removeAllSchemas(this.refs), this._cache.clear(), this;
          case "string": {
            const U = d.call(this, z);
            return typeof U == "object" && this._cache.delete(U.schema), delete this.schemas[z], delete this.refs[z], this;
          }
          case "object": {
            const U = z;
            this._cache.delete(U);
            let j = z[this.opts.schemaId];
            return j && (j = (0, c.normalizeId)(j), delete this.schemas[j], delete this.refs[j]), this;
          }
          default:
            throw new Error("ajv.removeSchema: invalid parameter");
        }
      }
      // add "vocabulary" - a collection of keywords
      addVocabulary(z) {
        for (const U of z)
          this.addKeyword(U);
        return this;
      }
      addKeyword(z, U) {
        let j;
        if (typeof z == "string")
          j = z, typeof U == "object" && (this.logger.warn("these parameters are deprecated, see docs for addKeyword"), U.keyword = j);
        else if (typeof z == "object" && U === void 0) {
          if (U = z, j = U.keyword, Array.isArray(j) && !j.length)
            throw new Error("addKeywords: keyword must be string or non-empty array");
        } else
          throw new Error("invalid addKeywords parameters");
        if (x.call(this, j, U), !U)
          return (0, l.eachItem)(j, (T) => G.call(this, T)), this;
        ue.call(this, U);
        const b = {
          ...U,
          type: (0, u.getJSONTypes)(U.type),
          schemaType: (0, u.getJSONTypes)(U.schemaType)
        };
        return (0, l.eachItem)(j, b.type.length === 0 ? (T) => G.call(this, T, b) : (T) => b.type.forEach((D) => G.call(this, T, b, D))), this;
      }
      getKeyword(z) {
        const U = this.RULES.all[z];
        return typeof U == "object" ? U.definition : !!U;
      }
      // Remove keyword
      removeKeyword(z) {
        const { RULES: U } = this;
        delete U.keywords[z], delete U.all[z];
        for (const j of U.rules) {
          const b = j.rules.findIndex((T) => T.keyword === z);
          b >= 0 && j.rules.splice(b, 1);
        }
        return this;
      }
      // Add format
      addFormat(z, U) {
        return typeof U == "string" && (U = new RegExp(U)), this.formats[z] = U, this;
      }
      errorsText(z = this.errors, { separator: U = ", ", dataVar: j = "data" } = {}) {
        return !z || z.length === 0 ? "No errors" : z.map((b) => `${j}${b.instancePath} ${b.message}`).reduce((b, T) => b + U + T);
      }
      $dataMetaSchema(z, U) {
        const j = this.RULES.all;
        z = JSON.parse(JSON.stringify(z));
        for (const b of U) {
          const T = b.split("/").slice(1);
          let D = z;
          for (const J of T)
            D = D[J];
          for (const J in j) {
            const Y = j[J];
            if (typeof Y != "object")
              continue;
            const { $data: he } = Y.definition, le = D[J];
            he && le && (D[J] = Pe(le));
          }
        }
        return z;
      }
      _removeAllSchemas(z, U) {
        for (const j in z) {
          const b = z[j];
          (!U || U.test(j)) && (typeof b == "string" ? delete z[j] : b && !b.meta && (this._cache.delete(b.schema), delete z[j]));
        }
      }
      _addSchema(z, U, j, b = this.opts.validateSchema, T = this.opts.addUsedSchema) {
        let D;
        const { schemaId: J } = this.opts;
        if (typeof z == "object")
          D = z[J];
        else {
          if (this.opts.jtd)
            throw new Error("schema must be object");
          if (typeof z != "boolean")
            throw new Error("schema must be object or boolean");
        }
        let Y = this._cache.get(z);
        if (Y !== void 0)
          return Y;
        j = (0, c.normalizeId)(D || j);
        const he = c.getSchemaRefs.call(this, z, j);
        return Y = new i.SchemaEnv({ schema: z, schemaId: J, meta: U, baseId: j, localRefs: he }), this._cache.set(Y.schema, Y), T && !j.startsWith("#") && (j && this._checkUnique(j), this.refs[j] = Y), b && this.validateSchema(z, !0), Y;
      }
      _checkUnique(z) {
        if (this.schemas[z] || this.refs[z])
          throw new Error(`schema with key or id "${z}" already exists`);
      }
      _compileSchemaEnv(z) {
        if (z.meta ? this._compileMetaSchema(z) : i.compileSchema.call(this, z), !z.validate)
          throw new Error("ajv implementation error");
        return z.validate;
      }
      _compileMetaSchema(z) {
        const U = this.opts;
        this.opts = this._metaOpts;
        try {
          i.compileSchema.call(this, z);
        } finally {
          this.opts = U;
        }
      }
    }
    k.ValidationError = n.default, k.MissingRefError = o.default, t.default = k;
    function f(L, z, U, j = "error") {
      for (const b in L) {
        const T = b;
        T in z && this.logger[j](`${U}: option ${b}. ${L[T]}`);
      }
    }
    function d(L) {
      return L = (0, c.normalizeId)(L), this.schemas[L] || this.refs[L];
    }
    function p() {
      const L = this.opts.schemas;
      if (L)
        if (Array.isArray(L))
          this.addSchema(L);
        else
          for (const z in L)
            this.addSchema(L[z], z);
    }
    function E() {
      for (const L in this.opts.formats) {
        const z = this.opts.formats[L];
        z && this.addFormat(L, z);
      }
    }
    function I(L) {
      if (Array.isArray(L)) {
        this.addVocabulary(L);
        return;
      }
      this.logger.warn("keywords option as map is deprecated, pass array");
      for (const z in L) {
        const U = L[z];
        U.keyword || (U.keyword = z), this.addKeyword(U);
      }
    }
    function R() {
      const L = { ...this.opts };
      for (const z of S)
        delete L[z];
      return L;
    }
    const A = { log() {
    }, warn() {
    }, error() {
    } };
    function M(L) {
      if (L === !1)
        return A;
      if (L === void 0)
        return console;
      if (L.log && L.warn && L.error)
        return L;
      throw new Error("logger must implement log, warn and error methods");
    }
    const P = /^[a-z_$][a-z0-9_$:-]*$/i;
    function x(L, z) {
      const { RULES: U } = this;
      if ((0, l.eachItem)(L, (j) => {
        if (U.keywords[j])
          throw new Error(`Keyword ${j} is already defined`);
        if (!P.test(j))
          throw new Error(`Keyword ${j} has invalid name`);
      }), !!z && z.$data && !("code" in z || "validate" in z))
        throw new Error('$data keyword must have "code" or "validate" function');
    }
    function G(L, z, U) {
      var j;
      const b = z == null ? void 0 : z.post;
      if (U && b)
        throw new Error('keyword with "post" flag cannot have "type"');
      const { RULES: T } = this;
      let D = b ? T.post : T.rules.find(({ type: Y }) => Y === U);
      if (D || (D = { type: U, rules: [] }, T.rules.push(D)), T.keywords[L] = !0, !z)
        return;
      const J = {
        keyword: L,
        definition: {
          ...z,
          type: (0, u.getJSONTypes)(z.type),
          schemaType: (0, u.getJSONTypes)(z.schemaType)
        }
      };
      z.before ? fe.call(this, D, J, z.before) : D.rules.push(J), T.all[L] = J, (j = z.implements) === null || j === void 0 || j.forEach((Y) => this.addKeyword(Y));
    }
    function fe(L, z, U) {
      const j = L.rules.findIndex((b) => b.keyword === U);
      j >= 0 ? L.rules.splice(j, 0, z) : (L.rules.push(z), this.logger.warn(`rule ${U} is not defined`));
    }
    function ue(L) {
      let { metaSchema: z } = L;
      z !== void 0 && (L.$data && this.opts.$data && (z = Pe(z)), L.validateSchema = this.compile(z, !0));
    }
    const ee = {
      $ref: "https://raw.githubusercontent.com/ajv-validator/ajv/master/lib/refs/data.json#"
    };
    function Pe(L) {
      return { anyOf: [L, ee] };
    }
  }(_o)), _o;
}
var Gr = {}, Kr = {}, Jr = {}, ra;
function Qg() {
  if (ra) return Jr;
  ra = 1, Object.defineProperty(Jr, "__esModule", { value: !0 });
  const t = {
    keyword: "id",
    code() {
      throw new Error('NOT SUPPORTED: keyword "id", use "$id" for schema ID');
    }
  };
  return Jr.default = t, Jr;
}
var Tt = {}, na;
function Xg() {
  if (na) return Tt;
  na = 1, Object.defineProperty(Tt, "__esModule", { value: !0 }), Tt.callRef = Tt.getValidate = void 0;
  const t = /* @__PURE__ */ ao(), e = /* @__PURE__ */ _t(), r = /* @__PURE__ */ ie(), n = /* @__PURE__ */ zt(), o = /* @__PURE__ */ Zs(), s = /* @__PURE__ */ de(), i = {
    keyword: "$ref",
    schemaType: "string",
    code(u) {
      const { gen: l, schema: h, it: m } = u, { baseId: _, schemaEnv: S, validateName: $, opts: v, self: y } = m, { root: g } = S;
      if ((h === "#" || h === "#/") && _ === g.baseId)
        return k();
      const w = o.resolveRef.call(y, g, _, h);
      if (w === void 0)
        throw new t.default(m.opts.uriResolver, _, h);
      if (w instanceof o.SchemaEnv)
        return f(w);
      return d(w);
      function k() {
        if (S === g)
          return c(u, $, S, S.$async);
        const p = l.scopeValue("root", { ref: g });
        return c(u, (0, r._)`${p}.validate`, g, g.$async);
      }
      function f(p) {
        const E = a(u, p);
        c(u, E, p, p.$async);
      }
      function d(p) {
        const E = l.scopeValue("schema", v.code.source === !0 ? { ref: p, code: (0, r.stringify)(p) } : { ref: p }), I = l.name("valid"), R = u.subschema({
          schema: p,
          dataTypes: [],
          schemaPath: r.nil,
          topSchemaRef: E,
          errSchemaPath: h
        }, I);
        u.mergeEvaluated(R), u.ok(I);
      }
    }
  };
  function a(u, l) {
    const { gen: h } = u;
    return l.validate ? h.scopeValue("validate", { ref: l.validate }) : (0, r._)`${h.scopeValue("wrapper", { ref: l })}.validate`;
  }
  Tt.getValidate = a;
  function c(u, l, h, m) {
    const { gen: _, it: S } = u, { allErrors: $, schemaEnv: v, opts: y } = S, g = y.passContext ? n.default.this : r.nil;
    m ? w() : k();
    function w() {
      if (!v.$async)
        throw new Error("async schema referenced by sync schema");
      const p = _.let("valid");
      _.try(() => {
        _.code((0, r._)`await ${(0, e.callValidateCode)(u, l, g)}`), d(l), $ || _.assign(p, !0);
      }, (E) => {
        _.if((0, r._)`!(${E} instanceof ${S.ValidationError})`, () => _.throw(E)), f(E), $ || _.assign(p, !1);
      }), u.ok(p);
    }
    function k() {
      u.result((0, e.callValidateCode)(u, l, g), () => d(l), () => f(l));
    }
    function f(p) {
      const E = (0, r._)`${p}.errors`;
      _.assign(n.default.vErrors, (0, r._)`${n.default.vErrors} === null ? ${E} : ${n.default.vErrors}.concat(${E})`), _.assign(n.default.errors, (0, r._)`${n.default.vErrors}.length`);
    }
    function d(p) {
      var E;
      if (!S.opts.unevaluated)
        return;
      const I = (E = h == null ? void 0 : h.validate) === null || E === void 0 ? void 0 : E.evaluated;
      if (S.props !== !0)
        if (I && !I.dynamicProps)
          I.props !== void 0 && (S.props = s.mergeEvaluated.props(_, I.props, S.props));
        else {
          const R = _.var("props", (0, r._)`${p}.evaluated.props`);
          S.props = s.mergeEvaluated.props(_, R, S.props, r.Name);
        }
      if (S.items !== !0)
        if (I && !I.dynamicItems)
          I.items !== void 0 && (S.items = s.mergeEvaluated.items(_, I.items, S.items));
        else {
          const R = _.var("items", (0, r._)`${p}.evaluated.items`);
          S.items = s.mergeEvaluated.items(_, R, S.items, r.Name);
        }
    }
  }
  return Tt.callRef = c, Tt.default = i, Tt;
}
var oa;
function Yg() {
  if (oa) return Kr;
  oa = 1, Object.defineProperty(Kr, "__esModule", { value: !0 });
  const t = /* @__PURE__ */ Qg(), e = /* @__PURE__ */ Xg(), r = [
    "$schema",
    "$id",
    "$defs",
    "$vocabulary",
    { keyword: "$comment" },
    "definitions",
    t.default,
    e.default
  ];
  return Kr.default = r, Kr;
}
var Qr = {}, Xr = {}, sa;
function e_() {
  if (sa) return Xr;
  sa = 1, Object.defineProperty(Xr, "__esModule", { value: !0 });
  const t = /* @__PURE__ */ ie(), e = t.operators, r = {
    maximum: { okStr: "<=", ok: e.LTE, fail: e.GT },
    minimum: { okStr: ">=", ok: e.GTE, fail: e.LT },
    exclusiveMaximum: { okStr: "<", ok: e.LT, fail: e.GTE },
    exclusiveMinimum: { okStr: ">", ok: e.GT, fail: e.LTE }
  }, n = {
    message: ({ keyword: s, schemaCode: i }) => (0, t.str)`must be ${r[s].okStr} ${i}`,
    params: ({ keyword: s, schemaCode: i }) => (0, t._)`{comparison: ${r[s].okStr}, limit: ${i}}`
  }, o = {
    keyword: Object.keys(r),
    type: "number",
    schemaType: "number",
    $data: !0,
    error: n,
    code(s) {
      const { keyword: i, data: a, schemaCode: c } = s;
      s.fail$data((0, t._)`${a} ${r[i].fail} ${c} || isNaN(${a})`);
    }
  };
  return Xr.default = o, Xr;
}
var Yr = {}, ia;
function t_() {
  if (ia) return Yr;
  ia = 1, Object.defineProperty(Yr, "__esModule", { value: !0 });
  const t = /* @__PURE__ */ ie(), r = {
    keyword: "multipleOf",
    type: "number",
    schemaType: "number",
    $data: !0,
    error: {
      message: ({ schemaCode: n }) => (0, t.str)`must be multiple of ${n}`,
      params: ({ schemaCode: n }) => (0, t._)`{multipleOf: ${n}}`
    },
    code(n) {
      const { gen: o, data: s, schemaCode: i, it: a } = n, c = a.opts.multipleOfPrecision, u = o.let("res"), l = c ? (0, t._)`Math.abs(Math.round(${u}) - ${u}) > 1e-${c}` : (0, t._)`${u} !== parseInt(${u})`;
      n.fail$data((0, t._)`(${i} === 0 || (${u} = ${s}/${i}, ${l}))`);
    }
  };
  return Yr.default = r, Yr;
}
var en = {}, tn = {}, aa;
function r_() {
  if (aa) return tn;
  aa = 1, Object.defineProperty(tn, "__esModule", { value: !0 });
  function t(e) {
    const r = e.length;
    let n = 0, o = 0, s;
    for (; o < r; )
      n++, s = e.charCodeAt(o++), s >= 55296 && s <= 56319 && o < r && (s = e.charCodeAt(o), (s & 64512) === 56320 && o++);
    return n;
  }
  return tn.default = t, t.code = 'require("ajv/dist/runtime/ucs2length").default', tn;
}
var ca;
function n_() {
  if (ca) return en;
  ca = 1, Object.defineProperty(en, "__esModule", { value: !0 });
  const t = /* @__PURE__ */ ie(), e = /* @__PURE__ */ de(), r = /* @__PURE__ */ r_(), o = {
    keyword: ["maxLength", "minLength"],
    type: "string",
    schemaType: "number",
    $data: !0,
    error: {
      message({ keyword: s, schemaCode: i }) {
        const a = s === "maxLength" ? "more" : "fewer";
        return (0, t.str)`must NOT have ${a} than ${i} characters`;
      },
      params: ({ schemaCode: s }) => (0, t._)`{limit: ${s}}`
    },
    code(s) {
      const { keyword: i, data: a, schemaCode: c, it: u } = s, l = i === "maxLength" ? t.operators.GT : t.operators.LT, h = u.opts.unicode === !1 ? (0, t._)`${a}.length` : (0, t._)`${(0, e.useFunc)(s.gen, r.default)}(${a})`;
      s.fail$data((0, t._)`${h} ${l} ${c}`);
    }
  };
  return en.default = o, en;
}
var rn = {}, ua;
function o_() {
  if (ua) return rn;
  ua = 1, Object.defineProperty(rn, "__esModule", { value: !0 });
  const t = /* @__PURE__ */ _t(), e = /* @__PURE__ */ de(), r = /* @__PURE__ */ ie(), o = {
    keyword: "pattern",
    type: "string",
    schemaType: "string",
    $data: !0,
    error: {
      message: ({ schemaCode: s }) => (0, r.str)`must match pattern "${s}"`,
      params: ({ schemaCode: s }) => (0, r._)`{pattern: ${s}}`
    },
    code(s) {
      const { gen: i, data: a, $data: c, schema: u, schemaCode: l, it: h } = s, m = h.opts.unicodeRegExp ? "u" : "";
      if (c) {
        const { regExp: _ } = h.opts.code, S = _.code === "new RegExp" ? (0, r._)`new RegExp` : (0, e.useFunc)(i, _), $ = i.let("valid");
        i.try(() => i.assign($, (0, r._)`${S}(${l}, ${m}).test(${a})`), () => i.assign($, !1)), s.fail$data((0, r._)`!${$}`);
      } else {
        const _ = (0, t.usePattern)(s, u);
        s.fail$data((0, r._)`!${_}.test(${a})`);
      }
    }
  };
  return rn.default = o, rn;
}
var nn = {}, la;
function s_() {
  if (la) return nn;
  la = 1, Object.defineProperty(nn, "__esModule", { value: !0 });
  const t = /* @__PURE__ */ ie(), r = {
    keyword: ["maxProperties", "minProperties"],
    type: "object",
    schemaType: "number",
    $data: !0,
    error: {
      message({ keyword: n, schemaCode: o }) {
        const s = n === "maxProperties" ? "more" : "fewer";
        return (0, t.str)`must NOT have ${s} than ${o} properties`;
      },
      params: ({ schemaCode: n }) => (0, t._)`{limit: ${n}}`
    },
    code(n) {
      const { keyword: o, data: s, schemaCode: i } = n, a = o === "maxProperties" ? t.operators.GT : t.operators.LT;
      n.fail$data((0, t._)`Object.keys(${s}).length ${a} ${i}`);
    }
  };
  return nn.default = r, nn;
}
var on = {}, da;
function i_() {
  if (da) return on;
  da = 1, Object.defineProperty(on, "__esModule", { value: !0 });
  const t = /* @__PURE__ */ _t(), e = /* @__PURE__ */ ie(), r = /* @__PURE__ */ de(), o = {
    keyword: "required",
    type: "object",
    schemaType: "array",
    $data: !0,
    error: {
      message: ({ params: { missingProperty: s } }) => (0, e.str)`must have required property '${s}'`,
      params: ({ params: { missingProperty: s } }) => (0, e._)`{missingProperty: ${s}}`
    },
    code(s) {
      const { gen: i, schema: a, schemaCode: c, data: u, $data: l, it: h } = s, { opts: m } = h;
      if (!l && a.length === 0)
        return;
      const _ = a.length >= m.loopRequired;
      if (h.allErrors ? S() : $(), m.strictRequired) {
        const g = s.parentSchema.properties, { definedProperties: w } = s.it;
        for (const k of a)
          if ((g == null ? void 0 : g[k]) === void 0 && !w.has(k)) {
            const f = h.schemaEnv.baseId + h.errSchemaPath, d = `required property "${k}" is not defined at "${f}" (strictRequired)`;
            (0, r.checkStrictMode)(h, d, h.opts.strictRequired);
          }
      }
      function S() {
        if (_ || l)
          s.block$data(e.nil, v);
        else
          for (const g of a)
            (0, t.checkReportMissingProp)(s, g);
      }
      function $() {
        const g = i.let("missing");
        if (_ || l) {
          const w = i.let("valid", !0);
          s.block$data(w, () => y(g, w)), s.ok(w);
        } else
          i.if((0, t.checkMissingProp)(s, a, g)), (0, t.reportMissingProp)(s, g), i.else();
      }
      function v() {
        i.forOf("prop", c, (g) => {
          s.setParams({ missingProperty: g }), i.if((0, t.noPropertyInData)(i, u, g, m.ownProperties), () => s.error());
        });
      }
      function y(g, w) {
        s.setParams({ missingProperty: g }), i.forOf(g, c, () => {
          i.assign(w, (0, t.propertyInData)(i, u, g, m.ownProperties)), i.if((0, e.not)(w), () => {
            s.error(), i.break();
          });
        }, e.nil);
      }
    }
  };
  return on.default = o, on;
}
var sn = {}, fa;
function a_() {
  if (fa) return sn;
  fa = 1, Object.defineProperty(sn, "__esModule", { value: !0 });
  const t = /* @__PURE__ */ ie(), r = {
    keyword: ["maxItems", "minItems"],
    type: "array",
    schemaType: "number",
    $data: !0,
    error: {
      message({ keyword: n, schemaCode: o }) {
        const s = n === "maxItems" ? "more" : "fewer";
        return (0, t.str)`must NOT have ${s} than ${o} items`;
      },
      params: ({ schemaCode: n }) => (0, t._)`{limit: ${n}}`
    },
    code(n) {
      const { keyword: o, data: s, schemaCode: i } = n, a = o === "maxItems" ? t.operators.GT : t.operators.LT;
      n.fail$data((0, t._)`${s}.length ${a} ${i}`);
    }
  };
  return sn.default = r, sn;
}
var an = {}, cn = {}, ha;
function Vs() {
  if (ha) return cn;
  ha = 1, Object.defineProperty(cn, "__esModule", { value: !0 });
  const t = Cu();
  return t.code = 'require("ajv/dist/runtime/equal").default', cn.default = t, cn;
}
var pa;
function c_() {
  if (pa) return an;
  pa = 1, Object.defineProperty(an, "__esModule", { value: !0 });
  const t = /* @__PURE__ */ Fn(), e = /* @__PURE__ */ ie(), r = /* @__PURE__ */ de(), n = /* @__PURE__ */ Vs(), s = {
    keyword: "uniqueItems",
    type: "array",
    schemaType: "boolean",
    $data: !0,
    error: {
      message: ({ params: { i, j: a } }) => (0, e.str)`must NOT have duplicate items (items ## ${a} and ${i} are identical)`,
      params: ({ params: { i, j: a } }) => (0, e._)`{i: ${i}, j: ${a}}`
    },
    code(i) {
      const { gen: a, data: c, $data: u, schema: l, parentSchema: h, schemaCode: m, it: _ } = i;
      if (!u && !l)
        return;
      const S = a.let("valid"), $ = h.items ? (0, t.getSchemaTypes)(h.items) : [];
      i.block$data(S, v, (0, e._)`${m} === false`), i.ok(S);
      function v() {
        const k = a.let("i", (0, e._)`${c}.length`), f = a.let("j");
        i.setParams({ i: k, j: f }), a.assign(S, !0), a.if((0, e._)`${k} > 1`, () => (y() ? g : w)(k, f));
      }
      function y() {
        return $.length > 0 && !$.some((k) => k === "object" || k === "array");
      }
      function g(k, f) {
        const d = a.name("item"), p = (0, t.checkDataTypes)($, d, _.opts.strictNumbers, t.DataType.Wrong), E = a.const("indices", (0, e._)`{}`);
        a.for((0, e._)`;${k}--;`, () => {
          a.let(d, (0, e._)`${c}[${k}]`), a.if(p, (0, e._)`continue`), $.length > 1 && a.if((0, e._)`typeof ${d} == "string"`, (0, e._)`${d} += "_"`), a.if((0, e._)`typeof ${E}[${d}] == "number"`, () => {
            a.assign(f, (0, e._)`${E}[${d}]`), i.error(), a.assign(S, !1).break();
          }).code((0, e._)`${E}[${d}] = ${k}`);
        });
      }
      function w(k, f) {
        const d = (0, r.useFunc)(a, n.default), p = a.name("outer");
        a.label(p).for((0, e._)`;${k}--;`, () => a.for((0, e._)`${f} = ${k}; ${f}--;`, () => a.if((0, e._)`${d}(${c}[${k}], ${c}[${f}])`, () => {
          i.error(), a.assign(S, !1).break(p);
        })));
      }
    }
  };
  return an.default = s, an;
}
var un = {}, ma;
function u_() {
  if (ma) return un;
  ma = 1, Object.defineProperty(un, "__esModule", { value: !0 });
  const t = /* @__PURE__ */ ie(), e = /* @__PURE__ */ de(), r = /* @__PURE__ */ Vs(), o = {
    keyword: "const",
    $data: !0,
    error: {
      message: "must be equal to constant",
      params: ({ schemaCode: s }) => (0, t._)`{allowedValue: ${s}}`
    },
    code(s) {
      const { gen: i, data: a, $data: c, schemaCode: u, schema: l } = s;
      c || l && typeof l == "object" ? s.fail$data((0, t._)`!${(0, e.useFunc)(i, r.default)}(${a}, ${u})`) : s.fail((0, t._)`${l} !== ${a}`);
    }
  };
  return un.default = o, un;
}
var ln = {}, ga;
function l_() {
  if (ga) return ln;
  ga = 1, Object.defineProperty(ln, "__esModule", { value: !0 });
  const t = /* @__PURE__ */ ie(), e = /* @__PURE__ */ de(), r = /* @__PURE__ */ Vs(), o = {
    keyword: "enum",
    schemaType: "array",
    $data: !0,
    error: {
      message: "must be equal to one of the allowed values",
      params: ({ schemaCode: s }) => (0, t._)`{allowedValues: ${s}}`
    },
    code(s) {
      const { gen: i, data: a, $data: c, schema: u, schemaCode: l, it: h } = s;
      if (!c && u.length === 0)
        throw new Error("enum must have non-empty array");
      const m = u.length >= h.opts.loopEnum;
      let _;
      const S = () => _ ?? (_ = (0, e.useFunc)(i, r.default));
      let $;
      if (m || c)
        $ = i.let("valid"), s.block$data($, v);
      else {
        if (!Array.isArray(u))
          throw new Error("ajv implementation error");
        const g = i.const("vSchema", l);
        $ = (0, t.or)(...u.map((w, k) => y(g, k)));
      }
      s.pass($);
      function v() {
        i.assign($, !1), i.forOf("v", l, (g) => i.if((0, t._)`${S()}(${a}, ${g})`, () => i.assign($, !0).break()));
      }
      function y(g, w) {
        const k = u[w];
        return typeof k == "object" && k !== null ? (0, t._)`${S()}(${a}, ${g}[${w}])` : (0, t._)`${a} === ${k}`;
      }
    }
  };
  return ln.default = o, ln;
}
var _a;
function d_() {
  if (_a) return Qr;
  _a = 1, Object.defineProperty(Qr, "__esModule", { value: !0 });
  const t = /* @__PURE__ */ e_(), e = /* @__PURE__ */ t_(), r = /* @__PURE__ */ n_(), n = /* @__PURE__ */ o_(), o = /* @__PURE__ */ s_(), s = /* @__PURE__ */ i_(), i = /* @__PURE__ */ a_(), a = /* @__PURE__ */ c_(), c = /* @__PURE__ */ u_(), u = /* @__PURE__ */ l_(), l = [
    // number
    t.default,
    e.default,
    // string
    r.default,
    n.default,
    // object
    o.default,
    s.default,
    // array
    i.default,
    a.default,
    // any
    { keyword: "type", schemaType: ["string", "array"] },
    { keyword: "nullable", schemaType: "boolean" },
    c.default,
    u.default
  ];
  return Qr.default = l, Qr;
}
var dn = {}, Jt = {}, ya;
function Pu() {
  if (ya) return Jt;
  ya = 1, Object.defineProperty(Jt, "__esModule", { value: !0 }), Jt.validateAdditionalItems = void 0;
  const t = /* @__PURE__ */ ie(), e = /* @__PURE__ */ de(), n = {
    keyword: "additionalItems",
    type: "array",
    schemaType: ["boolean", "object"],
    before: "uniqueItems",
    error: {
      message: ({ params: { len: s } }) => (0, t.str)`must NOT have more than ${s} items`,
      params: ({ params: { len: s } }) => (0, t._)`{limit: ${s}}`
    },
    code(s) {
      const { parentSchema: i, it: a } = s, { items: c } = i;
      if (!Array.isArray(c)) {
        (0, e.checkStrictMode)(a, '"additionalItems" is ignored when "items" is not an array of schemas');
        return;
      }
      o(s, c);
    }
  };
  function o(s, i) {
    const { gen: a, schema: c, data: u, keyword: l, it: h } = s;
    h.items = !0;
    const m = a.const("len", (0, t._)`${u}.length`);
    if (c === !1)
      s.setParams({ len: i.length }), s.pass((0, t._)`${m} <= ${i.length}`);
    else if (typeof c == "object" && !(0, e.alwaysValidSchema)(h, c)) {
      const S = a.var("valid", (0, t._)`${m} <= ${i.length}`);
      a.if((0, t.not)(S), () => _(S)), s.ok(S);
    }
    function _(S) {
      a.forRange("i", i.length, m, ($) => {
        s.subschema({ keyword: l, dataProp: $, dataPropType: e.Type.Num }, S), h.allErrors || a.if((0, t.not)(S), () => a.break());
      });
    }
  }
  return Jt.validateAdditionalItems = o, Jt.default = n, Jt;
}
var fn = {}, Qt = {}, va;
function Au() {
  if (va) return Qt;
  va = 1, Object.defineProperty(Qt, "__esModule", { value: !0 }), Qt.validateTuple = void 0;
  const t = /* @__PURE__ */ ie(), e = /* @__PURE__ */ de(), r = /* @__PURE__ */ _t(), n = {
    keyword: "items",
    type: "array",
    schemaType: ["object", "array", "boolean"],
    before: "uniqueItems",
    code(s) {
      const { schema: i, it: a } = s;
      if (Array.isArray(i))
        return o(s, "additionalItems", i);
      a.items = !0, !(0, e.alwaysValidSchema)(a, i) && s.ok((0, r.validateArray)(s));
    }
  };
  function o(s, i, a = s.schema) {
    const { gen: c, parentSchema: u, data: l, keyword: h, it: m } = s;
    $(u), m.opts.unevaluated && a.length && m.items !== !0 && (m.items = e.mergeEvaluated.items(c, a.length, m.items));
    const _ = c.name("valid"), S = c.const("len", (0, t._)`${l}.length`);
    a.forEach((v, y) => {
      (0, e.alwaysValidSchema)(m, v) || (c.if((0, t._)`${S} > ${y}`, () => s.subschema({
        keyword: h,
        schemaProp: y,
        dataProp: y
      }, _)), s.ok(_));
    });
    function $(v) {
      const { opts: y, errSchemaPath: g } = m, w = a.length, k = w === v.minItems && (w === v.maxItems || v[i] === !1);
      if (y.strictTuples && !k) {
        const f = `"${h}" is ${w}-tuple, but minItems or maxItems/${i} are not specified or different at path "${g}"`;
        (0, e.checkStrictMode)(m, f, y.strictTuples);
      }
    }
  }
  return Qt.validateTuple = o, Qt.default = n, Qt;
}
var wa;
function f_() {
  if (wa) return fn;
  wa = 1, Object.defineProperty(fn, "__esModule", { value: !0 });
  const t = /* @__PURE__ */ Au(), e = {
    keyword: "prefixItems",
    type: "array",
    schemaType: ["array"],
    before: "uniqueItems",
    code: (r) => (0, t.validateTuple)(r, "items")
  };
  return fn.default = e, fn;
}
var hn = {}, ba;
function h_() {
  if (ba) return hn;
  ba = 1, Object.defineProperty(hn, "__esModule", { value: !0 });
  const t = /* @__PURE__ */ ie(), e = /* @__PURE__ */ de(), r = /* @__PURE__ */ _t(), n = /* @__PURE__ */ Pu(), s = {
    keyword: "items",
    type: "array",
    schemaType: ["object", "boolean"],
    before: "uniqueItems",
    error: {
      message: ({ params: { len: i } }) => (0, t.str)`must NOT have more than ${i} items`,
      params: ({ params: { len: i } }) => (0, t._)`{limit: ${i}}`
    },
    code(i) {
      const { schema: a, parentSchema: c, it: u } = i, { prefixItems: l } = c;
      u.items = !0, !(0, e.alwaysValidSchema)(u, a) && (l ? (0, n.validateAdditionalItems)(i, l) : i.ok((0, r.validateArray)(i)));
    }
  };
  return hn.default = s, hn;
}
var pn = {}, $a;
function p_() {
  if ($a) return pn;
  $a = 1, Object.defineProperty(pn, "__esModule", { value: !0 });
  const t = /* @__PURE__ */ ie(), e = /* @__PURE__ */ de(), n = {
    keyword: "contains",
    type: "array",
    schemaType: ["object", "boolean"],
    before: "uniqueItems",
    trackErrors: !0,
    error: {
      message: ({ params: { min: o, max: s } }) => s === void 0 ? (0, t.str)`must contain at least ${o} valid item(s)` : (0, t.str)`must contain at least ${o} and no more than ${s} valid item(s)`,
      params: ({ params: { min: o, max: s } }) => s === void 0 ? (0, t._)`{minContains: ${o}}` : (0, t._)`{minContains: ${o}, maxContains: ${s}}`
    },
    code(o) {
      const { gen: s, schema: i, parentSchema: a, data: c, it: u } = o;
      let l, h;
      const { minContains: m, maxContains: _ } = a;
      u.opts.next ? (l = m === void 0 ? 1 : m, h = _) : l = 1;
      const S = s.const("len", (0, t._)`${c}.length`);
      if (o.setParams({ min: l, max: h }), h === void 0 && l === 0) {
        (0, e.checkStrictMode)(u, '"minContains" == 0 without "maxContains": "contains" keyword ignored');
        return;
      }
      if (h !== void 0 && l > h) {
        (0, e.checkStrictMode)(u, '"minContains" > "maxContains" is always invalid'), o.fail();
        return;
      }
      if ((0, e.alwaysValidSchema)(u, i)) {
        let w = (0, t._)`${S} >= ${l}`;
        h !== void 0 && (w = (0, t._)`${w} && ${S} <= ${h}`), o.pass(w);
        return;
      }
      u.items = !0;
      const $ = s.name("valid");
      h === void 0 && l === 1 ? y($, () => s.if($, () => s.break())) : l === 0 ? (s.let($, !0), h !== void 0 && s.if((0, t._)`${c}.length > 0`, v)) : (s.let($, !1), v()), o.result($, () => o.reset());
      function v() {
        const w = s.name("_valid"), k = s.let("count", 0);
        y(w, () => s.if(w, () => g(k)));
      }
      function y(w, k) {
        s.forRange("i", 0, S, (f) => {
          o.subschema({
            keyword: "contains",
            dataProp: f,
            dataPropType: e.Type.Num,
            compositeRule: !0
          }, w), k();
        });
      }
      function g(w) {
        s.code((0, t._)`${w}++`), h === void 0 ? s.if((0, t._)`${w} >= ${l}`, () => s.assign($, !0).break()) : (s.if((0, t._)`${w} > ${h}`, () => s.assign($, !1).break()), l === 1 ? s.assign($, !0) : s.if((0, t._)`${w} >= ${l}`, () => s.assign($, !0)));
      }
    }
  };
  return pn.default = n, pn;
}
var Co = {}, Sa;
function m_() {
  return Sa || (Sa = 1, function(t) {
    Object.defineProperty(t, "__esModule", { value: !0 }), t.validateSchemaDeps = t.validatePropertyDeps = t.error = void 0;
    const e = /* @__PURE__ */ ie(), r = /* @__PURE__ */ de(), n = /* @__PURE__ */ _t();
    t.error = {
      message: ({ params: { property: c, depsCount: u, deps: l } }) => {
        const h = u === 1 ? "property" : "properties";
        return (0, e.str)`must have ${h} ${l} when property ${c} is present`;
      },
      params: ({ params: { property: c, depsCount: u, deps: l, missingProperty: h } }) => (0, e._)`{property: ${c},
    missingProperty: ${h},
    depsCount: ${u},
    deps: ${l}}`
      // TODO change to reference
    };
    const o = {
      keyword: "dependencies",
      type: "object",
      schemaType: "object",
      error: t.error,
      code(c) {
        const [u, l] = s(c);
        i(c, u), a(c, l);
      }
    };
    function s({ schema: c }) {
      const u = {}, l = {};
      for (const h in c) {
        if (h === "__proto__")
          continue;
        const m = Array.isArray(c[h]) ? u : l;
        m[h] = c[h];
      }
      return [u, l];
    }
    function i(c, u = c.schema) {
      const { gen: l, data: h, it: m } = c;
      if (Object.keys(u).length === 0)
        return;
      const _ = l.let("missing");
      for (const S in u) {
        const $ = u[S];
        if ($.length === 0)
          continue;
        const v = (0, n.propertyInData)(l, h, S, m.opts.ownProperties);
        c.setParams({
          property: S,
          depsCount: $.length,
          deps: $.join(", ")
        }), m.allErrors ? l.if(v, () => {
          for (const y of $)
            (0, n.checkReportMissingProp)(c, y);
        }) : (l.if((0, e._)`${v} && (${(0, n.checkMissingProp)(c, $, _)})`), (0, n.reportMissingProp)(c, _), l.else());
      }
    }
    t.validatePropertyDeps = i;
    function a(c, u = c.schema) {
      const { gen: l, data: h, keyword: m, it: _ } = c, S = l.name("valid");
      for (const $ in u)
        (0, r.alwaysValidSchema)(_, u[$]) || (l.if(
          (0, n.propertyInData)(l, h, $, _.opts.ownProperties),
          () => {
            const v = c.subschema({ keyword: m, schemaProp: $ }, S);
            c.mergeValidEvaluated(v, S);
          },
          () => l.var(S, !0)
          // TODO var
        ), c.ok(S));
    }
    t.validateSchemaDeps = a, t.default = o;
  }(Co)), Co;
}
var mn = {}, Ea;
function g_() {
  if (Ea) return mn;
  Ea = 1, Object.defineProperty(mn, "__esModule", { value: !0 });
  const t = /* @__PURE__ */ ie(), e = /* @__PURE__ */ de(), n = {
    keyword: "propertyNames",
    type: "object",
    schemaType: ["object", "boolean"],
    error: {
      message: "property name must be valid",
      params: ({ params: o }) => (0, t._)`{propertyName: ${o.propertyName}}`
    },
    code(o) {
      const { gen: s, schema: i, data: a, it: c } = o;
      if ((0, e.alwaysValidSchema)(c, i))
        return;
      const u = s.name("valid");
      s.forIn("key", a, (l) => {
        o.setParams({ propertyName: l }), o.subschema({
          keyword: "propertyNames",
          data: l,
          dataTypes: ["string"],
          propertyName: l,
          compositeRule: !0
        }, u), s.if((0, t.not)(u), () => {
          o.error(!0), c.allErrors || s.break();
        });
      }), o.ok(u);
    }
  };
  return mn.default = n, mn;
}
var gn = {}, ka;
function Ru() {
  if (ka) return gn;
  ka = 1, Object.defineProperty(gn, "__esModule", { value: !0 });
  const t = /* @__PURE__ */ _t(), e = /* @__PURE__ */ ie(), r = /* @__PURE__ */ zt(), n = /* @__PURE__ */ de(), s = {
    keyword: "additionalProperties",
    type: ["object"],
    schemaType: ["boolean", "object"],
    allowUndefined: !0,
    trackErrors: !0,
    error: {
      message: "must NOT have additional properties",
      params: ({ params: i }) => (0, e._)`{additionalProperty: ${i.additionalProperty}}`
    },
    code(i) {
      const { gen: a, schema: c, parentSchema: u, data: l, errsCount: h, it: m } = i;
      if (!h)
        throw new Error("ajv implementation error");
      const { allErrors: _, opts: S } = m;
      if (m.props = !0, S.removeAdditional !== "all" && (0, n.alwaysValidSchema)(m, c))
        return;
      const $ = (0, t.allSchemaProperties)(u.properties), v = (0, t.allSchemaProperties)(u.patternProperties);
      y(), i.ok((0, e._)`${h} === ${r.default.errors}`);
      function y() {
        a.forIn("key", l, (d) => {
          !$.length && !v.length ? k(d) : a.if(g(d), () => k(d));
        });
      }
      function g(d) {
        let p;
        if ($.length > 8) {
          const E = (0, n.schemaRefOrVal)(m, u.properties, "properties");
          p = (0, t.isOwnProperty)(a, E, d);
        } else $.length ? p = (0, e.or)(...$.map((E) => (0, e._)`${d} === ${E}`)) : p = e.nil;
        return v.length && (p = (0, e.or)(p, ...v.map((E) => (0, e._)`${(0, t.usePattern)(i, E)}.test(${d})`))), (0, e.not)(p);
      }
      function w(d) {
        a.code((0, e._)`delete ${l}[${d}]`);
      }
      function k(d) {
        if (S.removeAdditional === "all" || S.removeAdditional && c === !1) {
          w(d);
          return;
        }
        if (c === !1) {
          i.setParams({ additionalProperty: d }), i.error(), _ || a.break();
          return;
        }
        if (typeof c == "object" && !(0, n.alwaysValidSchema)(m, c)) {
          const p = a.name("valid");
          S.removeAdditional === "failing" ? (f(d, p, !1), a.if((0, e.not)(p), () => {
            i.reset(), w(d);
          })) : (f(d, p), _ || a.if((0, e.not)(p), () => a.break()));
        }
      }
      function f(d, p, E) {
        const I = {
          keyword: "additionalProperties",
          dataProp: d,
          dataPropType: n.Type.Str
        };
        E === !1 && Object.assign(I, {
          compositeRule: !0,
          createErrors: !1,
          allErrors: !1
        }), i.subschema(I, p);
      }
    }
  };
  return gn.default = s, gn;
}
var _n = {}, Ca;
function __() {
  if (Ca) return _n;
  Ca = 1, Object.defineProperty(_n, "__esModule", { value: !0 });
  const t = /* @__PURE__ */ io(), e = /* @__PURE__ */ _t(), r = /* @__PURE__ */ de(), n = /* @__PURE__ */ Ru(), o = {
    keyword: "properties",
    type: "object",
    schemaType: "object",
    code(s) {
      const { gen: i, schema: a, parentSchema: c, data: u, it: l } = s;
      l.opts.removeAdditional === "all" && c.additionalProperties === void 0 && n.default.code(new t.KeywordCxt(l, n.default, "additionalProperties"));
      const h = (0, e.allSchemaProperties)(a);
      for (const v of h)
        l.definedProperties.add(v);
      l.opts.unevaluated && h.length && l.props !== !0 && (l.props = r.mergeEvaluated.props(i, (0, r.toHash)(h), l.props));
      const m = h.filter((v) => !(0, r.alwaysValidSchema)(l, a[v]));
      if (m.length === 0)
        return;
      const _ = i.name("valid");
      for (const v of m)
        S(v) ? $(v) : (i.if((0, e.propertyInData)(i, u, v, l.opts.ownProperties)), $(v), l.allErrors || i.else().var(_, !0), i.endIf()), s.it.definedProperties.add(v), s.ok(_);
      function S(v) {
        return l.opts.useDefaults && !l.compositeRule && a[v].default !== void 0;
      }
      function $(v) {
        s.subschema({
          keyword: "properties",
          schemaProp: v,
          dataProp: v
        }, _);
      }
    }
  };
  return _n.default = o, _n;
}
var yn = {}, Ta;
function y_() {
  if (Ta) return yn;
  Ta = 1, Object.defineProperty(yn, "__esModule", { value: !0 });
  const t = /* @__PURE__ */ _t(), e = /* @__PURE__ */ ie(), r = /* @__PURE__ */ de(), n = /* @__PURE__ */ de(), o = {
    keyword: "patternProperties",
    type: "object",
    schemaType: "object",
    code(s) {
      const { gen: i, schema: a, data: c, parentSchema: u, it: l } = s, { opts: h } = l, m = (0, t.allSchemaProperties)(a), _ = m.filter((k) => (0, r.alwaysValidSchema)(l, a[k]));
      if (m.length === 0 || _.length === m.length && (!l.opts.unevaluated || l.props === !0))
        return;
      const S = h.strictSchema && !h.allowMatchingProperties && u.properties, $ = i.name("valid");
      l.props !== !0 && !(l.props instanceof e.Name) && (l.props = (0, n.evaluatedPropsToName)(i, l.props));
      const { props: v } = l;
      y();
      function y() {
        for (const k of m)
          S && g(k), l.allErrors ? w(k) : (i.var($, !0), w(k), i.if($));
      }
      function g(k) {
        for (const f in S)
          new RegExp(k).test(f) && (0, r.checkStrictMode)(l, `property ${f} matches pattern ${k} (use allowMatchingProperties)`);
      }
      function w(k) {
        i.forIn("key", c, (f) => {
          i.if((0, e._)`${(0, t.usePattern)(s, k)}.test(${f})`, () => {
            const d = _.includes(k);
            d || s.subschema({
              keyword: "patternProperties",
              schemaProp: k,
              dataProp: f,
              dataPropType: n.Type.Str
            }, $), l.opts.unevaluated && v !== !0 ? i.assign((0, e._)`${v}[${f}]`, !0) : !d && !l.allErrors && i.if((0, e.not)($), () => i.break());
          });
        });
      }
    }
  };
  return yn.default = o, yn;
}
var vn = {}, Pa;
function v_() {
  if (Pa) return vn;
  Pa = 1, Object.defineProperty(vn, "__esModule", { value: !0 });
  const t = /* @__PURE__ */ de(), e = {
    keyword: "not",
    schemaType: ["object", "boolean"],
    trackErrors: !0,
    code(r) {
      const { gen: n, schema: o, it: s } = r;
      if ((0, t.alwaysValidSchema)(s, o)) {
        r.fail();
        return;
      }
      const i = n.name("valid");
      r.subschema({
        keyword: "not",
        compositeRule: !0,
        createErrors: !1,
        allErrors: !1
      }, i), r.failResult(i, () => r.reset(), () => r.error());
    },
    error: { message: "must NOT be valid" }
  };
  return vn.default = e, vn;
}
var wn = {}, Aa;
function w_() {
  if (Aa) return wn;
  Aa = 1, Object.defineProperty(wn, "__esModule", { value: !0 });
  const e = {
    keyword: "anyOf",
    schemaType: "array",
    trackErrors: !0,
    code: (/* @__PURE__ */ _t()).validateUnion,
    error: { message: "must match a schema in anyOf" }
  };
  return wn.default = e, wn;
}
var bn = {}, Ra;
function b_() {
  if (Ra) return bn;
  Ra = 1, Object.defineProperty(bn, "__esModule", { value: !0 });
  const t = /* @__PURE__ */ ie(), e = /* @__PURE__ */ de(), n = {
    keyword: "oneOf",
    schemaType: "array",
    trackErrors: !0,
    error: {
      message: "must match exactly one schema in oneOf",
      params: ({ params: o }) => (0, t._)`{passingSchemas: ${o.passing}}`
    },
    code(o) {
      const { gen: s, schema: i, parentSchema: a, it: c } = o;
      if (!Array.isArray(i))
        throw new Error("ajv implementation error");
      if (c.opts.discriminator && a.discriminator)
        return;
      const u = i, l = s.let("valid", !1), h = s.let("passing", null), m = s.name("_valid");
      o.setParams({ passing: h }), s.block(_), o.result(l, () => o.reset(), () => o.error(!0));
      function _() {
        u.forEach((S, $) => {
          let v;
          (0, e.alwaysValidSchema)(c, S) ? s.var(m, !0) : v = o.subschema({
            keyword: "oneOf",
            schemaProp: $,
            compositeRule: !0
          }, m), $ > 0 && s.if((0, t._)`${m} && ${l}`).assign(l, !1).assign(h, (0, t._)`[${h}, ${$}]`).else(), s.if(m, () => {
            s.assign(l, !0), s.assign(h, $), v && o.mergeEvaluated(v, t.Name);
          });
        });
      }
    }
  };
  return bn.default = n, bn;
}
var $n = {}, Ia;
function $_() {
  if (Ia) return $n;
  Ia = 1, Object.defineProperty($n, "__esModule", { value: !0 });
  const t = /* @__PURE__ */ de(), e = {
    keyword: "allOf",
    schemaType: "array",
    code(r) {
      const { gen: n, schema: o, it: s } = r;
      if (!Array.isArray(o))
        throw new Error("ajv implementation error");
      const i = n.name("valid");
      o.forEach((a, c) => {
        if ((0, t.alwaysValidSchema)(s, a))
          return;
        const u = r.subschema({ keyword: "allOf", schemaProp: c }, i);
        r.ok(i), r.mergeEvaluated(u);
      });
    }
  };
  return $n.default = e, $n;
}
var Sn = {}, Oa;
function S_() {
  if (Oa) return Sn;
  Oa = 1, Object.defineProperty(Sn, "__esModule", { value: !0 });
  const t = /* @__PURE__ */ ie(), e = /* @__PURE__ */ de(), n = {
    keyword: "if",
    schemaType: ["object", "boolean"],
    trackErrors: !0,
    error: {
      message: ({ params: s }) => (0, t.str)`must match "${s.ifClause}" schema`,
      params: ({ params: s }) => (0, t._)`{failingKeyword: ${s.ifClause}}`
    },
    code(s) {
      const { gen: i, parentSchema: a, it: c } = s;
      a.then === void 0 && a.else === void 0 && (0, e.checkStrictMode)(c, '"if" without "then" and "else" is ignored');
      const u = o(c, "then"), l = o(c, "else");
      if (!u && !l)
        return;
      const h = i.let("valid", !0), m = i.name("_valid");
      if (_(), s.reset(), u && l) {
        const $ = i.let("ifClause");
        s.setParams({ ifClause: $ }), i.if(m, S("then", $), S("else", $));
      } else u ? i.if(m, S("then")) : i.if((0, t.not)(m), S("else"));
      s.pass(h, () => s.error(!0));
      function _() {
        const $ = s.subschema({
          keyword: "if",
          compositeRule: !0,
          createErrors: !1,
          allErrors: !1
        }, m);
        s.mergeEvaluated($);
      }
      function S($, v) {
        return () => {
          const y = s.subschema({ keyword: $ }, m);
          i.assign(h, m), s.mergeValidEvaluated(y, h), v ? i.assign(v, (0, t._)`${$}`) : s.setParams({ ifClause: $ });
        };
      }
    }
  };
  function o(s, i) {
    const a = s.schema[i];
    return a !== void 0 && !(0, e.alwaysValidSchema)(s, a);
  }
  return Sn.default = n, Sn;
}
var En = {}, za;
function E_() {
  if (za) return En;
  za = 1, Object.defineProperty(En, "__esModule", { value: !0 });
  const t = /* @__PURE__ */ de(), e = {
    keyword: ["then", "else"],
    schemaType: ["object", "boolean"],
    code({ keyword: r, parentSchema: n, it: o }) {
      n.if === void 0 && (0, t.checkStrictMode)(o, `"${r}" without "if" is ignored`);
    }
  };
  return En.default = e, En;
}
var Na;
function k_() {
  if (Na) return dn;
  Na = 1, Object.defineProperty(dn, "__esModule", { value: !0 });
  const t = /* @__PURE__ */ Pu(), e = /* @__PURE__ */ f_(), r = /* @__PURE__ */ Au(), n = /* @__PURE__ */ h_(), o = /* @__PURE__ */ p_(), s = /* @__PURE__ */ m_(), i = /* @__PURE__ */ g_(), a = /* @__PURE__ */ Ru(), c = /* @__PURE__ */ __(), u = /* @__PURE__ */ y_(), l = /* @__PURE__ */ v_(), h = /* @__PURE__ */ w_(), m = /* @__PURE__ */ b_(), _ = /* @__PURE__ */ $_(), S = /* @__PURE__ */ S_(), $ = /* @__PURE__ */ E_();
  function v(y = !1) {
    const g = [
      // any
      l.default,
      h.default,
      m.default,
      _.default,
      S.default,
      $.default,
      // object
      i.default,
      a.default,
      s.default,
      c.default,
      u.default
    ];
    return y ? g.push(e.default, n.default) : g.push(t.default, r.default), g.push(o.default), g;
  }
  return dn.default = v, dn;
}
var kn = {}, Cn = {}, Ma;
function C_() {
  if (Ma) return Cn;
  Ma = 1, Object.defineProperty(Cn, "__esModule", { value: !0 });
  const t = /* @__PURE__ */ ie(), r = {
    keyword: "format",
    type: ["number", "string"],
    schemaType: "string",
    $data: !0,
    error: {
      message: ({ schemaCode: n }) => (0, t.str)`must match format "${n}"`,
      params: ({ schemaCode: n }) => (0, t._)`{format: ${n}}`
    },
    code(n, o) {
      const { gen: s, data: i, $data: a, schema: c, schemaCode: u, it: l } = n, { opts: h, errSchemaPath: m, schemaEnv: _, self: S } = l;
      if (!h.validateFormats)
        return;
      a ? $() : v();
      function $() {
        const y = s.scopeValue("formats", {
          ref: S.formats,
          code: h.code.formats
        }), g = s.const("fDef", (0, t._)`${y}[${u}]`), w = s.let("fType"), k = s.let("format");
        s.if((0, t._)`typeof ${g} == "object" && !(${g} instanceof RegExp)`, () => s.assign(w, (0, t._)`${g}.type || "string"`).assign(k, (0, t._)`${g}.validate`), () => s.assign(w, (0, t._)`"string"`).assign(k, g)), n.fail$data((0, t.or)(f(), d()));
        function f() {
          return h.strictSchema === !1 ? t.nil : (0, t._)`${u} && !${k}`;
        }
        function d() {
          const p = _.$async ? (0, t._)`(${g}.async ? await ${k}(${i}) : ${k}(${i}))` : (0, t._)`${k}(${i})`, E = (0, t._)`(typeof ${k} == "function" ? ${p} : ${k}.test(${i}))`;
          return (0, t._)`${k} && ${k} !== true && ${w} === ${o} && !${E}`;
        }
      }
      function v() {
        const y = S.formats[c];
        if (!y) {
          f();
          return;
        }
        if (y === !0)
          return;
        const [g, w, k] = d(y);
        g === o && n.pass(p());
        function f() {
          if (h.strictSchema === !1) {
            S.logger.warn(E());
            return;
          }
          throw new Error(E());
          function E() {
            return `unknown format "${c}" ignored in schema at path "${m}"`;
          }
        }
        function d(E) {
          const I = E instanceof RegExp ? (0, t.regexpCode)(E) : h.code.formats ? (0, t._)`${h.code.formats}${(0, t.getProperty)(c)}` : void 0, R = s.scopeValue("formats", { key: c, ref: E, code: I });
          return typeof E == "object" && !(E instanceof RegExp) ? [E.type || "string", E.validate, (0, t._)`${R}.validate`] : ["string", E, R];
        }
        function p() {
          if (typeof y == "object" && !(y instanceof RegExp) && y.async) {
            if (!_.$async)
              throw new Error("async format in sync schema");
            return (0, t._)`await ${k}(${i})`;
          }
          return typeof w == "function" ? (0, t._)`${k}(${i})` : (0, t._)`${k}.test(${i})`;
        }
      }
    }
  };
  return Cn.default = r, Cn;
}
var ja;
function T_() {
  if (ja) return kn;
  ja = 1, Object.defineProperty(kn, "__esModule", { value: !0 });
  const e = [(/* @__PURE__ */ C_()).default];
  return kn.default = e, kn;
}
var xt = {}, xa;
function P_() {
  return xa || (xa = 1, Object.defineProperty(xt, "__esModule", { value: !0 }), xt.contentVocabulary = xt.metadataVocabulary = void 0, xt.metadataVocabulary = [
    "title",
    "description",
    "default",
    "deprecated",
    "readOnly",
    "writeOnly",
    "examples"
  ], xt.contentVocabulary = [
    "contentMediaType",
    "contentEncoding",
    "contentSchema"
  ]), xt;
}
var qa;
function A_() {
  if (qa) return Gr;
  qa = 1, Object.defineProperty(Gr, "__esModule", { value: !0 });
  const t = /* @__PURE__ */ Yg(), e = /* @__PURE__ */ d_(), r = /* @__PURE__ */ k_(), n = /* @__PURE__ */ T_(), o = /* @__PURE__ */ P_(), s = [
    t.default,
    e.default,
    (0, r.default)(),
    n.default,
    o.metadataVocabulary,
    o.contentVocabulary
  ];
  return Gr.default = s, Gr;
}
var Tn = {}, vr = {}, Da;
function R_() {
  if (Da) return vr;
  Da = 1, Object.defineProperty(vr, "__esModule", { value: !0 }), vr.DiscrError = void 0;
  var t;
  return function(e) {
    e.Tag = "tag", e.Mapping = "mapping";
  }(t || (vr.DiscrError = t = {})), vr;
}
var Ua;
function I_() {
  if (Ua) return Tn;
  Ua = 1, Object.defineProperty(Tn, "__esModule", { value: !0 });
  const t = /* @__PURE__ */ ie(), e = /* @__PURE__ */ R_(), r = /* @__PURE__ */ Zs(), n = /* @__PURE__ */ ao(), o = /* @__PURE__ */ de(), i = {
    keyword: "discriminator",
    type: "object",
    schemaType: "object",
    error: {
      message: ({ params: { discrError: a, tagName: c } }) => a === e.DiscrError.Tag ? `tag "${c}" must be string` : `value of tag "${c}" must be in oneOf`,
      params: ({ params: { discrError: a, tag: c, tagName: u } }) => (0, t._)`{error: ${a}, tag: ${u}, tagValue: ${c}}`
    },
    code(a) {
      const { gen: c, data: u, schema: l, parentSchema: h, it: m } = a, { oneOf: _ } = h;
      if (!m.opts.discriminator)
        throw new Error("discriminator: requires discriminator option");
      const S = l.propertyName;
      if (typeof S != "string")
        throw new Error("discriminator: requires propertyName");
      if (l.mapping)
        throw new Error("discriminator: mapping is not supported");
      if (!_)
        throw new Error("discriminator: requires oneOf keyword");
      const $ = c.let("valid", !1), v = c.const("tag", (0, t._)`${u}${(0, t.getProperty)(S)}`);
      c.if((0, t._)`typeof ${v} == "string"`, () => y(), () => a.error(!1, { discrError: e.DiscrError.Tag, tag: v, tagName: S })), a.ok($);
      function y() {
        const k = w();
        c.if(!1);
        for (const f in k)
          c.elseIf((0, t._)`${v} === ${f}`), c.assign($, g(k[f]));
        c.else(), a.error(!1, { discrError: e.DiscrError.Mapping, tag: v, tagName: S }), c.endIf();
      }
      function g(k) {
        const f = c.name("valid"), d = a.subschema({ keyword: "oneOf", schemaProp: k }, f);
        return a.mergeEvaluated(d, t.Name), f;
      }
      function w() {
        var k;
        const f = {}, d = E(h);
        let p = !0;
        for (let A = 0; A < _.length; A++) {
          let M = _[A];
          if (M != null && M.$ref && !(0, o.schemaHasRulesButRef)(M, m.self.RULES)) {
            const x = M.$ref;
            if (M = r.resolveRef.call(m.self, m.schemaEnv.root, m.baseId, x), M instanceof r.SchemaEnv && (M = M.schema), M === void 0)
              throw new n.default(m.opts.uriResolver, m.baseId, x);
          }
          const P = (k = M == null ? void 0 : M.properties) === null || k === void 0 ? void 0 : k[S];
          if (typeof P != "object")
            throw new Error(`discriminator: oneOf subschemas (or referenced schemas) must have "properties/${S}"`);
          p = p && (d || E(M)), I(P, A);
        }
        if (!p)
          throw new Error(`discriminator: "${S}" must be required`);
        return f;
        function E({ required: A }) {
          return Array.isArray(A) && A.includes(S);
        }
        function I(A, M) {
          if (A.const)
            R(A.const, M);
          else if (A.enum)
            for (const P of A.enum)
              R(P, M);
          else
            throw new Error(`discriminator: "properties/${S}" must have "const" or "enum"`);
        }
        function R(A, M) {
          if (typeof A != "string" || A in f)
            throw new Error(`discriminator: "${S}" values must be unique strings`);
          f[A] = M;
        }
      }
    }
  };
  return Tn.default = i, Tn;
}
const O_ = "http://json-schema.org/draft-07/schema#", z_ = "http://json-schema.org/draft-07/schema#", N_ = "Core schema meta-schema", M_ = { schemaArray: { type: "array", minItems: 1, items: { $ref: "#" } }, nonNegativeInteger: { type: "integer", minimum: 0 }, nonNegativeIntegerDefault0: { allOf: [{ $ref: "#/definitions/nonNegativeInteger" }, { default: 0 }] }, simpleTypes: { enum: ["array", "boolean", "integer", "null", "number", "object", "string"] }, stringArray: { type: "array", items: { type: "string" }, uniqueItems: !0, default: [] } }, j_ = ["object", "boolean"], x_ = { $id: { type: "string", format: "uri-reference" }, $schema: { type: "string", format: "uri" }, $ref: { type: "string", format: "uri-reference" }, $comment: { type: "string" }, title: { type: "string" }, description: { type: "string" }, default: !0, readOnly: { type: "boolean", default: !1 }, examples: { type: "array", items: !0 }, multipleOf: { type: "number", exclusiveMinimum: 0 }, maximum: { type: "number" }, exclusiveMaximum: { type: "number" }, minimum: { type: "number" }, exclusiveMinimum: { type: "number" }, maxLength: { $ref: "#/definitions/nonNegativeInteger" }, minLength: { $ref: "#/definitions/nonNegativeIntegerDefault0" }, pattern: { type: "string", format: "regex" }, additionalItems: { $ref: "#" }, items: { anyOf: [{ $ref: "#" }, { $ref: "#/definitions/schemaArray" }], default: !0 }, maxItems: { $ref: "#/definitions/nonNegativeInteger" }, minItems: { $ref: "#/definitions/nonNegativeIntegerDefault0" }, uniqueItems: { type: "boolean", default: !1 }, contains: { $ref: "#" }, maxProperties: { $ref: "#/definitions/nonNegativeInteger" }, minProperties: { $ref: "#/definitions/nonNegativeIntegerDefault0" }, required: { $ref: "#/definitions/stringArray" }, additionalProperties: { $ref: "#" }, definitions: { type: "object", additionalProperties: { $ref: "#" }, default: {} }, properties: { type: "object", additionalProperties: { $ref: "#" }, default: {} }, patternProperties: { type: "object", additionalProperties: { $ref: "#" }, propertyNames: { format: "regex" }, default: {} }, dependencies: { type: "object", additionalProperties: { anyOf: [{ $ref: "#" }, { $ref: "#/definitions/stringArray" }] } }, propertyNames: { $ref: "#" }, const: !0, enum: { type: "array", items: !0, minItems: 1, uniqueItems: !0 }, type: { anyOf: [{ $ref: "#/definitions/simpleTypes" }, { type: "array", items: { $ref: "#/definitions/simpleTypes" }, minItems: 1, uniqueItems: !0 }] }, format: { type: "string" }, contentMediaType: { type: "string" }, contentEncoding: { type: "string" }, if: { $ref: "#" }, then: { $ref: "#" }, else: { $ref: "#" }, allOf: { $ref: "#/definitions/schemaArray" }, anyOf: { $ref: "#/definitions/schemaArray" }, oneOf: { $ref: "#/definitions/schemaArray" }, not: { $ref: "#" } }, q_ = {
  $schema: O_,
  $id: z_,
  title: N_,
  definitions: M_,
  type: j_,
  properties: x_,
  default: !0
};
var Fa;
function Iu() {
  return Fa || (Fa = 1, function(t, e) {
    Object.defineProperty(e, "__esModule", { value: !0 }), e.MissingRefError = e.ValidationError = e.CodeGen = e.Name = e.nil = e.stringify = e.str = e._ = e.KeywordCxt = e.Ajv = void 0;
    const r = /* @__PURE__ */ Jg(), n = /* @__PURE__ */ A_(), o = /* @__PURE__ */ I_(), s = q_, i = ["/properties"], a = "http://json-schema.org/draft-07/schema";
    class c extends r.default {
      _addVocabularies() {
        super._addVocabularies(), n.default.forEach((S) => this.addVocabulary(S)), this.opts.discriminator && this.addKeyword(o.default);
      }
      _addDefaultMetaSchema() {
        if (super._addDefaultMetaSchema(), !this.opts.meta)
          return;
        const S = this.opts.$data ? this.$dataMetaSchema(s, i) : s;
        this.addMetaSchema(S, a, !1), this.refs["http://json-schema.org/schema"] = a;
      }
      defaultMeta() {
        return this.opts.defaultMeta = super.defaultMeta() || (this.getSchema(a) ? a : void 0);
      }
    }
    e.Ajv = c, t.exports = e = c, t.exports.Ajv = c, Object.defineProperty(e, "__esModule", { value: !0 }), e.default = c;
    var u = /* @__PURE__ */ io();
    Object.defineProperty(e, "KeywordCxt", { enumerable: !0, get: function() {
      return u.KeywordCxt;
    } });
    var l = /* @__PURE__ */ ie();
    Object.defineProperty(e, "_", { enumerable: !0, get: function() {
      return l._;
    } }), Object.defineProperty(e, "str", { enumerable: !0, get: function() {
      return l.str;
    } }), Object.defineProperty(e, "stringify", { enumerable: !0, get: function() {
      return l.stringify;
    } }), Object.defineProperty(e, "nil", { enumerable: !0, get: function() {
      return l.nil;
    } }), Object.defineProperty(e, "Name", { enumerable: !0, get: function() {
      return l.Name;
    } }), Object.defineProperty(e, "CodeGen", { enumerable: !0, get: function() {
      return l.CodeGen;
    } });
    var h = /* @__PURE__ */ Ls();
    Object.defineProperty(e, "ValidationError", { enumerable: !0, get: function() {
      return h.default;
    } });
    var m = /* @__PURE__ */ ao();
    Object.defineProperty(e, "MissingRefError", { enumerable: !0, get: function() {
      return m.default;
    } });
  }(Zr, Zr.exports)), Zr.exports;
}
var D_ = /* @__PURE__ */ Iu();
const U_ = /* @__PURE__ */ fs(D_);
var Pn = { exports: {} }, To = {}, La;
function F_() {
  return La || (La = 1, function(t) {
    Object.defineProperty(t, "__esModule", { value: !0 }), t.formatNames = t.fastFormats = t.fullFormats = void 0;
    function e(A, M) {
      return { validate: A, compare: M };
    }
    t.fullFormats = {
      // date: http://tools.ietf.org/html/rfc3339#section-5.6
      date: e(s, i),
      // date-time: http://tools.ietf.org/html/rfc3339#section-5.6
      time: e(c(!0), u),
      "date-time": e(m(!0), _),
      "iso-time": e(c(), l),
      "iso-date-time": e(m(), S),
      // duration: https://tools.ietf.org/html/rfc3339#appendix-A
      duration: /^P(?!$)((\d+Y)?(\d+M)?(\d+D)?(T(?=\d)(\d+H)?(\d+M)?(\d+S)?)?|(\d+W)?)$/,
      uri: y,
      "uri-reference": /^(?:[a-z][a-z0-9+\-.]*:)?(?:\/?\/(?:(?:[a-z0-9\-._~!$&'()*+,;=:]|%[0-9a-f]{2})*@)?(?:\[(?:(?:(?:(?:[0-9a-f]{1,4}:){6}|::(?:[0-9a-f]{1,4}:){5}|(?:[0-9a-f]{1,4})?::(?:[0-9a-f]{1,4}:){4}|(?:(?:[0-9a-f]{1,4}:){0,1}[0-9a-f]{1,4})?::(?:[0-9a-f]{1,4}:){3}|(?:(?:[0-9a-f]{1,4}:){0,2}[0-9a-f]{1,4})?::(?:[0-9a-f]{1,4}:){2}|(?:(?:[0-9a-f]{1,4}:){0,3}[0-9a-f]{1,4})?::[0-9a-f]{1,4}:|(?:(?:[0-9a-f]{1,4}:){0,4}[0-9a-f]{1,4})?::)(?:[0-9a-f]{1,4}:[0-9a-f]{1,4}|(?:(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\.){3}(?:25[0-5]|2[0-4]\d|[01]?\d\d?))|(?:(?:[0-9a-f]{1,4}:){0,5}[0-9a-f]{1,4})?::[0-9a-f]{1,4}|(?:(?:[0-9a-f]{1,4}:){0,6}[0-9a-f]{1,4})?::)|[Vv][0-9a-f]+\.[a-z0-9\-._~!$&'()*+,;=:]+)\]|(?:(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\.){3}(?:25[0-5]|2[0-4]\d|[01]?\d\d?)|(?:[a-z0-9\-._~!$&'"()*+,;=]|%[0-9a-f]{2})*)(?::\d*)?(?:\/(?:[a-z0-9\-._~!$&'"()*+,;=:@]|%[0-9a-f]{2})*)*|\/(?:(?:[a-z0-9\-._~!$&'"()*+,;=:@]|%[0-9a-f]{2})+(?:\/(?:[a-z0-9\-._~!$&'"()*+,;=:@]|%[0-9a-f]{2})*)*)?|(?:[a-z0-9\-._~!$&'"()*+,;=:@]|%[0-9a-f]{2})+(?:\/(?:[a-z0-9\-._~!$&'"()*+,;=:@]|%[0-9a-f]{2})*)*)?(?:\?(?:[a-z0-9\-._~!$&'"()*+,;=:@/?]|%[0-9a-f]{2})*)?(?:#(?:[a-z0-9\-._~!$&'"()*+,;=:@/?]|%[0-9a-f]{2})*)?$/i,
      // uri-template: https://tools.ietf.org/html/rfc6570
      "uri-template": /^(?:(?:[^\x00-\x20"'<>%\\^`{|}]|%[0-9a-f]{2})|\{[+#./;?&=,!@|]?(?:[a-z0-9_]|%[0-9a-f]{2})+(?::[1-9][0-9]{0,3}|\*)?(?:,(?:[a-z0-9_]|%[0-9a-f]{2})+(?::[1-9][0-9]{0,3}|\*)?)*\})*$/i,
      // For the source: https://gist.github.com/dperini/729294
      // For test cases: https://mathiasbynens.be/demo/url-regex
      url: /^(?:https?|ftp):\/\/(?:\S+(?::\S*)?@)?(?:(?!(?:10|127)(?:\.\d{1,3}){3})(?!(?:169\.254|192\.168)(?:\.\d{1,3}){2})(?!172\.(?:1[6-9]|2\d|3[0-1])(?:\.\d{1,3}){2})(?:[1-9]\d?|1\d\d|2[01]\d|22[0-3])(?:\.(?:1?\d{1,2}|2[0-4]\d|25[0-5])){2}(?:\.(?:[1-9]\d?|1\d\d|2[0-4]\d|25[0-4]))|(?:(?:[a-z0-9\u{00a1}-\u{ffff}]+-)*[a-z0-9\u{00a1}-\u{ffff}]+)(?:\.(?:[a-z0-9\u{00a1}-\u{ffff}]+-)*[a-z0-9\u{00a1}-\u{ffff}]+)*(?:\.(?:[a-z\u{00a1}-\u{ffff}]{2,})))(?::\d{2,5})?(?:\/[^\s]*)?$/iu,
      email: /^[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?$/i,
      hostname: /^(?=.{1,253}\.?$)[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?(?:\.[a-z0-9](?:[-0-9a-z]{0,61}[0-9a-z])?)*\.?$/i,
      // optimized https://www.safaribooksonline.com/library/view/regular-expressions-cookbook/9780596802837/ch07s16.html
      ipv4: /^(?:(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)\.){3}(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)$/,
      ipv6: /^((([0-9a-f]{1,4}:){7}([0-9a-f]{1,4}|:))|(([0-9a-f]{1,4}:){6}(:[0-9a-f]{1,4}|((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3})|:))|(([0-9a-f]{1,4}:){5}(((:[0-9a-f]{1,4}){1,2})|:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3})|:))|(([0-9a-f]{1,4}:){4}(((:[0-9a-f]{1,4}){1,3})|((:[0-9a-f]{1,4})?:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:))|(([0-9a-f]{1,4}:){3}(((:[0-9a-f]{1,4}){1,4})|((:[0-9a-f]{1,4}){0,2}:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:))|(([0-9a-f]{1,4}:){2}(((:[0-9a-f]{1,4}){1,5})|((:[0-9a-f]{1,4}){0,3}:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:))|(([0-9a-f]{1,4}:){1}(((:[0-9a-f]{1,4}){1,6})|((:[0-9a-f]{1,4}){0,4}:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:))|(:(((:[0-9a-f]{1,4}){1,7})|((:[0-9a-f]{1,4}){0,5}:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:)))$/i,
      regex: R,
      // uuid: http://tools.ietf.org/html/rfc4122
      uuid: /^(?:urn:uuid:)?[0-9a-f]{8}-(?:[0-9a-f]{4}-){3}[0-9a-f]{12}$/i,
      // JSON-pointer: https://tools.ietf.org/html/rfc6901
      // uri fragment: https://tools.ietf.org/html/rfc3986#appendix-A
      "json-pointer": /^(?:\/(?:[^~/]|~0|~1)*)*$/,
      "json-pointer-uri-fragment": /^#(?:\/(?:[a-z0-9_\-.!$&'()*+,;:=@]|%[0-9a-f]{2}|~0|~1)*)*$/i,
      // relative JSON-pointer: http://tools.ietf.org/html/draft-luff-relative-json-pointer-00
      "relative-json-pointer": /^(?:0|[1-9][0-9]*)(?:#|(?:\/(?:[^~/]|~0|~1)*)*)$/,
      // the following formats are used by the openapi specification: https://spec.openapis.org/oas/v3.0.0#data-types
      // byte: https://github.com/miguelmota/is-base64
      byte: w,
      // signed 32 bit integer
      int32: { type: "number", validate: d },
      // signed 64 bit integer
      int64: { type: "number", validate: p },
      // C-type float
      float: { type: "number", validate: E },
      // C-type double
      double: { type: "number", validate: E },
      // hint to the UI to hide input strings
      password: !0,
      // unchecked string payload
      binary: !0
    }, t.fastFormats = {
      ...t.fullFormats,
      date: e(/^\d\d\d\d-[0-1]\d-[0-3]\d$/, i),
      time: e(/^(?:[0-2]\d:[0-5]\d:[0-5]\d|23:59:60)(?:\.\d+)?(?:z|[+-]\d\d(?::?\d\d)?)$/i, u),
      "date-time": e(/^\d\d\d\d-[0-1]\d-[0-3]\dt(?:[0-2]\d:[0-5]\d:[0-5]\d|23:59:60)(?:\.\d+)?(?:z|[+-]\d\d(?::?\d\d)?)$/i, _),
      "iso-time": e(/^(?:[0-2]\d:[0-5]\d:[0-5]\d|23:59:60)(?:\.\d+)?(?:z|[+-]\d\d(?::?\d\d)?)?$/i, l),
      "iso-date-time": e(/^\d\d\d\d-[0-1]\d-[0-3]\d[t\s](?:[0-2]\d:[0-5]\d:[0-5]\d|23:59:60)(?:\.\d+)?(?:z|[+-]\d\d(?::?\d\d)?)?$/i, S),
      // uri: https://github.com/mafintosh/is-my-json-valid/blob/master/formats.js
      uri: /^(?:[a-z][a-z0-9+\-.]*:)(?:\/?\/)?[^\s]*$/i,
      "uri-reference": /^(?:(?:[a-z][a-z0-9+\-.]*:)?\/?\/)?(?:[^\\\s#][^\s#]*)?(?:#[^\\\s]*)?$/i,
      // email (sources from jsen validator):
      // http://stackoverflow.com/questions/201323/using-a-regular-expression-to-validate-an-email-address#answer-8829363
      // http://www.w3.org/TR/html5/forms.html#valid-e-mail-address (search for 'wilful violation')
      email: /^[a-z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?(?:\.[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?)*$/i
    }, t.formatNames = Object.keys(t.fullFormats);
    function r(A) {
      return A % 4 === 0 && (A % 100 !== 0 || A % 400 === 0);
    }
    const n = /^(\d\d\d\d)-(\d\d)-(\d\d)$/, o = [0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
    function s(A) {
      const M = n.exec(A);
      if (!M)
        return !1;
      const P = +M[1], x = +M[2], G = +M[3];
      return x >= 1 && x <= 12 && G >= 1 && G <= (x === 2 && r(P) ? 29 : o[x]);
    }
    function i(A, M) {
      if (A && M)
        return A > M ? 1 : A < M ? -1 : 0;
    }
    const a = /^(\d\d):(\d\d):(\d\d(?:\.\d+)?)(z|([+-])(\d\d)(?::?(\d\d))?)?$/i;
    function c(A) {
      return function(P) {
        const x = a.exec(P);
        if (!x)
          return !1;
        const G = +x[1], fe = +x[2], ue = +x[3], ee = x[4], Pe = x[5] === "-" ? -1 : 1, L = +(x[6] || 0), z = +(x[7] || 0);
        if (L > 23 || z > 59 || A && !ee)
          return !1;
        if (G <= 23 && fe <= 59 && ue < 60)
          return !0;
        const U = fe - z * Pe, j = G - L * Pe - (U < 0 ? 1 : 0);
        return (j === 23 || j === -1) && (U === 59 || U === -1) && ue < 61;
      };
    }
    function u(A, M) {
      if (!(A && M))
        return;
      const P = (/* @__PURE__ */ new Date("2020-01-01T" + A)).valueOf(), x = (/* @__PURE__ */ new Date("2020-01-01T" + M)).valueOf();
      if (P && x)
        return P - x;
    }
    function l(A, M) {
      if (!(A && M))
        return;
      const P = a.exec(A), x = a.exec(M);
      if (P && x)
        return A = P[1] + P[2] + P[3], M = x[1] + x[2] + x[3], A > M ? 1 : A < M ? -1 : 0;
    }
    const h = /t|\s/i;
    function m(A) {
      const M = c(A);
      return function(x) {
        const G = x.split(h);
        return G.length === 2 && s(G[0]) && M(G[1]);
      };
    }
    function _(A, M) {
      if (!(A && M))
        return;
      const P = new Date(A).valueOf(), x = new Date(M).valueOf();
      if (P && x)
        return P - x;
    }
    function S(A, M) {
      if (!(A && M))
        return;
      const [P, x] = A.split(h), [G, fe] = M.split(h), ue = i(P, G);
      if (ue !== void 0)
        return ue || u(x, fe);
    }
    const $ = /\/|:/, v = /^(?:[a-z][a-z0-9+\-.]*:)(?:\/?\/(?:(?:[a-z0-9\-._~!$&'()*+,;=:]|%[0-9a-f]{2})*@)?(?:\[(?:(?:(?:(?:[0-9a-f]{1,4}:){6}|::(?:[0-9a-f]{1,4}:){5}|(?:[0-9a-f]{1,4})?::(?:[0-9a-f]{1,4}:){4}|(?:(?:[0-9a-f]{1,4}:){0,1}[0-9a-f]{1,4})?::(?:[0-9a-f]{1,4}:){3}|(?:(?:[0-9a-f]{1,4}:){0,2}[0-9a-f]{1,4})?::(?:[0-9a-f]{1,4}:){2}|(?:(?:[0-9a-f]{1,4}:){0,3}[0-9a-f]{1,4})?::[0-9a-f]{1,4}:|(?:(?:[0-9a-f]{1,4}:){0,4}[0-9a-f]{1,4})?::)(?:[0-9a-f]{1,4}:[0-9a-f]{1,4}|(?:(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\.){3}(?:25[0-5]|2[0-4]\d|[01]?\d\d?))|(?:(?:[0-9a-f]{1,4}:){0,5}[0-9a-f]{1,4})?::[0-9a-f]{1,4}|(?:(?:[0-9a-f]{1,4}:){0,6}[0-9a-f]{1,4})?::)|[Vv][0-9a-f]+\.[a-z0-9\-._~!$&'()*+,;=:]+)\]|(?:(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\.){3}(?:25[0-5]|2[0-4]\d|[01]?\d\d?)|(?:[a-z0-9\-._~!$&'()*+,;=]|%[0-9a-f]{2})*)(?::\d*)?(?:\/(?:[a-z0-9\-._~!$&'()*+,;=:@]|%[0-9a-f]{2})*)*|\/(?:(?:[a-z0-9\-._~!$&'()*+,;=:@]|%[0-9a-f]{2})+(?:\/(?:[a-z0-9\-._~!$&'()*+,;=:@]|%[0-9a-f]{2})*)*)?|(?:[a-z0-9\-._~!$&'()*+,;=:@]|%[0-9a-f]{2})+(?:\/(?:[a-z0-9\-._~!$&'()*+,;=:@]|%[0-9a-f]{2})*)*)(?:\?(?:[a-z0-9\-._~!$&'()*+,;=:@/?]|%[0-9a-f]{2})*)?(?:#(?:[a-z0-9\-._~!$&'()*+,;=:@/?]|%[0-9a-f]{2})*)?$/i;
    function y(A) {
      return $.test(A) && v.test(A);
    }
    const g = /^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/gm;
    function w(A) {
      return g.lastIndex = 0, g.test(A);
    }
    const k = -2147483648, f = 2 ** 31 - 1;
    function d(A) {
      return Number.isInteger(A) && A <= f && A >= k;
    }
    function p(A) {
      return Number.isInteger(A);
    }
    function E() {
      return !0;
    }
    const I = /[^\\]\\Z/;
    function R(A) {
      if (I.test(A))
        return !1;
      try {
        return new RegExp(A), !0;
      } catch {
        return !1;
      }
    }
  }(To)), To;
}
var Po = {}, Za;
function L_() {
  return Za || (Za = 1, function(t) {
    Object.defineProperty(t, "__esModule", { value: !0 }), t.formatLimitDefinition = void 0;
    const e = /* @__PURE__ */ Iu(), r = /* @__PURE__ */ ie(), n = r.operators, o = {
      formatMaximum: { okStr: "<=", ok: n.LTE, fail: n.GT },
      formatMinimum: { okStr: ">=", ok: n.GTE, fail: n.LT },
      formatExclusiveMaximum: { okStr: "<", ok: n.LT, fail: n.GTE },
      formatExclusiveMinimum: { okStr: ">", ok: n.GT, fail: n.LTE }
    }, s = {
      message: ({ keyword: a, schemaCode: c }) => (0, r.str)`should be ${o[a].okStr} ${c}`,
      params: ({ keyword: a, schemaCode: c }) => (0, r._)`{comparison: ${o[a].okStr}, limit: ${c}}`
    };
    t.formatLimitDefinition = {
      keyword: Object.keys(o),
      type: "string",
      schemaType: "string",
      $data: !0,
      error: s,
      code(a) {
        const { gen: c, data: u, schemaCode: l, keyword: h, it: m } = a, { opts: _, self: S } = m;
        if (!_.validateFormats)
          return;
        const $ = new e.KeywordCxt(m, S.RULES.all.format.definition, "format");
        $.$data ? v() : y();
        function v() {
          const w = c.scopeValue("formats", {
            ref: S.formats,
            code: _.code.formats
          }), k = c.const("fmt", (0, r._)`${w}[${$.schemaCode}]`);
          a.fail$data((0, r.or)((0, r._)`typeof ${k} != "object"`, (0, r._)`${k} instanceof RegExp`, (0, r._)`typeof ${k}.compare != "function"`, g(k)));
        }
        function y() {
          const w = $.schema, k = S.formats[w];
          if (!k || k === !0)
            return;
          if (typeof k != "object" || k instanceof RegExp || typeof k.compare != "function")
            throw new Error(`"${h}": format "${w}" does not define "compare" function`);
          const f = c.scopeValue("formats", {
            key: w,
            ref: k,
            code: _.code.formats ? (0, r._)`${_.code.formats}${(0, r.getProperty)(w)}` : void 0
          });
          a.fail$data(g(f));
        }
        function g(w) {
          return (0, r._)`${w}.compare(${u}, ${l}) ${o[h].fail} 0`;
        }
      },
      dependencies: ["format"]
    };
    const i = (a) => (a.addKeyword(t.formatLimitDefinition), a);
    t.default = i;
  }(Po)), Po;
}
var Va;
function Z_() {
  return Va || (Va = 1, function(t, e) {
    Object.defineProperty(e, "__esModule", { value: !0 });
    const r = F_(), n = L_(), o = /* @__PURE__ */ ie(), s = new o.Name("fullFormats"), i = new o.Name("fastFormats"), a = (u, l = { keywords: !0 }) => {
      if (Array.isArray(l))
        return c(u, l, r.fullFormats, s), u;
      const [h, m] = l.mode === "fast" ? [r.fastFormats, i] : [r.fullFormats, s], _ = l.formats || r.formatNames;
      return c(u, _, h, m), l.keywords && (0, n.default)(u), u;
    };
    a.get = (u, l = "full") => {
      const m = (l === "fast" ? r.fastFormats : r.fullFormats)[u];
      if (!m)
        throw new Error(`Unknown format "${u}"`);
      return m;
    };
    function c(u, l, h, m) {
      var _, S;
      (_ = (S = u.opts.code).formats) !== null && _ !== void 0 || (S.formats = (0, o._)`require("ajv-formats/dist/formats").${m}`);
      for (const $ of l)
        u.addFormat($, h[$]);
    }
    t.exports = e = a, Object.defineProperty(e, "__esModule", { value: !0 }), e.default = a;
  }(Pn, Pn.exports)), Pn.exports;
}
var V_ = Z_();
const H_ = /* @__PURE__ */ fs(V_);
function W_() {
  const t = new U_({
    strict: !1,
    validateFormats: !0,
    validateSchema: !1,
    allErrors: !0
  });
  return H_(t), t;
}
class B_ {
  /**
   * Create an AJV validator
   *
   * @param ajv - Optional pre-configured AJV instance. If not provided, a default instance will be created.
   *
   * @example
   * ```typescript
   * // Use default configuration (recommended for most cases)
   * import { AjvJsonSchemaValidator } from '@modelcontextprotocol/sdk/validation/ajv';
   * const validator = new AjvJsonSchemaValidator();
   *
   * // Or provide custom AJV instance for advanced configuration
   * import { Ajv } from 'ajv';
   * import addFormats from 'ajv-formats';
   *
   * const ajv = new Ajv({ validateFormats: true });
   * addFormats(ajv);
   * const validator = new AjvJsonSchemaValidator(ajv);
   * ```
   */
  constructor(e) {
    this._ajv = e ?? W_();
  }
  /**
   * Create a validator for the given JSON Schema
   *
   * The validator is compiled once and can be reused multiple times.
   * If the schema has an $id, it will be cached by AJV automatically.
   *
   * @param schema - Standard JSON Schema object
   * @returns A validator function that validates input data
   */
  getValidator(e) {
    const r = "$id" in e && typeof e.$id == "string" ? this._ajv.getSchema(e.$id) ?? this._ajv.compile(e) : this._ajv.compile(e);
    return (n) => r(n) ? {
      valid: !0,
      data: n,
      errorMessage: void 0
    } : {
      valid: !1,
      data: void 0,
      errorMessage: this._ajv.errorsText(r.errors)
    };
  }
}
class G_ {
  constructor(e) {
    this._client = e;
  }
  /**
   * Calls a tool and returns an AsyncGenerator that yields response messages.
   * The generator is guaranteed to end with either a 'result' or 'error' message.
   *
   * This method provides streaming access to tool execution, allowing you to
   * observe intermediate task status updates for long-running tool calls.
   * Automatically validates structured output if the tool has an outputSchema.
   *
   * @example
   * ```typescript
   * const stream = client.experimental.tasks.callToolStream({ name: 'myTool', arguments: {} });
   * for await (const message of stream) {
   *   switch (message.type) {
   *     case 'taskCreated':
   *       console.log('Tool execution started:', message.task.taskId);
   *       break;
   *     case 'taskStatus':
   *       console.log('Tool status:', message.task.status);
   *       break;
   *     case 'result':
   *       console.log('Tool result:', message.result);
   *       break;
   *     case 'error':
   *       console.error('Tool error:', message.error);
   *       break;
   *   }
   * }
   * ```
   *
   * @param params - Tool call parameters (name and arguments)
   * @param resultSchema - Zod schema for validating the result (defaults to CallToolResultSchema)
   * @param options - Optional request options (timeout, signal, task creation params, etc.)
   * @returns AsyncGenerator that yields ResponseMessage objects
   *
   * @experimental
   */
  async *callToolStream(e, r = no, n) {
    const o = this._client, s = {
      ...n,
      // We check if the tool is known to be a task during auto-configuration, but assume
      // the caller knows what they're doing if they pass this explicitly
      task: (n == null ? void 0 : n.task) ?? (o.isToolTask(e.name) ? {} : void 0)
    }, i = o.requestStream({ method: "tools/call", params: e }, r, s), a = o.getToolOutputValidator(e.name);
    for await (const c of i) {
      if (c.type === "result" && a) {
        const u = c.result;
        if (!u.structuredContent && !u.isError) {
          yield {
            type: "error",
            error: new te(oe.InvalidRequest, `Tool ${e.name} has an output schema but did not return structured content`)
          };
          return;
        }
        if (u.structuredContent)
          try {
            const l = a(u.structuredContent);
            if (!l.valid) {
              yield {
                type: "error",
                error: new te(oe.InvalidParams, `Structured content does not match the tool's output schema: ${l.errorMessage}`)
              };
              return;
            }
          } catch (l) {
            if (l instanceof te) {
              yield { type: "error", error: l };
              return;
            }
            yield {
              type: "error",
              error: new te(oe.InvalidParams, `Failed to validate structured content: ${l instanceof Error ? l.message : String(l)}`)
            };
            return;
          }
      }
      yield c;
    }
  }
  /**
   * Gets the current status of a task.
   *
   * @param taskId - The task identifier
   * @param options - Optional request options
   * @returns The task status
   *
   * @experimental
   */
  async getTask(e, r) {
    return this._client.getTask({ taskId: e }, r);
  }
  /**
   * Retrieves the result of a completed task.
   *
   * @param taskId - The task identifier
   * @param resultSchema - Zod schema for validating the result
   * @param options - Optional request options
   * @returns The task result
   *
   * @experimental
   */
  async getTaskResult(e, r, n) {
    return this._client.getTaskResult({ taskId: e }, r, n);
  }
  /**
   * Lists tasks with optional pagination.
   *
   * @param cursor - Optional pagination cursor
   * @param options - Optional request options
   * @returns List of tasks with optional next cursor
   *
   * @experimental
   */
  async listTasks(e, r) {
    return this._client.listTasks(e ? { cursor: e } : void 0, r);
  }
  /**
   * Cancels a running task.
   *
   * @param taskId - The task identifier
   * @param options - Optional request options
   *
   * @experimental
   */
  async cancelTask(e, r) {
    return this._client.cancelTask({ taskId: e }, r);
  }
  /**
   * Sends a request and returns an AsyncGenerator that yields response messages.
   * The generator is guaranteed to end with either a 'result' or 'error' message.
   *
   * This method provides streaming access to request processing, allowing you to
   * observe intermediate task status updates for task-augmented requests.
   *
   * @param request - The request to send
   * @param resultSchema - Zod schema for validating the result
   * @param options - Optional request options (timeout, signal, task creation params, etc.)
   * @returns AsyncGenerator that yields ResponseMessage objects
   *
   * @experimental
   */
  requestStream(e, r, n) {
    return this._client.requestStream(e, r, n);
  }
}
function K_(t, e, r) {
  var n;
  if (!t)
    throw new Error(`${r} does not support task creation (required for ${e})`);
  switch (e) {
    case "tools/call":
      if (!((n = t.tools) != null && n.call))
        throw new Error(`${r} does not support task creation for tools/call (required for ${e})`);
      break;
  }
}
function J_(t, e, r) {
  var n, o;
  if (!t)
    throw new Error(`${r} does not support task creation (required for ${e})`);
  switch (e) {
    case "sampling/createMessage":
      if (!((n = t.sampling) != null && n.createMessage))
        throw new Error(`${r} does not support task creation for sampling/createMessage (required for ${e})`);
      break;
    case "elicitation/create":
      if (!((o = t.elicitation) != null && o.create))
        throw new Error(`${r} does not support task creation for elicitation/create (required for ${e})`);
      break;
  }
}
function On(t, e) {
  if (!(!t || e === null || typeof e != "object")) {
    if (t.type === "object" && t.properties && typeof t.properties == "object") {
      const r = e, n = t.properties;
      for (const o of Object.keys(n)) {
        const s = n[o];
        r[o] === void 0 && Object.prototype.hasOwnProperty.call(s, "default") && (r[o] = s.default), r[o] !== void 0 && On(s, r[o]);
      }
    }
    if (Array.isArray(t.anyOf))
      for (const r of t.anyOf)
        typeof r != "boolean" && On(r, e);
    if (Array.isArray(t.oneOf))
      for (const r of t.oneOf)
        typeof r != "boolean" && On(r, e);
  }
}
function Q_(t) {
  if (!t)
    return { supportsFormMode: !1, supportsUrlMode: !1 };
  const e = t.form !== void 0, r = t.url !== void 0;
  return { supportsFormMode: e || !e && !r, supportsUrlMode: r };
}
class X_ extends zg {
  /**
   * Initializes this client with the given name and version information.
   */
  constructor(e, r) {
    super(r), this._clientInfo = e, this._cachedToolOutputValidators = /* @__PURE__ */ new Map(), this._cachedKnownTaskTools = /* @__PURE__ */ new Set(), this._cachedRequiredTaskTools = /* @__PURE__ */ new Set(), this._listChangedDebounceTimers = /* @__PURE__ */ new Map(), this._capabilities = (r == null ? void 0 : r.capabilities) ?? {}, this._jsonSchemaValidator = (r == null ? void 0 : r.jsonSchemaValidator) ?? new B_(), r != null && r.listChanged && (this._pendingListChangedConfig = r.listChanged);
  }
  /**
   * Set up handlers for list changed notifications based on config and server capabilities.
   * This should only be called after initialization when server capabilities are known.
   * Handlers are silently skipped if the server doesn't advertise the corresponding listChanged capability.
   * @internal
   */
  _setupListChangedHandlers(e) {
    var r, n, o, s, i, a;
    e.tools && ((n = (r = this._serverCapabilities) == null ? void 0 : r.tools) != null && n.listChanged) && this._setupListChangedHandler("tools", mu, e.tools, async () => (await this.listTools()).tools), e.prompts && ((s = (o = this._serverCapabilities) == null ? void 0 : o.prompts) != null && s.listChanged) && this._setupListChangedHandler("prompts", fu, e.prompts, async () => (await this.listPrompts()).prompts), e.resources && ((a = (i = this._serverCapabilities) == null ? void 0 : i.resources) != null && a.listChanged) && this._setupListChangedHandler("resources", uu, e.resources, async () => (await this.listResources()).resources);
  }
  /**
   * Access experimental features.
   *
   * WARNING: These APIs are experimental and may change without notice.
   *
   * @experimental
   */
  get experimental() {
    return this._experimental || (this._experimental = {
      tasks: new G_(this)
    }), this._experimental;
  }
  /**
   * Registers new capabilities. This can only be called before connecting to a transport.
   *
   * The new capabilities will be merged with any existing capabilities previously given (e.g., at initialization).
   */
  registerCapabilities(e) {
    if (this.transport)
      throw new Error("Cannot register capabilities after connecting to transport");
    this._capabilities = Ng(this._capabilities, e);
  }
  /**
   * Override request handler registration to enforce client-side validation for elicitation.
   */
  setRequestHandler(e, r) {
    const n = Mc(e), o = n == null ? void 0 : n.method;
    if (!o)
      throw new Error("Schema is missing a method literal");
    const s = jc(o);
    if (typeof s != "string")
      throw new Error("Schema method literal must be a string");
    const i = s;
    if (i === "elicitation/create") {
      const a = async (c, u) => {
        var g, w;
        const l = Pt(bu, c);
        if (!l.success) {
          const k = l.error instanceof Error ? l.error.message : String(l.error);
          throw new te(oe.InvalidParams, `Invalid elicitation request: ${k}`);
        }
        const { params: h } = l.data;
        h.mode = h.mode ?? "form";
        const { supportsFormMode: m, supportsUrlMode: _ } = Q_(this._capabilities.elicitation);
        if (h.mode === "form" && !m)
          throw new te(oe.InvalidParams, "Client does not support form-mode elicitation requests");
        if (h.mode === "url" && !_)
          throw new te(oe.InvalidParams, "Client does not support URL-mode elicitation requests");
        const S = await Promise.resolve(r(c, u));
        if (h.task) {
          const k = Pt(Rr, S);
          if (!k.success) {
            const f = k.error instanceof Error ? k.error.message : String(k.error);
            throw new te(oe.InvalidParams, `Invalid task creation result: ${f}`);
          }
          return k.data;
        }
        const $ = Pt($u, S);
        if (!$.success) {
          const k = $.error instanceof Error ? $.error.message : String($.error);
          throw new te(oe.InvalidParams, `Invalid elicitation result: ${k}`);
        }
        const v = $.data, y = h.mode === "form" ? h.requestedSchema : void 0;
        if (h.mode === "form" && v.action === "accept" && v.content && y && (w = (g = this._capabilities.elicitation) == null ? void 0 : g.form) != null && w.applyDefaults)
          try {
            On(y, v.content);
          } catch {
          }
        return v;
      };
      return super.setRequestHandler(e, a);
    }
    if (i === "sampling/createMessage") {
      const a = async (c, u) => {
        const l = Pt(yu, c);
        if (!l.success) {
          const v = l.error instanceof Error ? l.error.message : String(l.error);
          throw new te(oe.InvalidParams, `Invalid sampling request: ${v}`);
        }
        const { params: h } = l.data, m = await Promise.resolve(r(c, u));
        if (h.task) {
          const v = Pt(Rr, m);
          if (!v.success) {
            const y = v.error instanceof Error ? v.error.message : String(v.error);
            throw new te(oe.InvalidParams, `Invalid task creation result: ${y}`);
          }
          return v.data;
        }
        const S = h.tools || h.toolChoice ? wu : vu, $ = Pt(S, m);
        if (!$.success) {
          const v = $.error instanceof Error ? $.error.message : String($.error);
          throw new te(oe.InvalidParams, `Invalid sampling result: ${v}`);
        }
        return $.data;
      };
      return super.setRequestHandler(e, a);
    }
    return super.setRequestHandler(e, r);
  }
  assertCapability(e, r) {
    var n;
    if (!((n = this._serverCapabilities) != null && n[e]))
      throw new Error(`Server does not support ${e} (required for ${r})`);
  }
  async connect(e, r) {
    if (await super.connect(e), e.sessionId === void 0)
      try {
        const n = await this.request({
          method: "initialize",
          params: {
            protocolVersion: eo,
            capabilities: this._capabilities,
            clientInfo: this._clientInfo
          }
        }, eu, r);
        if (n === void 0)
          throw new Error(`Server sent invalid initialize result: ${n}`);
        if (!tm.includes(n.protocolVersion))
          throw new Error(`Server's protocol version is not supported: ${n.protocolVersion}`);
        this._serverCapabilities = n.capabilities, this._serverVersion = n.serverInfo, e.setProtocolVersion && e.setProtocolVersion(n.protocolVersion), this._instructions = n.instructions, await this.notification({
          method: "notifications/initialized"
        }), this._pendingListChangedConfig && (this._setupListChangedHandlers(this._pendingListChangedConfig), this._pendingListChangedConfig = void 0);
      } catch (n) {
        throw this.close(), n;
      }
  }
  /**
   * After initialization has completed, this will be populated with the server's reported capabilities.
   */
  getServerCapabilities() {
    return this._serverCapabilities;
  }
  /**
   * After initialization has completed, this will be populated with information about the server's name and version.
   */
  getServerVersion() {
    return this._serverVersion;
  }
  /**
   * After initialization has completed, this may be populated with information about the server's instructions.
   */
  getInstructions() {
    return this._instructions;
  }
  assertCapabilityForMethod(e) {
    var r, n, o, s, i;
    switch (e) {
      case "logging/setLevel":
        if (!((r = this._serverCapabilities) != null && r.logging))
          throw new Error(`Server does not support logging (required for ${e})`);
        break;
      case "prompts/get":
      case "prompts/list":
        if (!((n = this._serverCapabilities) != null && n.prompts))
          throw new Error(`Server does not support prompts (required for ${e})`);
        break;
      case "resources/list":
      case "resources/templates/list":
      case "resources/read":
      case "resources/subscribe":
      case "resources/unsubscribe":
        if (!((o = this._serverCapabilities) != null && o.resources))
          throw new Error(`Server does not support resources (required for ${e})`);
        if (e === "resources/subscribe" && !this._serverCapabilities.resources.subscribe)
          throw new Error(`Server does not support resource subscriptions (required for ${e})`);
        break;
      case "tools/call":
      case "tools/list":
        if (!((s = this._serverCapabilities) != null && s.tools))
          throw new Error(`Server does not support tools (required for ${e})`);
        break;
      case "completion/complete":
        if (!((i = this._serverCapabilities) != null && i.completions))
          throw new Error(`Server does not support completions (required for ${e})`);
        break;
    }
  }
  assertNotificationCapability(e) {
    var r;
    switch (e) {
      case "notifications/roots/list_changed":
        if (!((r = this._capabilities.roots) != null && r.listChanged))
          throw new Error(`Client does not support roots list changed notifications (required for ${e})`);
        break;
    }
  }
  assertRequestHandlerCapability(e) {
    if (this._capabilities)
      switch (e) {
        case "sampling/createMessage":
          if (!this._capabilities.sampling)
            throw new Error(`Client does not support sampling capability (required for ${e})`);
          break;
        case "elicitation/create":
          if (!this._capabilities.elicitation)
            throw new Error(`Client does not support elicitation capability (required for ${e})`);
          break;
        case "roots/list":
          if (!this._capabilities.roots)
            throw new Error(`Client does not support roots capability (required for ${e})`);
          break;
        case "tasks/get":
        case "tasks/list":
        case "tasks/result":
        case "tasks/cancel":
          if (!this._capabilities.tasks)
            throw new Error(`Client does not support tasks capability (required for ${e})`);
          break;
      }
  }
  assertTaskCapability(e) {
    var r, n;
    K_((n = (r = this._serverCapabilities) == null ? void 0 : r.tasks) == null ? void 0 : n.requests, e, "Server");
  }
  assertTaskHandlerCapability(e) {
    var r;
    this._capabilities && J_((r = this._capabilities.tasks) == null ? void 0 : r.requests, e, "Client");
  }
  async ping(e) {
    return this.request({ method: "ping" }, or, e);
  }
  async complete(e, r) {
    return this.request({ method: "completion/complete", params: e }, Su, r);
  }
  async setLoggingLevel(e, r) {
    return this.request({ method: "logging/setLevel", params: { level: e } }, or, r);
  }
  async getPrompt(e, r) {
    return this.request({ method: "prompts/get", params: e }, du, r);
  }
  async listPrompts(e, r) {
    return this.request({ method: "prompts/list", params: e }, lu, r);
  }
  async listResources(e, r) {
    return this.request({ method: "resources/list", params: e }, iu, r);
  }
  async listResourceTemplates(e, r) {
    return this.request({ method: "resources/templates/list", params: e }, au, r);
  }
  async readResource(e, r) {
    return this.request({ method: "resources/read", params: e }, cu, r);
  }
  async subscribeResource(e, r) {
    return this.request({ method: "resources/subscribe", params: e }, or, r);
  }
  async unsubscribeResource(e, r) {
    return this.request({ method: "resources/unsubscribe", params: e }, or, r);
  }
  /**
   * Calls a tool and waits for the result. Automatically validates structured output if the tool has an outputSchema.
   *
   * For task-based execution with streaming behavior, use client.experimental.tasks.callToolStream() instead.
   */
  async callTool(e, r = no, n) {
    if (this.isToolTaskRequired(e.name))
      throw new te(oe.InvalidRequest, `Tool "${e.name}" requires task-based execution. Use client.experimental.tasks.callToolStream() instead.`);
    const o = await this.request({ method: "tools/call", params: e }, r, n), s = this.getToolOutputValidator(e.name);
    if (s) {
      if (!o.structuredContent && !o.isError)
        throw new te(oe.InvalidRequest, `Tool ${e.name} has an output schema but did not return structured content`);
      if (o.structuredContent)
        try {
          const i = s(o.structuredContent);
          if (!i.valid)
            throw new te(oe.InvalidParams, `Structured content does not match the tool's output schema: ${i.errorMessage}`);
        } catch (i) {
          throw i instanceof te ? i : new te(oe.InvalidParams, `Failed to validate structured content: ${i instanceof Error ? i.message : String(i)}`);
        }
    }
    return o;
  }
  isToolTask(e) {
    var r, n, o, s;
    return (s = (o = (n = (r = this._serverCapabilities) == null ? void 0 : r.tasks) == null ? void 0 : n.requests) == null ? void 0 : o.tools) != null && s.call ? this._cachedKnownTaskTools.has(e) : !1;
  }
  /**
   * Check if a tool requires task-based execution.
   * Unlike isToolTask which includes 'optional' tools, this only checks for 'required'.
   */
  isToolTaskRequired(e) {
    return this._cachedRequiredTaskTools.has(e);
  }
  /**
   * Cache validators for tool output schemas.
   * Called after listTools() to pre-compile validators for better performance.
   */
  cacheToolMetadata(e) {
    var r;
    this._cachedToolOutputValidators.clear(), this._cachedKnownTaskTools.clear(), this._cachedRequiredTaskTools.clear();
    for (const n of e) {
      if (n.outputSchema) {
        const s = this._jsonSchemaValidator.getValidator(n.outputSchema);
        this._cachedToolOutputValidators.set(n.name, s);
      }
      const o = (r = n.execution) == null ? void 0 : r.taskSupport;
      (o === "required" || o === "optional") && this._cachedKnownTaskTools.add(n.name), o === "required" && this._cachedRequiredTaskTools.add(n.name);
    }
  }
  /**
   * Get cached validator for a tool
   */
  getToolOutputValidator(e) {
    return this._cachedToolOutputValidators.get(e);
  }
  async listTools(e, r) {
    const n = await this.request({ method: "tools/list", params: e }, pu, r);
    return this.cacheToolMetadata(n.tools), n;
  }
  /**
   * Set up a single list changed handler.
   * @internal
   */
  _setupListChangedHandler(e, r, n, o) {
    const s = Km.safeParse(n);
    if (!s.success)
      throw new Error(`Invalid ${e} listChanged options: ${s.error.message}`);
    if (typeof n.onChanged != "function")
      throw new Error(`Invalid ${e} listChanged options: onChanged must be a function`);
    const { autoRefresh: i, debounceMs: a } = s.data, { onChanged: c } = n, u = async () => {
      if (!i) {
        c(null, null);
        return;
      }
      try {
        const h = await o();
        c(null, h);
      } catch (h) {
        const m = h instanceof Error ? h : new Error(String(h));
        c(m, null);
      }
    }, l = () => {
      if (a) {
        const h = this._listChangedDebounceTimers.get(e);
        h && clearTimeout(h);
        const m = setTimeout(u, a);
        this._listChangedDebounceTimers.set(e, m);
      } else
        u();
    };
    this.setNotificationHandler(r, l);
  }
  async sendRootsListChanged() {
    return this.notification({ method: "notifications/roots/list_changed" });
  }
}
const Ha = nt("EventEmitter");
class Ou {
  constructor() {
    B(this, "listeners", /* @__PURE__ */ new Map());
    B(this, "maxListeners", 100);
  }
  on(e, r) {
    this.listeners.has(e) || this.listeners.set(e, /* @__PURE__ */ new Set());
    const n = this.listeners.get(e);
    return n.size >= this.maxListeners && Ha.warn(`EventEmitter: Maximum listeners (${this.maxListeners}) exceeded for event '${String(e)}'`), n.add(r), this;
  }
  off(e, r) {
    const n = this.listeners.get(e);
    return n && (n.delete(r), n.size === 0 && this.listeners.delete(e)), this;
  }
  once(e, r) {
    const n = (o) => (this.off(e, n), r(o));
    return this.on(e, n);
  }
  emit(e, r) {
    const n = this.listeners.get(e);
    return !n || n.size === 0 ? !1 : (n.forEach(async (o) => {
      try {
        await o(r);
      } catch (s) {
        Ha.error(`EventEmitter: Error in listener for event '${String(e)}':`, s);
      }
    }), !0);
  }
  removeAllListeners(e) {
    return e !== void 0 ? this.listeners.delete(e) : this.listeners.clear(), this;
  }
  listenerCount(e) {
    var r;
    return ((r = this.listeners.get(e)) == null ? void 0 : r.size) ?? 0;
  }
  eventNames() {
    return Array.from(this.listeners.keys());
  }
  setMaxListeners(e) {
    return this.maxListeners = Math.max(0, e), this;
  }
  getMaxListeners() {
    return this.maxListeners;
  }
}
class Ao extends Error {
  constructor(e, r) {
    super(e), this.name = "ParseError", this.type = r.type, this.field = r.field, this.value = r.value, this.line = r.line;
  }
}
const Wa = 10, Y_ = 13, qt = 32;
function Ro(t) {
}
function zu(t) {
  if (typeof t == "function")
    throw new TypeError(
      "`config` must be an object, got a function instead. Did you mean `createParser({onEvent: fn})`?"
    );
  const { onEvent: e = Ro, onError: r = Ro, onRetry: n = Ro, onComment: o, maxBufferSize: s } = t, i = [];
  let a = 0, c = !0, u, l = "", h = 0, m, _ = !1;
  function S(f) {
    if (_)
      throw new Error(
        "Cannot feed parser: it was terminated after exceeding the configured max buffer size. Call `reset()` to resume parsing."
      );
    if (c && (c = !1, f.charCodeAt(0) === 239 && f.charCodeAt(1) === 187 && f.charCodeAt(2) === 191 && (f = f.slice(3))), i.length === 0) {
      const E = v(f);
      E !== "" && (i.push(E), a = E.length), $();
      return;
    }
    if (f.indexOf(`
`) === -1 && f.indexOf("\r") === -1) {
      i.push(f), a += f.length, $();
      return;
    }
    i.push(f);
    const d = i.join("");
    i.length = 0, a = 0;
    const p = v(d);
    p !== "" && (i.push(p), a = p.length), $();
  }
  function $() {
    s !== void 0 && (a + l.length <= s || (_ = !0, i.length = 0, a = 0, u = void 0, l = "", h = 0, m = void 0, r(
      new Ao(`Buffered data exceeded max buffer size of ${s} characters`, {
        type: "max-buffer-size-exceeded"
      })
    )));
  }
  function v(f) {
    let d = 0;
    if (f.indexOf("\r") === -1) {
      let p = f.indexOf(`
`, d);
      for (; p !== -1; ) {
        if (d === p) {
          h > 0 && e({ id: u, event: m, data: l }), u = void 0, l = "", h = 0, m = void 0, d = p + 1, p = f.indexOf(`
`, d);
          continue;
        }
        const E = f.charCodeAt(d);
        if (Ba(f, d, E)) {
          const I = f.charCodeAt(d + 5) === qt ? d + 6 : d + 5, R = f.slice(I, p);
          if (h === 0 && f.charCodeAt(p + 1) === Wa) {
            e({ id: u, event: m, data: R }), u = void 0, l = "", m = void 0, d = p + 2, p = f.indexOf(`
`, d);
            continue;
          }
          l = h === 0 ? R : `${l}
${R}`, h++;
        } else Ga(f, d, E) ? m = f.slice(
          f.charCodeAt(d + 6) === qt ? d + 7 : d + 6,
          p
        ) || void 0 : y(f, d, p);
        d = p + 1, p = f.indexOf(`
`, d);
      }
      return f.slice(d);
    }
    for (; d < f.length; ) {
      const p = f.indexOf("\r", d), E = f.indexOf(`
`, d);
      let I = -1;
      if (p !== -1 && E !== -1 ? I = p < E ? p : E : p !== -1 ? p === f.length - 1 ? I = -1 : I = p : E !== -1 && (I = E), I === -1)
        break;
      y(f, d, I), d = I + 1, f.charCodeAt(d - 1) === Y_ && f.charCodeAt(d) === Wa && d++;
    }
    return f.slice(d);
  }
  function y(f, d, p) {
    if (d === p) {
      w();
      return;
    }
    const E = f.charCodeAt(d);
    if (Ba(f, d, E)) {
      const x = f.charCodeAt(d + 5) === qt ? d + 6 : d + 5, G = f.slice(x, p);
      l = h === 0 ? G : `${l}
${G}`, h++;
      return;
    }
    if (Ga(f, d, E)) {
      m = f.slice(f.charCodeAt(d + 6) === qt ? d + 7 : d + 6, p) || void 0;
      return;
    }
    if (E === 105 && f.charCodeAt(d + 1) === 100 && f.charCodeAt(d + 2) === 58) {
      const x = f.slice(f.charCodeAt(d + 3) === qt ? d + 4 : d + 3, p);
      x.includes("\0") || (u = x);
      return;
    }
    if (E === 58) {
      if (o) {
        const x = f.slice(d, p);
        o(x.slice(f.charCodeAt(d + 1) === qt ? 2 : 1));
      }
      return;
    }
    const I = f.slice(d, p), R = I.indexOf(":");
    if (R === -1) {
      g(I, "", I);
      return;
    }
    const A = I.slice(0, R), M = I.charCodeAt(R + 1) === qt ? 2 : 1, P = I.slice(R + M);
    g(A, P, I);
  }
  function g(f, d, p) {
    switch (f) {
      case "event":
        m = d || void 0;
        break;
      case "data":
        l = h === 0 ? d : `${l}
${d}`, h++;
        break;
      case "id":
        d.includes("\0") || (u = d);
        break;
      case "retry":
        /^\d+$/.test(d) ? n(parseInt(d, 10)) : r(
          new Ao(`Invalid \`retry\` value: "${d}"`, {
            type: "invalid-retry",
            value: d,
            line: p
          })
        );
        break;
      default:
        r(
          new Ao(
            `Unknown field "${f.length > 20 ? `${f.slice(0, 20)}…` : f}"`,
            { type: "unknown-field", field: f, value: d, line: p }
          )
        );
        break;
    }
  }
  function w() {
    h > 0 && e({
      id: u,
      event: m,
      data: l
    }), u = void 0, l = "", h = 0, m = void 0;
  }
  function k(f = {}) {
    if (f.consume && i.length > 0) {
      const d = i.join("");
      y(d, 0, d.length);
    }
    c = !0, u = void 0, l = "", h = 0, m = void 0, i.length = 0, a = 0, _ = !1;
  }
  return { feed: S, reset: k };
}
function Ba(t, e, r) {
  return r === 100 && t.charCodeAt(e + 1) === 97 && t.charCodeAt(e + 2) === 116 && t.charCodeAt(e + 3) === 97 && t.charCodeAt(e + 4) === 58;
}
function Ga(t, e, r) {
  return r === 101 && t.charCodeAt(e + 1) === 118 && t.charCodeAt(e + 2) === 101 && t.charCodeAt(e + 3) === 110 && t.charCodeAt(e + 4) === 116 && t.charCodeAt(e + 5) === 58;
}
class Ka extends Event {
  /**
   * Constructs a new `ErrorEvent` instance. This is typically not called directly,
   * but rather emitted by the `EventSource` object when an error occurs.
   *
   * @param type - The type of the event (should be "error")
   * @param errorEventInitDict - Optional properties to include in the error event
   */
  constructor(e, r) {
    var n, o;
    super(e), this.code = (n = r == null ? void 0 : r.code) != null ? n : void 0, this.message = (o = r == null ? void 0 : r.message) != null ? o : void 0;
  }
  /**
   * Node.js "hides" the `message` and `code` properties of the `ErrorEvent` instance,
   * when it is `console.log`'ed. This makes it harder to debug errors. To ease debugging,
   * we explicitly include the properties in the `inspect` method.
   *
   * This is automatically called by Node.js when you `console.log` an instance of this class.
   *
   * @param _depth - The current depth
   * @param options - The options passed to `util.inspect`
   * @param inspect - The inspect function to use (prevents having to import it from `util`)
   * @returns A string representation of the error
   */
  [Symbol.for("nodejs.util.inspect.custom")](e, r, n) {
    return n(Ja(this), r);
  }
  /**
   * Deno "hides" the `message` and `code` properties of the `ErrorEvent` instance,
   * when it is `console.log`'ed. This makes it harder to debug errors. To ease debugging,
   * we explicitly include the properties in the `inspect` method.
   *
   * This is automatically called by Deno when you `console.log` an instance of this class.
   *
   * @param inspect - The inspect function to use (prevents having to import it from `util`)
   * @param options - The options passed to `Deno.inspect`
   * @returns A string representation of the error
   */
  [Symbol.for("Deno.customInspect")](e, r) {
    return e(Ja(this), r);
  }
}
function ey(t) {
  const e = globalThis.DOMException;
  return typeof e == "function" ? new e(t, "SyntaxError") : new SyntaxError(t);
}
function Lo(t) {
  return t instanceof Error ? "errors" in t && Array.isArray(t.errors) ? t.errors.map(Lo).join(", ") : "cause" in t && t.cause instanceof Error ? `${t}: ${Lo(t.cause)}` : t.message : `${t}`;
}
function Ja(t) {
  return {
    type: t.type,
    message: t.message,
    code: t.code,
    defaultPrevented: t.defaultPrevented,
    cancelable: t.cancelable,
    timeStamp: t.timeStamp
  };
}
var Nu = (t) => {
  throw TypeError(t);
}, Hs = (t, e, r) => e.has(t) || Nu("Cannot " + r), ce = (t, e, r) => (Hs(t, e, "read from private field"), r ? r.call(t) : e.get(t)), Oe = (t, e, r) => e.has(t) ? Nu("Cannot add the same private member more than once") : e instanceof WeakSet ? e.add(t) : e.set(t, r), be = (t, e, r, n) => (Hs(t, e, "write to private field"), e.set(t, r), r), $t = (t, e, r) => (Hs(t, e, "access private method"), r), et, Lt, Yt, zn, Ln, Er, sr, kr, At, er, ar, tr, $r, pt, Zo, Vo, Ho, Qa, Wo, Bo, Sr, Go, Ko;
class Nn extends EventTarget {
  constructor(e, r) {
    var n, o;
    super(), Oe(this, pt), this.CONNECTING = 0, this.OPEN = 1, this.CLOSED = 2, Oe(this, et), Oe(this, Lt), Oe(this, Yt), Oe(this, zn), Oe(this, Ln), Oe(this, Er), Oe(this, sr), Oe(this, kr, null), Oe(this, At), Oe(this, er), Oe(this, ar, null), Oe(this, tr, null), Oe(this, $r, null), Oe(this, Vo, async (s) => {
      var i;
      ce(this, er).reset();
      const { body: a, redirected: c, status: u, headers: l } = s;
      if (u === 204) {
        $t(this, pt, Sr).call(this, "Server sent HTTP 204, not reconnecting", 204), this.close();
        return;
      }
      if (c ? be(this, Yt, new URL(s.url)) : be(this, Yt, void 0), u !== 200) {
        $t(this, pt, Sr).call(this, `Non-200 status code (${u})`, u);
        return;
      }
      if (!(l.get("content-type") || "").startsWith("text/event-stream")) {
        $t(this, pt, Sr).call(this, 'Invalid content type, expected "text/event-stream"', u);
        return;
      }
      if (ce(this, et) === this.CLOSED)
        return;
      be(this, et, this.OPEN);
      const h = new Event("open");
      if ((i = ce(this, $r)) == null || i.call(this, h), this.dispatchEvent(h), typeof a != "object" || !a || !("getReader" in a)) {
        $t(this, pt, Sr).call(this, "Invalid response body, expected a web ReadableStream", u), this.close();
        return;
      }
      const m = new TextDecoder(), _ = a.getReader();
      let S = !0;
      do {
        const { done: $, value: v } = await _.read();
        v && ce(this, er).feed(m.decode(v, { stream: !$ })), $ && (S = !1, ce(this, er).reset(), $t(this, pt, Go).call(this));
      } while (S);
    }), Oe(this, Ho, (s) => {
      be(this, At, void 0), !(s.name === "AbortError" || s.type === "aborted") && $t(this, pt, Go).call(this, Lo(s));
    }), Oe(this, Wo, (s) => {
      typeof s.id == "string" && be(this, kr, s.id);
      const i = new MessageEvent(s.event || "message", {
        data: s.data,
        origin: ce(this, Yt) ? ce(this, Yt).origin : ce(this, Lt).origin,
        lastEventId: s.id || ""
      });
      ce(this, tr) && (!s.event || s.event === "message") && ce(this, tr).call(this, i), this.dispatchEvent(i);
    }), Oe(this, Bo, (s) => {
      be(this, Er, s);
    }), Oe(this, Ko, () => {
      be(this, sr, void 0), ce(this, et) === this.CONNECTING && $t(this, pt, Zo).call(this);
    });
    try {
      if (e instanceof URL)
        be(this, Lt, e);
      else if (typeof e == "string")
        be(this, Lt, new URL(e, ty()));
      else
        throw new Error("Invalid URL");
    } catch {
      throw ey("An invalid or illegal string was specified");
    }
    be(this, er, zu({
      onEvent: ce(this, Wo),
      onRetry: ce(this, Bo)
    })), be(this, et, this.CONNECTING), be(this, Er, 3e3), be(this, Ln, (n = r == null ? void 0 : r.fetch) != null ? n : globalThis.fetch), be(this, zn, (o = r == null ? void 0 : r.withCredentials) != null ? o : !1), $t(this, pt, Zo).call(this);
  }
  /**
   * Returns the state of this EventSource object's connection. It can have the values described below.
   *
   * [MDN Reference](https://developer.mozilla.org/docs/Web/API/EventSource/readyState)
   *
   * Note: typed as `number` instead of `0 | 1 | 2` for compatibility with the `EventSource` interface,
   * defined in the TypeScript `dom` library.
   *
   * @public
   */
  get readyState() {
    return ce(this, et);
  }
  /**
   * Returns the URL providing the event stream.
   *
   * [MDN Reference](https://developer.mozilla.org/docs/Web/API/EventSource/url)
   *
   * @public
   */
  get url() {
    return ce(this, Lt).href;
  }
  /**
   * Returns true if the credentials mode for connection requests to the URL providing the event stream is set to "include", and false otherwise.
   *
   * [MDN Reference](https://developer.mozilla.org/docs/Web/API/EventSource/withCredentials)
   */
  get withCredentials() {
    return ce(this, zn);
  }
  /** [MDN Reference](https://developer.mozilla.org/docs/Web/API/EventSource/error_event) */
  get onerror() {
    return ce(this, ar);
  }
  set onerror(e) {
    be(this, ar, e);
  }
  /** [MDN Reference](https://developer.mozilla.org/docs/Web/API/EventSource/message_event) */
  get onmessage() {
    return ce(this, tr);
  }
  set onmessage(e) {
    be(this, tr, e);
  }
  /** [MDN Reference](https://developer.mozilla.org/docs/Web/API/EventSource/open_event) */
  get onopen() {
    return ce(this, $r);
  }
  set onopen(e) {
    be(this, $r, e);
  }
  addEventListener(e, r, n) {
    const o = r;
    super.addEventListener(e, o, n);
  }
  removeEventListener(e, r, n) {
    const o = r;
    super.removeEventListener(e, o, n);
  }
  /**
   * Aborts any instances of the fetch algorithm started for this EventSource object, and sets the readyState attribute to CLOSED.
   *
   * [MDN Reference](https://developer.mozilla.org/docs/Web/API/EventSource/close)
   *
   * @public
   */
  close() {
    ce(this, sr) && clearTimeout(ce(this, sr)), ce(this, et) !== this.CLOSED && (ce(this, At) && ce(this, At).abort(), be(this, et, this.CLOSED), be(this, At, void 0));
  }
}
et = /* @__PURE__ */ new WeakMap(), Lt = /* @__PURE__ */ new WeakMap(), Yt = /* @__PURE__ */ new WeakMap(), zn = /* @__PURE__ */ new WeakMap(), Ln = /* @__PURE__ */ new WeakMap(), Er = /* @__PURE__ */ new WeakMap(), sr = /* @__PURE__ */ new WeakMap(), kr = /* @__PURE__ */ new WeakMap(), At = /* @__PURE__ */ new WeakMap(), er = /* @__PURE__ */ new WeakMap(), ar = /* @__PURE__ */ new WeakMap(), tr = /* @__PURE__ */ new WeakMap(), $r = /* @__PURE__ */ new WeakMap(), pt = /* @__PURE__ */ new WeakSet(), /**
* Connect to the given URL and start receiving events
*
* @internal
*/
Zo = function() {
  be(this, et, this.CONNECTING), be(this, At, new AbortController()), ce(this, Ln)(ce(this, Lt), $t(this, pt, Qa).call(this)).then(ce(this, Vo)).catch(ce(this, Ho));
}, Vo = /* @__PURE__ */ new WeakMap(), Ho = /* @__PURE__ */ new WeakMap(), /**
* Get request options for the `fetch()` request
*
* @returns The request options
* @internal
*/
Qa = function() {
  var t;
  const e = {
    // [spec] Let `corsAttributeState` be `Anonymous`…
    // [spec] …will have their mode set to "cors"…
    mode: "cors",
    redirect: "follow",
    headers: { Accept: "text/event-stream", ...ce(this, kr) ? { "Last-Event-ID": ce(this, kr) } : void 0 },
    cache: "no-store",
    signal: (t = ce(this, At)) == null ? void 0 : t.signal
  };
  return "window" in globalThis && (e.credentials = this.withCredentials ? "include" : "same-origin"), e;
}, Wo = /* @__PURE__ */ new WeakMap(), Bo = /* @__PURE__ */ new WeakMap(), /**
* Handles the process referred to in the EventSource specification as "failing a connection".
*
* @param error - The error causing the connection to fail
* @param code - The HTTP status code, if available
* @internal
*/
Sr = function(t, e) {
  var r;
  ce(this, et) !== this.CLOSED && be(this, et, this.CLOSED);
  const n = new Ka("error", { code: e, message: t });
  (r = ce(this, ar)) == null || r.call(this, n), this.dispatchEvent(n);
}, /**
* Schedules a reconnection attempt against the EventSource endpoint.
*
* @param message - The error causing the connection to fail
* @param code - The HTTP status code, if available
* @internal
*/
Go = function(t, e) {
  var r;
  if (ce(this, et) === this.CLOSED)
    return;
  be(this, et, this.CONNECTING);
  const n = new Ka("error", { code: e, message: t });
  (r = ce(this, ar)) == null || r.call(this, n), this.dispatchEvent(n), be(this, sr, setTimeout(ce(this, Ko), ce(this, Er)));
}, Ko = /* @__PURE__ */ new WeakMap(), /**
* ReadyState representing an EventSource currently trying to connect
*
* @public
*/
Nn.CONNECTING = 0, /**
* ReadyState representing an EventSource connection that is open (eg connected)
*
* @public
*/
Nn.OPEN = 1, /**
* ReadyState representing an EventSource connection that is closed (eg disconnected)
*
* @public
*/
Nn.CLOSED = 2;
function ty() {
  const t = "document" in globalThis ? globalThis.document : void 0;
  return t && typeof t == "object" && "baseURI" in t && typeof t.baseURI == "string" ? t.baseURI : void 0;
}
function Zn(t) {
  return t ? t instanceof Headers ? Object.fromEntries(t.entries()) : Array.isArray(t) ? Object.fromEntries(t) : { ...t } : {};
}
function Mu(t = fetch, e) {
  return e ? async (r, n) => {
    const o = {
      ...e,
      ...n,
      // Headers need special handling - merge instead of replace
      headers: n != null && n.headers ? { ...Zn(e.headers), ...Zn(n.headers) } : e.headers
    };
    return t(r, o);
  } : t;
}
let Ws;
Ws = globalThis.crypto;
async function ry(t) {
  return (await Ws).getRandomValues(new Uint8Array(t));
}
async function ny(t) {
  const e = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-._~", r = Math.pow(2, 8) - Math.pow(2, 8) % e.length;
  let n = "";
  for (; n.length < t; ) {
    const o = await ry(t - n.length);
    for (const s of o)
      s < r && (n += e[s % e.length]);
  }
  return n;
}
async function oy(t) {
  return await ny(t);
}
async function sy(t) {
  const e = await (await Ws).subtle.digest("SHA-256", new TextEncoder().encode(t));
  return btoa(String.fromCharCode(...new Uint8Array(e))).replace(/\//g, "_").replace(/\+/g, "-").replace(/=/g, "");
}
async function iy(t) {
  if (t || (t = 43), t < 43 || t > 128)
    throw `Expected a length between 43 and 128. Received ${t}.`;
  const e = await oy(t), r = await sy(e);
  return {
    code_verifier: e,
    code_challenge: r
  };
}
const Ue = ap().superRefine((t, e) => {
  if (!URL.canParse(t))
    return e.addIssue({
      code: Yp.custom,
      message: "URL must be parseable",
      fatal: !0
    }), cl;
}).refine((t) => {
  const e = new URL(t);
  return e.protocol !== "javascript:" && e.protocol !== "data:" && e.protocol !== "vbscript:";
}, { message: "URL cannot use javascript:, data:, or vbscript: scheme" }), ay = Fe({
  resource: C().url(),
  authorization_servers: H(Ue).optional(),
  jwks_uri: C().url().optional(),
  scopes_supported: H(C()).optional(),
  bearer_methods_supported: H(C()).optional(),
  resource_signing_alg_values_supported: H(C()).optional(),
  resource_name: C().optional(),
  resource_documentation: C().optional(),
  resource_policy_uri: C().url().optional(),
  resource_tos_uri: C().url().optional(),
  tls_client_certificate_bound_access_tokens: _e().optional(),
  authorization_details_types_supported: H(C()).optional(),
  dpop_signing_alg_values_supported: H(C()).optional(),
  dpop_bound_access_tokens_required: _e().optional()
}), ju = Fe({
  issuer: C(),
  authorization_endpoint: Ue,
  token_endpoint: Ue,
  registration_endpoint: Ue.optional(),
  scopes_supported: H(C()).optional(),
  response_types_supported: H(C()),
  response_modes_supported: H(C()).optional(),
  grant_types_supported: H(C()).optional(),
  token_endpoint_auth_methods_supported: H(C()).optional(),
  token_endpoint_auth_signing_alg_values_supported: H(C()).optional(),
  service_documentation: Ue.optional(),
  revocation_endpoint: Ue.optional(),
  revocation_endpoint_auth_methods_supported: H(C()).optional(),
  revocation_endpoint_auth_signing_alg_values_supported: H(C()).optional(),
  introspection_endpoint: C().optional(),
  introspection_endpoint_auth_methods_supported: H(C()).optional(),
  introspection_endpoint_auth_signing_alg_values_supported: H(C()).optional(),
  code_challenge_methods_supported: H(C()).optional(),
  client_id_metadata_document_supported: _e().optional()
}), cy = Fe({
  issuer: C(),
  authorization_endpoint: Ue,
  token_endpoint: Ue,
  userinfo_endpoint: Ue.optional(),
  jwks_uri: Ue,
  registration_endpoint: Ue.optional(),
  scopes_supported: H(C()).optional(),
  response_types_supported: H(C()),
  response_modes_supported: H(C()).optional(),
  grant_types_supported: H(C()).optional(),
  acr_values_supported: H(C()).optional(),
  subject_types_supported: H(C()),
  id_token_signing_alg_values_supported: H(C()),
  id_token_encryption_alg_values_supported: H(C()).optional(),
  id_token_encryption_enc_values_supported: H(C()).optional(),
  userinfo_signing_alg_values_supported: H(C()).optional(),
  userinfo_encryption_alg_values_supported: H(C()).optional(),
  userinfo_encryption_enc_values_supported: H(C()).optional(),
  request_object_signing_alg_values_supported: H(C()).optional(),
  request_object_encryption_alg_values_supported: H(C()).optional(),
  request_object_encryption_enc_values_supported: H(C()).optional(),
  token_endpoint_auth_methods_supported: H(C()).optional(),
  token_endpoint_auth_signing_alg_values_supported: H(C()).optional(),
  display_values_supported: H(C()).optional(),
  claim_types_supported: H(C()).optional(),
  claims_supported: H(C()).optional(),
  service_documentation: C().optional(),
  claims_locales_supported: H(C()).optional(),
  ui_locales_supported: H(C()).optional(),
  claims_parameter_supported: _e().optional(),
  request_parameter_supported: _e().optional(),
  request_uri_parameter_supported: _e().optional(),
  require_request_uri_registration: _e().optional(),
  op_policy_uri: Ue.optional(),
  op_tos_uri: Ue.optional(),
  client_id_metadata_document_supported: _e().optional()
}), uy = W({
  ...cy.shape,
  ...ju.pick({
    code_challenge_methods_supported: !0
  }).shape
}), ly = W({
  access_token: C(),
  id_token: C().optional(),
  // Optional for OAuth 2.1, but necessary in OpenID Connect
  token_type: C(),
  expires_in: em().optional(),
  scope: C().optional(),
  refresh_token: C().optional()
}).strip(), dy = W({
  error: C(),
  error_description: C().optional(),
  error_uri: C().optional()
}), Xa = Ue.optional().or(Q("").transform(() => {
})), fy = W({
  redirect_uris: H(Ue),
  token_endpoint_auth_method: C().optional(),
  grant_types: H(C()).optional(),
  response_types: H(C()).optional(),
  client_name: C().optional(),
  client_uri: Ue.optional(),
  logo_uri: Xa,
  scope: C().optional(),
  contacts: H(C()).optional(),
  tos_uri: Xa,
  policy_uri: C().optional(),
  jwks_uri: Ue.optional(),
  jwks: Pp().optional(),
  software_id: C().optional(),
  software_version: C().optional(),
  software_statement: C().optional()
}).strip(), hy = W({
  client_id: C(),
  client_secret: C().optional(),
  client_id_issued_at: pe().optional(),
  client_secret_expires_at: pe().optional()
}).strip(), py = fy.merge(hy);
W({
  error: C(),
  error_description: C().optional()
}).strip();
W({
  token: C(),
  token_type_hint: C().optional()
}).strip();
function my(t) {
  const e = typeof t == "string" ? new URL(t) : new URL(t.href);
  return e.hash = "", e;
}
function gy({ requestedResource: t, configuredResource: e }) {
  const r = typeof t == "string" ? new URL(t) : new URL(t.href), n = typeof e == "string" ? new URL(e) : new URL(e.href);
  if (r.origin !== n.origin || r.pathname.length < n.pathname.length)
    return !1;
  const o = r.pathname.endsWith("/") ? r.pathname : r.pathname + "/", s = n.pathname.endsWith("/") ? n.pathname : n.pathname + "/";
  return o.startsWith(s);
}
class je extends Error {
  constructor(e, r) {
    super(e), this.errorUri = r, this.name = this.constructor.name;
  }
  /**
   * Converts the error to a standard OAuth error response object
   */
  toResponseObject() {
    const e = {
      error: this.errorCode,
      error_description: this.message
    };
    return this.errorUri && (e.error_uri = this.errorUri), e;
  }
  get errorCode() {
    return this.constructor.errorCode;
  }
}
class Jo extends je {
}
Jo.errorCode = "invalid_request";
class Vn extends je {
}
Vn.errorCode = "invalid_client";
class Hn extends je {
}
Hn.errorCode = "invalid_grant";
class Wn extends je {
}
Wn.errorCode = "unauthorized_client";
class Qo extends je {
}
Qo.errorCode = "unsupported_grant_type";
class Xo extends je {
}
Xo.errorCode = "invalid_scope";
class Yo extends je {
}
Yo.errorCode = "access_denied";
class hr extends je {
}
hr.errorCode = "server_error";
class es extends je {
}
es.errorCode = "temporarily_unavailable";
class ts extends je {
}
ts.errorCode = "unsupported_response_type";
class rs extends je {
}
rs.errorCode = "unsupported_token_type";
class ns extends je {
}
ns.errorCode = "invalid_token";
class os extends je {
}
os.errorCode = "method_not_allowed";
class ss extends je {
}
ss.errorCode = "too_many_requests";
class Bn extends je {
}
Bn.errorCode = "invalid_client_metadata";
class is extends je {
}
is.errorCode = "insufficient_scope";
class as extends je {
}
as.errorCode = "invalid_target";
const _y = {
  [Jo.errorCode]: Jo,
  [Vn.errorCode]: Vn,
  [Hn.errorCode]: Hn,
  [Wn.errorCode]: Wn,
  [Qo.errorCode]: Qo,
  [Xo.errorCode]: Xo,
  [Yo.errorCode]: Yo,
  [hr.errorCode]: hr,
  [es.errorCode]: es,
  [ts.errorCode]: ts,
  [rs.errorCode]: rs,
  [ns.errorCode]: ns,
  [os.errorCode]: os,
  [ss.errorCode]: ss,
  [Bn.errorCode]: Bn,
  [is.errorCode]: is,
  [as.errorCode]: as
};
class mt extends Error {
  constructor(e) {
    super(e ?? "Unauthorized");
  }
}
function yy(t) {
  return ["client_secret_basic", "client_secret_post", "none"].includes(t);
}
const Io = "code", Oo = "S256";
function vy(t, e) {
  const r = t.client_secret !== void 0;
  return "token_endpoint_auth_method" in t && t.token_endpoint_auth_method && yy(t.token_endpoint_auth_method) && (e.length === 0 || e.includes(t.token_endpoint_auth_method)) ? t.token_endpoint_auth_method : e.length === 0 ? r ? "client_secret_basic" : "none" : r && e.includes("client_secret_basic") ? "client_secret_basic" : r && e.includes("client_secret_post") ? "client_secret_post" : e.includes("none") ? "none" : r ? "client_secret_post" : "none";
}
function wy(t, e, r, n) {
  const { client_id: o, client_secret: s } = e;
  switch (t) {
    case "client_secret_basic":
      by(o, s, r);
      return;
    case "client_secret_post":
      $y(o, s, n);
      return;
    case "none":
      Sy(o, n);
      return;
    default:
      throw new Error(`Unsupported client authentication method: ${t}`);
  }
}
function by(t, e, r) {
  if (!e)
    throw new Error("client_secret_basic authentication requires a client_secret");
  const n = btoa(`${t}:${e}`);
  r.set("Authorization", `Basic ${n}`);
}
function $y(t, e, r) {
  r.set("client_id", t), e && r.set("client_secret", e);
}
function Sy(t, e) {
  e.set("client_id", t);
}
async function xu(t) {
  const e = t instanceof Response ? t.status : void 0, r = t instanceof Response ? await t.text() : t;
  try {
    const n = dy.parse(JSON.parse(r)), { error: o, error_description: s, error_uri: i } = n, a = _y[o] || hr;
    return new a(s || "", i);
  } catch (n) {
    const o = `${e ? `HTTP ${e}: ` : ""}Invalid OAuth error response: ${n}. Raw body: ${r}`;
    return new hr(o);
  }
}
async function Bt(t, e) {
  var r, n;
  try {
    return await zo(t, e);
  } catch (o) {
    if (o instanceof Vn || o instanceof Wn)
      return await ((r = t.invalidateCredentials) == null ? void 0 : r.call(t, "all")), await zo(t, e);
    if (o instanceof Hn)
      return await ((n = t.invalidateCredentials) == null ? void 0 : n.call(t, "tokens")), await zo(t, e);
    throw o;
  }
}
async function zo(t, { serverUrl: e, authorizationCode: r, scope: n, resourceMetadataUrl: o, fetchFn: s }) {
  var w, k, f, d, p;
  const i = await ((w = t.discoveryState) == null ? void 0 : w.call(t));
  let a, c, u, l = o;
  if (!l && (i != null && i.resourceMetadataUrl) && (l = new URL(i.resourceMetadataUrl)), i != null && i.authorizationServerUrl) {
    if (c = i.authorizationServerUrl, a = i.resourceMetadata, u = i.authorizationServerMetadata ?? await Du(c, { fetchFn: s }), !a)
      try {
        a = await qu(e, { resourceMetadataUrl: l }, s);
      } catch {
      }
    (u !== i.authorizationServerMetadata || a !== i.resourceMetadata) && await ((k = t.saveDiscoveryState) == null ? void 0 : k.call(t, {
      authorizationServerUrl: String(c),
      resourceMetadataUrl: l == null ? void 0 : l.toString(),
      resourceMetadata: a,
      authorizationServerMetadata: u
    }));
  } else {
    const E = await Ry(e, { resourceMetadataUrl: l, fetchFn: s });
    c = E.authorizationServerUrl, u = E.authorizationServerMetadata, a = E.resourceMetadata, await ((f = t.saveDiscoveryState) == null ? void 0 : f.call(t, {
      authorizationServerUrl: String(c),
      resourceMetadataUrl: l == null ? void 0 : l.toString(),
      resourceMetadata: a,
      authorizationServerMetadata: u
    }));
  }
  const h = await ky(e, t, a), m = n || ((d = a == null ? void 0 : a.scopes_supported) == null ? void 0 : d.join(" ")) || t.clientMetadata.scope;
  let _ = await Promise.resolve(t.clientInformation());
  if (!_) {
    if (r !== void 0)
      throw new Error("Existing OAuth client information is required when exchanging an authorization code");
    const E = (u == null ? void 0 : u.client_id_metadata_document_supported) === !0, I = t.clientMetadataUrl;
    if (I && !Ey(I))
      throw new Bn(`clientMetadataUrl must be a valid HTTPS URL with a non-root pathname, got: ${I}`);
    if (E && I)
      _ = {
        client_id: I
      }, await ((p = t.saveClientInformation) == null ? void 0 : p.call(t, _));
    else {
      if (!t.saveClientInformation)
        throw new Error("OAuth client information must be saveable for dynamic registration");
      const A = await My(c, {
        metadata: u,
        clientMetadata: t.clientMetadata,
        scope: m,
        fetchFn: s
      });
      await t.saveClientInformation(A), _ = A;
    }
  }
  const S = !t.redirectUrl;
  if (r !== void 0 || S) {
    const E = await Ny(t, c, {
      metadata: u,
      resource: h,
      authorizationCode: r,
      fetchFn: s
    });
    return await t.saveTokens(E), "AUTHORIZED";
  }
  const $ = await t.tokens();
  if ($ != null && $.refresh_token)
    try {
      const E = await zy(c, {
        metadata: u,
        clientInformation: _,
        refreshToken: $.refresh_token,
        resource: h,
        addClientAuthentication: t.addClientAuthentication,
        fetchFn: s
      });
      return await t.saveTokens(E), "AUTHORIZED";
    } catch (E) {
      if (!(!(E instanceof je) || E instanceof hr)) throw E;
    }
  const v = t.state ? await t.state() : void 0, { authorizationUrl: y, codeVerifier: g } = await Iy(c, {
    metadata: u,
    clientInformation: _,
    state: v,
    redirectUrl: t.redirectUrl,
    scope: m,
    resource: h
  });
  return await t.saveCodeVerifier(g), await t.redirectToAuthorization(y), "REDIRECT";
}
function Ey(t) {
  if (!t)
    return !1;
  try {
    const e = new URL(t);
    return e.protocol === "https:" && e.pathname !== "/";
  } catch {
    return !1;
  }
}
async function ky(t, e, r) {
  const n = my(t);
  if (e.validateResourceURL)
    return await e.validateResourceURL(n, r == null ? void 0 : r.resource);
  if (r) {
    if (!gy({ requestedResource: n, configuredResource: r.resource }))
      throw new Error(`Protected resource ${r.resource} does not match expected ${n} (or origin)`);
    return new URL(r.resource);
  }
}
function Gn(t) {
  const e = t.headers.get("WWW-Authenticate");
  if (!e)
    return {};
  const [r, n] = e.split(" ");
  if (r.toLowerCase() !== "bearer" || !n)
    return {};
  const o = No(t, "resource_metadata") || void 0;
  let s;
  if (o)
    try {
      s = new URL(o);
    } catch {
    }
  const i = No(t, "scope") || void 0, a = No(t, "error") || void 0;
  return {
    resourceMetadataUrl: s,
    scope: i,
    error: a
  };
}
function No(t, e) {
  const r = t.headers.get("WWW-Authenticate");
  if (!r)
    return null;
  const n = new RegExp(`${e}=(?:"([^"]+)"|([^\\s,]+))`), o = r.match(n);
  return o ? o[1] || o[2] : null;
}
async function qu(t, e, r = fetch) {
  var o, s;
  const n = await Py(t, "oauth-protected-resource", r, {
    protocolVersion: e == null ? void 0 : e.protocolVersion,
    metadataUrl: e == null ? void 0 : e.resourceMetadataUrl
  });
  if (!n || n.status === 404)
    throw await ((o = n == null ? void 0 : n.body) == null ? void 0 : o.cancel()), new Error("Resource server does not implement OAuth 2.0 Protected Resource Metadata.");
  if (!n.ok)
    throw await ((s = n.body) == null ? void 0 : s.cancel()), new Error(`HTTP ${n.status} trying to load well-known OAuth protected resource metadata.`);
  return ay.parse(await n.json());
}
async function Bs(t, e, r = fetch) {
  try {
    return await r(t, { headers: e });
  } catch (n) {
    if (n instanceof TypeError)
      return e ? Bs(t, void 0, r) : void 0;
    throw n;
  }
}
function Cy(t, e = "", r = {}) {
  return e.endsWith("/") && (e = e.slice(0, -1)), r.prependPathname ? `${e}/.well-known/${t}` : `/.well-known/${t}${e}`;
}
async function Ya(t, e, r = fetch) {
  return await Bs(t, {
    "MCP-Protocol-Version": e
  }, r);
}
function Ty(t, e) {
  return !t || t.status >= 400 && t.status < 500 && e !== "/";
}
async function Py(t, e, r, n) {
  const o = new URL(t), s = (n == null ? void 0 : n.protocolVersion) ?? eo;
  let i;
  if (n != null && n.metadataUrl)
    i = new URL(n.metadataUrl);
  else {
    const c = Cy(e, o.pathname);
    i = new URL(c, (n == null ? void 0 : n.metadataServerUrl) ?? o), i.search = o.search;
  }
  let a = await Ya(i, s, r);
  if (!(n != null && n.metadataUrl) && Ty(a, o.pathname)) {
    const c = new URL(`/.well-known/${e}`, o);
    a = await Ya(c, s, r);
  }
  return a;
}
function Ay(t) {
  const e = typeof t == "string" ? new URL(t) : t, r = e.pathname !== "/", n = [];
  if (!r)
    return n.push({
      url: new URL("/.well-known/oauth-authorization-server", e.origin),
      type: "oauth"
    }), n.push({
      url: new URL("/.well-known/openid-configuration", e.origin),
      type: "oidc"
    }), n;
  let o = e.pathname;
  return o.endsWith("/") && (o = o.slice(0, -1)), n.push({
    url: new URL(`/.well-known/oauth-authorization-server${o}`, e.origin),
    type: "oauth"
  }), n.push({
    url: new URL(`/.well-known/openid-configuration${o}`, e.origin),
    type: "oidc"
  }), n.push({
    url: new URL(`${o}/.well-known/openid-configuration`, e.origin),
    type: "oidc"
  }), n;
}
async function Du(t, { fetchFn: e = fetch, protocolVersion: r = eo } = {}) {
  var s;
  const n = {
    "MCP-Protocol-Version": r,
    Accept: "application/json"
  }, o = Ay(t);
  for (const { url: i, type: a } of o) {
    const c = await Bs(i, n, e);
    if (c) {
      if (!c.ok) {
        if (await ((s = c.body) == null ? void 0 : s.cancel()), c.status >= 400 && c.status < 500)
          continue;
        throw new Error(`HTTP ${c.status} trying to load ${a === "oauth" ? "OAuth" : "OpenID provider"} metadata from ${i}`);
      }
      return a === "oauth" ? ju.parse(await c.json()) : uy.parse(await c.json());
    }
  }
}
async function Ry(t, e) {
  let r, n;
  try {
    r = await qu(t, { resourceMetadataUrl: e == null ? void 0 : e.resourceMetadataUrl }, e == null ? void 0 : e.fetchFn), r.authorization_servers && r.authorization_servers.length > 0 && (n = r.authorization_servers[0]);
  } catch {
  }
  n || (n = String(new URL("/", t)));
  const o = await Du(n, { fetchFn: e == null ? void 0 : e.fetchFn });
  return {
    authorizationServerUrl: n,
    authorizationServerMetadata: o,
    resourceMetadata: r
  };
}
async function Iy(t, { metadata: e, clientInformation: r, redirectUrl: n, scope: o, state: s, resource: i }) {
  let a;
  if (e) {
    if (a = new URL(e.authorization_endpoint), !e.response_types_supported.includes(Io))
      throw new Error(`Incompatible auth server: does not support response type ${Io}`);
    if (e.code_challenge_methods_supported && !e.code_challenge_methods_supported.includes(Oo))
      throw new Error(`Incompatible auth server: does not support code challenge method ${Oo}`);
  } else
    a = new URL("/authorize", t);
  const c = await iy(), u = c.code_verifier, l = c.code_challenge;
  return a.searchParams.set("response_type", Io), a.searchParams.set("client_id", r.client_id), a.searchParams.set("code_challenge", l), a.searchParams.set("code_challenge_method", Oo), a.searchParams.set("redirect_uri", String(n)), s && a.searchParams.set("state", s), o && a.searchParams.set("scope", o), o != null && o.includes("offline_access") && a.searchParams.append("prompt", "consent"), i && a.searchParams.set("resource", i.href), { authorizationUrl: a, codeVerifier: u };
}
function Oy(t, e, r) {
  return new URLSearchParams({
    grant_type: "authorization_code",
    code: t,
    code_verifier: e,
    redirect_uri: String(r)
  });
}
async function Uu(t, { metadata: e, tokenRequestParams: r, clientInformation: n, addClientAuthentication: o, resource: s, fetchFn: i }) {
  const a = e != null && e.token_endpoint ? new URL(e.token_endpoint) : new URL("/token", t), c = new Headers({
    "Content-Type": "application/x-www-form-urlencoded",
    Accept: "application/json"
  });
  if (s && r.set("resource", s.href), o)
    await o(c, r, a, e);
  else if (n) {
    const l = (e == null ? void 0 : e.token_endpoint_auth_methods_supported) ?? [], h = vy(n, l);
    wy(h, n, c, r);
  }
  const u = await (i ?? fetch)(a, {
    method: "POST",
    headers: c,
    body: r
  });
  if (!u.ok)
    throw await xu(u);
  return ly.parse(await u.json());
}
async function zy(t, { metadata: e, clientInformation: r, refreshToken: n, resource: o, addClientAuthentication: s, fetchFn: i }) {
  const a = new URLSearchParams({
    grant_type: "refresh_token",
    refresh_token: n
  }), c = await Uu(t, {
    metadata: e,
    tokenRequestParams: a,
    clientInformation: r,
    addClientAuthentication: s,
    resource: o,
    fetchFn: i
  });
  return { refresh_token: n, ...c };
}
async function Ny(t, e, { metadata: r, resource: n, authorizationCode: o, fetchFn: s } = {}) {
  const i = t.clientMetadata.scope;
  let a;
  if (t.prepareTokenRequest && (a = await t.prepareTokenRequest(i)), !a) {
    if (!o)
      throw new Error("Either provider.prepareTokenRequest() or authorizationCode is required");
    if (!t.redirectUrl)
      throw new Error("redirectUrl is required for authorization_code flow");
    const u = await t.codeVerifier();
    a = Oy(o, u, t.redirectUrl);
  }
  const c = await t.clientInformation();
  return Uu(e, {
    metadata: r,
    tokenRequestParams: a,
    clientInformation: c ?? void 0,
    addClientAuthentication: t.addClientAuthentication,
    resource: n,
    fetchFn: s
  });
}
async function My(t, { metadata: e, clientMetadata: r, scope: n, fetchFn: o }) {
  let s;
  if (e) {
    if (!e.registration_endpoint)
      throw new Error("Incompatible auth server: does not support dynamic client registration");
    s = new URL(e.registration_endpoint);
  } else
    s = new URL("/register", t);
  const i = await (o ?? fetch)(s, {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      ...r,
      ...n !== void 0 ? { scope: n } : {}
    })
  });
  if (!i.ok)
    throw await xu(i);
  return py.parse(await i.json());
}
class jy extends Error {
  constructor(e, r, n) {
    super(`SSE error: ${r}`), this.code = e, this.event = n;
  }
}
class xy {
  constructor(e, r) {
    this._url = e, this._resourceMetadataUrl = void 0, this._scope = void 0, this._eventSourceInit = r == null ? void 0 : r.eventSourceInit, this._requestInit = r == null ? void 0 : r.requestInit, this._authProvider = r == null ? void 0 : r.authProvider, this._fetch = r == null ? void 0 : r.fetch, this._fetchWithInit = Mu(r == null ? void 0 : r.fetch, r == null ? void 0 : r.requestInit);
  }
  async _authThenStart() {
    var r;
    if (!this._authProvider)
      throw new mt("No auth provider");
    let e;
    try {
      e = await Bt(this._authProvider, {
        serverUrl: this._url,
        resourceMetadataUrl: this._resourceMetadataUrl,
        scope: this._scope,
        fetchFn: this._fetchWithInit
      });
    } catch (n) {
      throw (r = this.onerror) == null || r.call(this, n), n;
    }
    if (e !== "AUTHORIZED")
      throw new mt();
    return await this._startOrAuth();
  }
  async _commonHeaders() {
    var n;
    const e = {};
    if (this._authProvider) {
      const o = await this._authProvider.tokens();
      o && (e.Authorization = `Bearer ${o.access_token}`);
    }
    this._protocolVersion && (e["mcp-protocol-version"] = this._protocolVersion);
    const r = Zn((n = this._requestInit) == null ? void 0 : n.headers);
    return new Headers({
      ...e,
      ...r
    });
  }
  _startOrAuth() {
    var r;
    const e = ((r = this == null ? void 0 : this._eventSourceInit) == null ? void 0 : r.fetch) ?? this._fetch ?? fetch;
    return new Promise((n, o) => {
      this._eventSource = new Nn(this._url.href, {
        ...this._eventSourceInit,
        fetch: async (s, i) => {
          const a = await this._commonHeaders();
          a.set("Accept", "text/event-stream");
          const c = await e(s, {
            ...i,
            headers: a
          });
          if (c.status === 401 && c.headers.has("www-authenticate")) {
            const { resourceMetadataUrl: u, scope: l } = Gn(c);
            this._resourceMetadataUrl = u, this._scope = l;
          }
          return c;
        }
      }), this._abortController = new AbortController(), this._eventSource.onerror = (s) => {
        var a;
        if (s.code === 401 && this._authProvider) {
          this._authThenStart().then(n, o);
          return;
        }
        const i = new jy(s.code, s.message, s);
        o(i), (a = this.onerror) == null || a.call(this, i);
      }, this._eventSource.onopen = () => {
      }, this._eventSource.addEventListener("endpoint", (s) => {
        var a;
        const i = s;
        try {
          if (this._endpoint = new URL(i.data, this._url), this._endpoint.origin !== this._url.origin)
            throw new Error(`Endpoint origin does not match connection origin: ${this._endpoint.origin}`);
        } catch (c) {
          o(c), (a = this.onerror) == null || a.call(this, c), this.close();
          return;
        }
        n();
      }), this._eventSource.onmessage = (s) => {
        var c, u;
        const i = s;
        let a;
        try {
          a = In.parse(JSON.parse(i.data));
        } catch (l) {
          (c = this.onerror) == null || c.call(this, l);
          return;
        }
        (u = this.onmessage) == null || u.call(this, a);
      };
    });
  }
  async start() {
    if (this._eventSource)
      throw new Error("SSEClientTransport already started! If using Client class, note that connect() calls start() automatically.");
    return await this._startOrAuth();
  }
  /**
   * Call this method after the user has finished authorizing via their user agent and is redirected back to the MCP client application. This will exchange the authorization code for an access token, enabling the next connection attempt to successfully auth.
   */
  async finishAuth(e) {
    if (!this._authProvider)
      throw new mt("No auth provider");
    if (await Bt(this._authProvider, {
      serverUrl: this._url,
      authorizationCode: e,
      resourceMetadataUrl: this._resourceMetadataUrl,
      scope: this._scope,
      fetchFn: this._fetchWithInit
    }) !== "AUTHORIZED")
      throw new mt("Failed to authorize");
  }
  async close() {
    var e, r, n;
    (e = this._abortController) == null || e.abort(), (r = this._eventSource) == null || r.close(), (n = this.onclose) == null || n.call(this);
  }
  async send(e) {
    var r, n, o;
    if (!this._endpoint)
      throw new Error("Not connected");
    try {
      const s = await this._commonHeaders();
      s.set("content-type", "application/json");
      const i = {
        ...this._requestInit,
        method: "POST",
        headers: s,
        body: JSON.stringify(e),
        signal: (r = this._abortController) == null ? void 0 : r.signal
      }, a = await (this._fetch ?? fetch)(this._endpoint, i);
      if (!a.ok) {
        const c = await a.text().catch(() => null);
        if (a.status === 401 && this._authProvider) {
          const { resourceMetadataUrl: u, scope: l } = Gn(a);
          if (this._resourceMetadataUrl = u, this._scope = l, await Bt(this._authProvider, {
            serverUrl: this._url,
            resourceMetadataUrl: this._resourceMetadataUrl,
            scope: this._scope,
            fetchFn: this._fetchWithInit
          }) !== "AUTHORIZED")
            throw new mt();
          return this.send(e);
        }
        throw new Error(`Error POSTing to endpoint (HTTP ${a.status}): ${c}`);
      }
      await ((n = a.body) == null ? void 0 : n.cancel());
    } catch (s) {
      throw (o = this.onerror) == null || o.call(this, s), s;
    }
  }
  setProtocolVersion(e) {
    this._protocolVersion = e;
  }
}
const Ve = nt("SSEPlugin");
class Fu {
  constructor() {
    B(this, "metadata", {
      name: "SSE Transport Plugin",
      version: "1.0.0",
      transportType: "sse",
      description: "Server-Sent Events transport for MCP protocol",
      author: "Nyx Control"
    });
    B(this, "config", {});
    B(this, "transport", null);
    B(this, "isConnectedFlag", !1);
    B(this, "connectionPromise", null);
  }
  async initialize(e) {
    this.config = {
      keepAlive: !0,
      connectionTimeout: 5e3,
      readTimeout: 3e4,
      ...e
    }, Ve.debug("Initialized with config:", this.config);
  }
  async connect(e) {
    Ve.debug(`Creating transport for: ${e}`);
    try {
      const r = await this.createConnection(e);
      return this.transport = r, Ve.debug("[SSEPlugin] Transport created successfully"), r;
    } catch (r) {
      throw Ve.error("[SSEPlugin] Transport creation failed:", r), r;
    }
  }
  async createConnection(e) {
    try {
      const r = new URL(e);
      Ve.debug(`Creating SSE transport for: ${r.toString()}`);
      const n = new xy(r);
      return Ve.debug("[SSEPlugin] SSE transport created successfully"), n;
    } catch (r) {
      const n = r instanceof Error ? r.message : String(r);
      let o = n;
      throw n.includes("404") ? o = "SSE endpoint not found (404). Verify the server URL and SSE endpoint path." : n.includes("timeout") ? o = "SSE connection timeout. The server may be slow or the endpoint may not support SSE." : n.includes("Failed to fetch") && (o = "SSE connection failed. Check if the server is running and accessible."), new Error(`SSE Plugin: ${o}`);
    }
  }
  async disconnect() {
    if (Ve.debug("[SSEPlugin] Disconnecting..."), this.transport)
      try {
        "close" in this.transport && typeof this.transport.close == "function" && await this.transport.close();
      } catch (e) {
        Ve.warn("[SSEPlugin] Error during transport cleanup:", e);
      }
    this.transport = null, this.isConnectedFlag = !1, this.connectionPromise = null, Ve.debug("[SSEPlugin] Disconnected");
  }
  isConnected() {
    return this.transport !== null;
  }
  isSupported(e) {
    try {
      const r = new URL(e);
      return r.protocol === "http:" || r.protocol === "https:";
    } catch {
      return !1;
    }
  }
  getDefaultConfig() {
    return {
      keepAlive: !0,
      connectionTimeout: 5e3,
      readTimeout: 3e4,
      headers: {
        Accept: "text/event-stream",
        "Cache-Control": "no-cache"
      }
    };
  }
  async isHealthy() {
    if (!this.isConnected() || !this.transport)
      return !1;
    try {
      return !0;
    } catch (e) {
      return Ve.warn("[SSEPlugin] Health check failed:", e), !1;
    }
  }
  async callTool(e, r, n) {
    if (!this.isConnected())
      throw new Error("SSE Plugin: Not connected");
    Ve.debug(`Calling tool: ${r}`);
    try {
      const o = await e.callTool({ name: r, arguments: n });
      return Ve.debug(`Tool call completed: ${r}`), o;
    } catch (o) {
      throw Ve.error(`Tool call failed: ${r}`, o), o;
    }
  }
  async getPrimitives(e) {
    if (!this.isConnected())
      throw new Error("SSE Plugin: Not connected");
    Ve.debug("[SSEPlugin] Getting primitives...");
    try {
      const r = e.getServerCapabilities(), n = [], o = [];
      return r != null && r.resources && o.push(
        e.listResources().then(({ resources: s }) => {
          s.forEach((i) => n.push({ type: "resource", value: i }));
        })
      ), r != null && r.tools && o.push(
        e.listTools().then(({ tools: s }) => {
          s.forEach((i) => n.push({ type: "tool", value: i }));
        })
      ), r != null && r.prompts && o.push(
        e.listPrompts().then(({ prompts: s }) => {
          s.forEach((i) => n.push({ type: "prompt", value: i }));
        })
      ), await Promise.all(o), Ve.debug(`Retrieved ${n.length} primitives`), n;
    } catch (r) {
      throw Ve.error("[SSEPlugin] Failed to get primitives:", r), r;
    }
  }
}
const Be = nt("WebSocketTransport");
class qy {
  constructor(e, r = {}) {
    // Transport interface callbacks - required by MCP client
    B(this, "onmessage");
    B(this, "onclose");
    B(this, "onerror");
    B(this, "ws", null);
    B(this, "url");
    B(this, "options");
    B(this, "messageQueue", []);
    B(this, "isConnected", !1);
    // Removed ping/pong timers - using MCP protocol connection management
    B(this, "eventListeners", /* @__PURE__ */ new Map());
    this.url = e, this.options = {
      protocols: ["mcp-v1"],
      pingInterval: 3e4,
      pongTimeout: 5e3,
      binaryType: "arraybuffer",
      maxReconnectAttempts: 3,
      ...r
    };
  }
  async start() {
    Be.debug("[WebSocketTransport] Start method called - initiating connection"), await this.connect();
  }
  async connect() {
    if (this.isConnected || this.ws && this.ws.readyState === WebSocket.CONNECTING) {
      Be.debug("[WebSocketTransport] Already connected or connecting");
      return;
    }
    return new Promise((e, r) => {
      try {
        Be.debug(`Connecting to: ${this.url}`), this.ws = new WebSocket(this.url, this.options.protocols), this.ws.binaryType = this.options.binaryType || "arraybuffer";
        const n = setTimeout(() => {
          this.ws && this.ws.readyState === WebSocket.CONNECTING && (this.ws.close(), r(new Error("WebSocket connection timeout")));
        }, 1e4);
        this.ws.onopen = () => {
          clearTimeout(n), Be.debug("[WebSocketTransport] Connected"), this.isConnected = !0, this.startPingPong(), this.processMessageQueue(), e();
        }, this.ws.onclose = (o) => {
          clearTimeout(n), Be.debug(`Disconnected: ${o.code} ${o.reason}`), this.isConnected = !1, this.stopPingPong(), this.emit("close", { code: o.code, reason: o.reason }), this.onclose && this.onclose();
        }, this.ws.onerror = (o) => {
          clearTimeout(n), Be.error("[WebSocketTransport] Error:", o), this.isConnected = !1, this.emit("error", o), this.onerror && this.onerror(new Error("WebSocket connection failed")), r(new Error("WebSocket connection failed"));
        }, this.ws.onmessage = (o) => {
          try {
            let s;
            if (typeof o.data == "string")
              s = JSON.parse(o.data);
            else if (o.data instanceof ArrayBuffer) {
              const i = new TextDecoder().decode(o.data);
              s = JSON.parse(i);
            } else {
              Be.warn("[WebSocketTransport] Received unknown data type:", typeof o.data);
              return;
            }
            this.emit("message", s), this.onmessage && this.onmessage(s);
          } catch (s) {
            Be.error("[WebSocketTransport] Failed to parse message:", s);
            const i = new Error("Failed to parse WebSocket message");
            this.emit("error", i), this.onerror && this.onerror(i);
          }
        };
      } catch (n) {
        r(n);
      }
    });
  }
  async close() {
    Be.debug("[WebSocketTransport] Closing connection"), this.isConnected = !1, this.stopPingPong(), this.ws && (this.ws.close(1e3, "Normal closure"), this.ws = null);
  }
  async send(e) {
    const r = JSON.stringify(e);
    if (!this.isConnected || !this.ws || this.ws.readyState !== WebSocket.OPEN) {
      Be.debug("[WebSocketTransport] Queuing message (not connected)"), this.messageQueue.push(e);
      return;
    }
    try {
      this.ws.send(r);
    } catch (n) {
      throw Be.error("[WebSocketTransport] Failed to send message:", n), this.messageQueue.push(e), n;
    }
  }
  processMessageQueue() {
    if (this.messageQueue.length === 0) return;
    Be.debug(`Processing ${this.messageQueue.length} queued messages`);
    const e = [...this.messageQueue];
    this.messageQueue = [], e.forEach((r) => {
      try {
        this.send(r);
      } catch (n) {
        Be.error("[WebSocketTransport] Failed to send queued message:", n), this.messageQueue.push(r);
      }
    });
  }
  startPingPong() {
    Be.debug("[WebSocketTransport] Skipping custom ping/pong - relying on MCP protocol and server-side monitoring");
  }
  stopPingPong() {
  }
  // Removed custom ping/pong methods - using MCP protocol instead
  // Event emitter functionality
  on(e, r) {
    this.eventListeners.has(e) || this.eventListeners.set(e, /* @__PURE__ */ new Set()), this.eventListeners.get(e).add(r);
  }
  off(e, r) {
    const n = this.eventListeners.get(e);
    n && n.delete(r);
  }
  emit(e, r) {
    const n = this.eventListeners.get(e);
    n && n.forEach((o) => {
      try {
        o(r);
      } catch (s) {
        Be.error(`Error in ${e} listener:`, s);
      }
    });
  }
  getReadyState() {
    var e;
    return ((e = this.ws) == null ? void 0 : e.readyState) ?? WebSocket.CLOSED;
  }
  isConnectionOpen() {
    var e;
    return this.isConnected && ((e = this.ws) == null ? void 0 : e.readyState) === WebSocket.OPEN;
  }
}
const Ae = nt("WebSocketPlugin");
class Lu {
  constructor() {
    B(this, "metadata", {
      name: "WebSocket Transport Plugin",
      version: "1.0.0",
      transportType: "websocket",
      description: "WebSocket transport for MCP protocol with real-time bidirectional communication",
      author: "Nyx Control"
    });
    B(this, "config", {});
    B(this, "transport", null);
    B(this, "isConnectedFlag", !1);
    B(this, "connectionPromise", null);
    B(this, "lastPingTime", 0);
    B(this, "disconnectionCallback");
  }
  async initialize(e) {
    this.config = {
      protocols: ["mcp-v1"],
      pingInterval: 3e4,
      pongTimeout: 5e3,
      maxReconnectAttempts: 3,
      binaryType: "arraybuffer",
      ...e
    }, Ae.debug("Initialized with config:", this.config);
  }
  async connect(e) {
    Ae.debug(`Creating transport for: ${e}`);
    try {
      const r = await this.createConnection(e);
      return this.transport = r, Ae.debug("[WebSocketPlugin] Transport created successfully"), r;
    } catch (r) {
      throw Ae.error("[WebSocketPlugin] Transport creation failed:", r), r;
    }
  }
  async createConnection(e) {
    try {
      const r = new URL(e);
      if (r.protocol !== "ws:" && r.protocol !== "wss:")
        throw new Error(`Invalid WebSocket protocol: ${r.protocol}. Expected ws: or wss:`);
      Ae.debug(`Creating WebSocket transport for: ${r.toString()}`);
      const n = new qy(r.toString(), {
        protocols: this.config.protocols,
        pingInterval: this.config.pingInterval,
        pongTimeout: this.config.pongTimeout,
        binaryType: this.config.binaryType,
        maxReconnectAttempts: this.config.maxReconnectAttempts
      });
      return n.on("close", (o) => {
        Ae.debug(`Transport closed: ${o.code} ${o.reason}`), this.isConnectedFlag = !1, this.handleDisconnection("WebSocket closed", o.code, o.reason);
      }), n.on("error", (o) => {
        Ae.error("[WebSocketPlugin] Transport error:", o), o.message.includes("Pong timeout") || (this.isConnectedFlag = !1, this.handleDisconnection("WebSocket error", void 0, o.message));
      }), Ae.debug("[WebSocketPlugin] WebSocket transport created successfully"), n;
    } catch (r) {
      const n = r instanceof Error ? r.message : String(r);
      let o = n;
      throw n.includes("timeout") ? o = "WebSocket connection timeout. The server may be slow or unreachable." : n.includes("Failed to construct") ? o = "Invalid WebSocket URL format. Check the URI syntax." : n.includes("connection failed") ? o = "WebSocket connection failed. Check if the server is running and accessible." : n.includes("protocol") && (o = "WebSocket protocol error. The server may not support the requested protocols."), new Error(`WebSocket Plugin: ${o}`);
    }
  }
  async disconnect() {
    if (Ae.debug("[WebSocketPlugin] Disconnecting..."), this.transport)
      try {
        await this.transport.close();
      } catch (e) {
        Ae.warn("[WebSocketPlugin] Error during transport cleanup:", e);
      }
    this.transport = null, this.isConnectedFlag = !1, this.connectionPromise = null, Ae.debug("[WebSocketPlugin] Disconnected");
  }
  isConnected() {
    return this.transport !== null;
  }
  isSupported(e) {
    try {
      const r = new URL(e);
      return r.protocol === "ws:" || r.protocol === "wss:";
    } catch {
      return !1;
    }
  }
  getDefaultConfig() {
    return {
      protocols: ["mcp-v1"],
      maxReconnectAttempts: 3,
      binaryType: "arraybuffer"
      // Removed ping/pong settings - using MCP protocol connection management
    };
  }
  async isHealthy() {
    if (!this.isConnected() || !this.transport)
      return !1;
    try {
      const e = this.transport.getReadyState();
      return e === WebSocket.OPEN ? ((this.config.pingInterval || 3e4) > 0, !0) : (Ae.warn(`WebSocket not in OPEN state: ${e}`), !1);
    } catch (e) {
      return Ae.warn("[WebSocketPlugin] Health check failed:", e), !1;
    }
  }
  async callTool(e, r, n) {
    if (!this.isConnected())
      throw new Error("WebSocket Plugin: Not connected");
    Ae.debug(`Calling tool: ${r}`);
    try {
      const o = await e.callTool({ name: r, arguments: n });
      return Ae.debug(`Tool call completed: ${r}`), o;
    } catch (o) {
      throw Ae.error(`Tool call failed: ${r}`, o), this.isConnected() ? o : (this.isConnectedFlag = !1, new Error(`WebSocket connection lost during tool call: ${r}`));
    }
  }
  async getPrimitives(e) {
    if (!this.isConnected())
      throw new Error("WebSocket Plugin: Not connected");
    Ae.debug("[WebSocketPlugin] Getting primitives...");
    try {
      const r = e.getServerCapabilities(), n = [], o = [];
      return r != null && r.resources && o.push(
        e.listResources().then(({ resources: s }) => {
          s.forEach((i) => n.push({ type: "resource", value: i }));
        })
      ), r != null && r.tools && o.push(
        e.listTools().then(({ tools: s }) => {
          s.forEach((i) => n.push({ type: "tool", value: i }));
        })
      ), r != null && r.prompts && o.push(
        e.listPrompts().then(({ prompts: s }) => {
          s.forEach((i) => n.push({ type: "prompt", value: i }));
        })
      ), await Promise.all(o), Ae.debug(`Retrieved ${n.length} primitives`), n;
    } catch (r) {
      throw Ae.error("[WebSocketPlugin] Failed to get primitives:", r), this.isConnected() ? r : (this.isConnectedFlag = !1, new Error("WebSocket connection lost while getting primitives"));
    }
  }
  /**
   * Set a callback to be called when the WebSocket disconnects
   */
  setDisconnectionCallback(e) {
    this.disconnectionCallback = e;
  }
  /**
   * Handle disconnection events by notifying the main client
   */
  handleDisconnection(e, r, n) {
    if (Ae.debug(`Handling disconnection: ${e} (code: ${r}, details: ${n})`), this.disconnectionCallback)
      try {
        this.disconnectionCallback(e, r, n);
      } catch (o) {
        Ae.error("[WebSocketPlugin] Error in disconnection callback:", o);
      }
  }
}
var An = {};
/*!
 * content-type
 * Copyright(c) 2015 Douglas Christopher Wilson
 * MIT Licensed
 */
var ec;
function Dy() {
  if (ec) return An;
  ec = 1;
  var t = /; *([!#$%&'*+.^_`|~0-9A-Za-z-]+) *= *("(?:[\u000b\u0020\u0021\u0023-\u005b\u005d-\u007e\u0080-\u00ff]|\\[\u000b\u0020-\u00ff])*"|[!#$%&'*+.^_`|~0-9A-Za-z-]+) */g, e = /^[\u000b\u0020-\u007e\u0080-\u00ff]+$/, r = /^[!#$%&'*+.^_`|~0-9A-Za-z-]+$/, n = /\\([\u000b\u0020-\u00ff])/g, o = /([\\"])/g, s = /^[!#$%&'*+.^_`|~0-9A-Za-z-]+\/[!#$%&'*+.^_`|~0-9A-Za-z-]+$/;
  An.format = i, An.parse = a;
  function i(h) {
    if (!h || typeof h != "object")
      throw new TypeError("argument obj is required");
    var m = h.parameters, _ = h.type;
    if (!_ || !s.test(_))
      throw new TypeError("invalid type");
    var S = _;
    if (m && typeof m == "object")
      for (var $, v = Object.keys(m).sort(), y = 0; y < v.length; y++) {
        if ($ = v[y], !r.test($))
          throw new TypeError("invalid parameter name");
        S += "; " + $ + "=" + u(m[$]);
      }
    return S;
  }
  function a(h) {
    if (!h)
      throw new TypeError("argument string is required");
    var m = typeof h == "object" ? c(h) : h;
    if (typeof m != "string")
      throw new TypeError("argument string is required to be a string");
    var _ = m.indexOf(";"), S = _ !== -1 ? m.slice(0, _).trim() : m.trim();
    if (!s.test(S))
      throw new TypeError("invalid media type");
    var $ = new l(S.toLowerCase());
    if (_ !== -1) {
      var v, y, g;
      for (t.lastIndex = _; y = t.exec(m); ) {
        if (y.index !== _)
          throw new TypeError("invalid parameter format");
        _ += y[0].length, v = y[1].toLowerCase(), g = y[2], g.charCodeAt(0) === 34 && (g = g.slice(1, -1), g.indexOf("\\") !== -1 && (g = g.replace(n, "$1"))), $.parameters[v] = g;
      }
      if (_ !== m.length)
        throw new TypeError("invalid parameter format");
    }
    return $;
  }
  function c(h) {
    var m;
    if (typeof h.getHeader == "function" ? m = h.getHeader("content-type") : typeof h.headers == "object" && (m = h.headers && h.headers["content-type"]), typeof m != "string")
      throw new TypeError("content-type header is missing from object");
    return m;
  }
  function u(h) {
    var m = String(h);
    if (r.test(m))
      return m;
    if (m.length > 0 && !e.test(m))
      throw new TypeError("invalid parameter value");
    return '"' + m.replace(o, "\\$1") + '"';
  }
  function l(h) {
    this.parameters = /* @__PURE__ */ Object.create(null), this.type = h;
  }
  return An;
}
var Uy = Dy();
const Fy = /* @__PURE__ */ fs(Uy);
function Ly(t) {
  if (t)
    try {
      return Fy.parse(t).type;
    } catch {
      const e = (t.split(";", 1)[0] ?? "").trim().toLowerCase();
      return e === "" || t.slice(e.length).includes(",") ? void 0 : e;
    }
}
class Zy extends TransformStream {
  constructor({ onError: e, onRetry: r, onComment: n, maxBufferSize: o } = {}) {
    let s;
    super({
      start(i) {
        s = zu({
          onEvent: (a) => {
            i.enqueue(a);
          },
          onError(a) {
            typeof e == "function" && e(a), (e === "terminate" || a.type === "max-buffer-size-exceeded") && i.error(a);
          },
          onRetry: r,
          onComment: n,
          maxBufferSize: o
        });
      },
      transform(i) {
        s.feed(i);
      }
    });
  }
}
const Vy = {
  initialReconnectionDelay: 1e3,
  maxReconnectionDelay: 3e4,
  reconnectionDelayGrowFactor: 1.5,
  maxRetries: 2
};
class Xt extends Error {
  constructor(e, r) {
    super(`Streamable HTTP error: ${r}`), this.code = e;
  }
}
class Hy {
  constructor(e, r) {
    this._hasCompletedAuthFlow = !1, this._url = e, this._resourceMetadataUrl = void 0, this._scope = void 0, this._requestInit = r == null ? void 0 : r.requestInit, this._authProvider = r == null ? void 0 : r.authProvider, this._fetch = r == null ? void 0 : r.fetch, this._fetchWithInit = Mu(r == null ? void 0 : r.fetch, r == null ? void 0 : r.requestInit), this._sessionId = r == null ? void 0 : r.sessionId, this._reconnectionOptions = (r == null ? void 0 : r.reconnectionOptions) ?? Vy;
  }
  async _authThenStart() {
    var r;
    if (!this._authProvider)
      throw new mt("No auth provider");
    let e;
    try {
      e = await Bt(this._authProvider, {
        serverUrl: this._url,
        resourceMetadataUrl: this._resourceMetadataUrl,
        scope: this._scope,
        fetchFn: this._fetchWithInit
      });
    } catch (n) {
      throw (r = this.onerror) == null || r.call(this, n), n;
    }
    if (e !== "AUTHORIZED")
      throw new mt();
    return await this._startOrAuthSse({ resumptionToken: void 0 });
  }
  async _commonHeaders() {
    var n;
    const e = {};
    if (this._authProvider) {
      const o = await this._authProvider.tokens();
      o && (e.Authorization = `Bearer ${o.access_token}`);
    }
    this._sessionId && (e["mcp-session-id"] = this._sessionId), this._protocolVersion && (e["mcp-protocol-version"] = this._protocolVersion);
    const r = Zn((n = this._requestInit) == null ? void 0 : n.headers);
    return new Headers({
      ...e,
      ...r
    });
  }
  async _startOrAuthSse(e) {
    var n, o, s;
    const { resumptionToken: r } = e;
    try {
      const i = await this._commonHeaders();
      i.set("Accept", "text/event-stream"), r && i.set("last-event-id", r);
      const a = await (this._fetch ?? fetch)(this._url, {
        method: "GET",
        headers: i,
        signal: (n = this._abortController) == null ? void 0 : n.signal
      });
      if (!a.ok) {
        if (await ((o = a.body) == null ? void 0 : o.cancel()), a.status === 401 && this._authProvider)
          return await this._authThenStart();
        if (a.status === 405)
          return;
        throw new Xt(a.status, `Failed to open SSE stream: ${a.statusText}`);
      }
      this._handleSseStream(a.body, e, !0);
    } catch (i) {
      throw (s = this.onerror) == null || s.call(this, i), i;
    }
  }
  /**
   * Calculates the next reconnection delay using  backoff algorithm
   *
   * @param attempt Current reconnection attempt count for the specific stream
   * @returns Time to wait in milliseconds before next reconnection attempt
   */
  _getNextReconnectionDelay(e) {
    if (this._serverRetryMs !== void 0)
      return this._serverRetryMs;
    const r = this._reconnectionOptions.initialReconnectionDelay, n = this._reconnectionOptions.reconnectionDelayGrowFactor, o = this._reconnectionOptions.maxReconnectionDelay;
    return Math.min(r * Math.pow(n, e), o);
  }
  /**
   * Schedule a reconnection attempt using server-provided retry interval or backoff
   *
   * @param lastEventId The ID of the last received event for resumability
   * @param attemptCount Current reconnection attempt count for this specific stream
   */
  _scheduleReconnection(e, r = 0) {
    var s;
    const n = this._reconnectionOptions.maxRetries;
    if (r >= n) {
      (s = this.onerror) == null || s.call(this, new Error(`Maximum reconnection attempts (${n}) exceeded.`));
      return;
    }
    const o = this._getNextReconnectionDelay(r);
    this._reconnectionTimeout = setTimeout(() => {
      this._startOrAuthSse(e).catch((i) => {
        var a;
        (a = this.onerror) == null || a.call(this, new Error(`Failed to reconnect SSE stream: ${i instanceof Error ? i.message : String(i)}`)), this._scheduleReconnection(e, r + 1);
      });
    }, o);
  }
  _handleSseStream(e, r, n) {
    if (!e)
      return;
    const { onresumptiontoken: o, replayMessageId: s } = r;
    let i, a = !1, c = !1;
    (async () => {
      var l, h, m, _;
      try {
        const S = e.pipeThrough(new TextDecoderStream()).pipeThrough(new Zy({
          onRetry: (y) => {
            this._serverRetryMs = y;
          }
        })).getReader();
        for (; ; ) {
          const { value: y, done: g } = await S.read();
          if (g)
            break;
          if (y.id && (i = y.id, a = !0, o == null || o(y.id)), !!y.data && (!y.event || y.event === "message"))
            try {
              const w = In.parse(JSON.parse(y.data));
              br(w) && (c = !0, s !== void 0 && (w.id = s)), (l = this.onmessage) == null || l.call(this, w);
            } catch (w) {
              (h = this.onerror) == null || h.call(this, w);
            }
        }
        (n || a) && !c && this._abortController && !this._abortController.signal.aborted && this._scheduleReconnection({
          resumptionToken: i,
          onresumptiontoken: o,
          replayMessageId: s
        }, 0);
      } catch (S) {
        if ((m = this.onerror) == null || m.call(this, new Error(`SSE stream disconnected: ${S}`)), (n || a) && !c && this._abortController && !this._abortController.signal.aborted)
          try {
            this._scheduleReconnection({
              resumptionToken: i,
              onresumptiontoken: o,
              replayMessageId: s
            }, 0);
          } catch (y) {
            (_ = this.onerror) == null || _.call(this, new Error(`Failed to reconnect: ${y instanceof Error ? y.message : String(y)}`));
          }
      }
    })();
  }
  async start() {
    if (this._abortController)
      throw new Error("StreamableHTTPClientTransport already started! If using Client class, note that connect() calls start() automatically.");
    this._abortController = new AbortController();
  }
  /**
   * Call this method after the user has finished authorizing via their user agent and is redirected back to the MCP client application. This will exchange the authorization code for an access token, enabling the next connection attempt to successfully auth.
   */
  async finishAuth(e) {
    if (!this._authProvider)
      throw new mt("No auth provider");
    if (await Bt(this._authProvider, {
      serverUrl: this._url,
      authorizationCode: e,
      resourceMetadataUrl: this._resourceMetadataUrl,
      scope: this._scope,
      fetchFn: this._fetchWithInit
    }) !== "AUTHORIZED")
      throw new mt("Failed to authorize");
  }
  async close() {
    var e, r;
    this._reconnectionTimeout && (clearTimeout(this._reconnectionTimeout), this._reconnectionTimeout = void 0), (e = this._abortController) == null || e.abort(), (r = this.onclose) == null || r.call(this);
  }
  async send(e, r) {
    var n, o, s, i, a, c;
    try {
      const { resumptionToken: u, onresumptiontoken: l } = r || {};
      if (u) {
        this._startOrAuthSse({ resumptionToken: u, replayMessageId: Fo(e) ? e.id : void 0 }).catch((w) => {
          var k;
          return (k = this.onerror) == null ? void 0 : k.call(this, w);
        });
        return;
      }
      const h = await this._commonHeaders();
      h.set("content-type", "application/json"), h.set("accept", "application/json, text/event-stream");
      const m = {
        ...this._requestInit,
        method: "POST",
        headers: h,
        body: JSON.stringify(e),
        signal: (n = this._abortController) == null ? void 0 : n.signal
      }, _ = await (this._fetch ?? fetch)(this._url, m), S = _.headers.get("mcp-session-id");
      if (S && (this._sessionId = S), !_.ok) {
        const w = await _.text().catch(() => null);
        if (_.status === 401 && this._authProvider) {
          if (this._hasCompletedAuthFlow)
            throw new Xt(401, "Server returned 401 after successful authentication");
          const { resourceMetadataUrl: k, scope: f } = Gn(_);
          if (this._resourceMetadataUrl = k, this._scope = f, await Bt(this._authProvider, {
            serverUrl: this._url,
            resourceMetadataUrl: this._resourceMetadataUrl,
            scope: this._scope,
            fetchFn: this._fetchWithInit
          }) !== "AUTHORIZED")
            throw new mt();
          return this._hasCompletedAuthFlow = !0, this.send(e);
        }
        if (_.status === 403 && this._authProvider) {
          const { resourceMetadataUrl: k, scope: f, error: d } = Gn(_);
          if (d === "insufficient_scope") {
            const p = _.headers.get("WWW-Authenticate");
            if (this._lastUpscopingHeader === p)
              throw new Xt(403, "Server returned 403 after trying upscoping");
            if (f && (this._scope = f), k && (this._resourceMetadataUrl = k), this._lastUpscopingHeader = p ?? void 0, await Bt(this._authProvider, {
              serverUrl: this._url,
              resourceMetadataUrl: this._resourceMetadataUrl,
              scope: this._scope,
              fetchFn: this._fetch
            }) !== "AUTHORIZED")
              throw new mt();
            return this.send(e);
          }
        }
        throw new Xt(_.status, `Error POSTing to endpoint: ${w}`);
      }
      if (this._hasCompletedAuthFlow = !1, this._lastUpscopingHeader = void 0, _.status === 202) {
        await ((o = _.body) == null ? void 0 : o.cancel()), _m(e) && this._startOrAuthSse({ resumptionToken: void 0 }).catch((w) => {
          var k;
          return (k = this.onerror) == null ? void 0 : k.call(this, w);
        });
        return;
      }
      const v = (Array.isArray(e) ? e : [e]).filter((w) => "method" in w && "id" in w && w.id !== void 0).length > 0, y = _.headers.get("content-type"), g = Ly(y);
      if (v)
        if (g === "text/event-stream")
          this._handleSseStream(_.body, { onresumptiontoken: l }, !1);
        else if (g === "application/json") {
          const w = await _.json(), k = Array.isArray(w) ? w.map((f) => In.parse(f)) : [In.parse(w)];
          for (const f of k)
            (s = this.onmessage) == null || s.call(this, f);
        } else
          throw await ((i = _.body) == null ? void 0 : i.cancel()), new Xt(-1, `Unexpected content type: ${y}`);
      else
        await ((a = _.body) == null ? void 0 : a.cancel());
    } catch (u) {
      throw (c = this.onerror) == null || c.call(this, u), u;
    }
  }
  get sessionId() {
    return this._sessionId;
  }
  /**
   * Terminates the current session by sending a DELETE request to the server.
   *
   * Clients that no longer need a particular session
   * (e.g., because the user is leaving the client application) SHOULD send an
   * HTTP DELETE to the MCP endpoint with the Mcp-Session-Id header to explicitly
   * terminate the session.
   *
   * The server MAY respond with HTTP 405 Method Not Allowed, indicating that
   * the server does not allow clients to terminate sessions.
   */
  async terminateSession() {
    var e, r, n;
    if (this._sessionId)
      try {
        const o = await this._commonHeaders(), s = {
          ...this._requestInit,
          method: "DELETE",
          headers: o,
          signal: (e = this._abortController) == null ? void 0 : e.signal
        }, i = await (this._fetch ?? fetch)(this._url, s);
        if (await ((r = i.body) == null ? void 0 : r.cancel()), !i.ok && i.status !== 405)
          throw new Xt(i.status, `Failed to terminate session: ${i.statusText}`);
        this._sessionId = void 0;
      } catch (o) {
        throw (n = this.onerror) == null || n.call(this, o), o;
      }
  }
  setProtocolVersion(e) {
    this._protocolVersion = e;
  }
  get protocolVersion() {
    return this._protocolVersion;
  }
  /**
   * Resume an SSE stream from a previous event ID.
   * Opens a GET SSE connection with Last-Event-ID header to replay missed events.
   *
   * @param lastEventId The event ID to resume from
   * @param options Optional callback to receive new resumption tokens
   */
  async resumeStream(e, r) {
    await this._startOrAuthSse({
      resumptionToken: e,
      onresumptiontoken: r == null ? void 0 : r.onresumptiontoken
    });
  }
}
const ze = nt("StreamableHttpPlugin");
class Zu {
  constructor() {
    B(this, "metadata", {
      name: "StreamableHttpPlugin",
      version: "1.0.0",
      transportType: "streamable-http",
      description: "Streamable HTTP transport for MCP protocol",
      author: "Nyx Control"
    });
    B(this, "transport", null);
  }
  async initialize(e) {
    ze.debug("Initialized with config:", e);
  }
  async connect(e) {
    ze.debug(`Creating transport for: ${e}`);
    try {
      const r = await this.createConnection(e);
      return this.transport = r, ze.debug("[StreamableHttpPlugin] Transport created successfully"), r;
    } catch (r) {
      throw ze.error("[StreamableHttpPlugin] Transport creation failed:", r), r;
    }
  }
  async createConnection(e) {
    try {
      const r = new URL(e);
      ze.debug(`Creating Streamable HTTP transport for: ${r.toString()}`);
      const n = new Hy(r);
      return ze.debug("[StreamableHttpPlugin] Streamable HTTP transport created successfully"), n;
    } catch (r) {
      const n = r instanceof Error ? r.message : String(r);
      let o = n;
      throw n.includes("404") ? o = "Streamable HTTP endpoint not found (404). Verify the server URL and endpoint path." : n.includes("timeout") ? o = "Streamable HTTP connection timeout. The server may be slow or unreachable." : n.includes("Failed to fetch") ? o = "Streamable HTTP connection failed. Check if the server is running and accessible." : n.includes("protocol") && (o = "Streamable HTTP protocol error. The server may not support streamable HTTP."), new Error(`StreamableHttpPlugin: ${o}`);
    }
  }
  async disconnect() {
    if (ze.debug("[StreamableHttpPlugin] Disconnecting..."), this.transport)
      try {
        await this.transport.close();
      } catch (e) {
        ze.warn("[StreamableHttpPlugin] Error during transport cleanup:", e);
      }
    this.transport = null, ze.debug("[StreamableHttpPlugin] Disconnected");
  }
  isConnected() {
    return this.transport !== null;
  }
  isSupported(e) {
    try {
      const r = new URL(e);
      return r.protocol === "http:" || r.protocol === "https:";
    } catch {
      return !1;
    }
  }
  getDefaultConfig() {
    return {
      keepAlive: !0,
      connectionTimeout: 5e3,
      readTimeout: 3e4,
      fallbackToSSE: !1,
      maxRetries: 2
    };
  }
  async isHealthy() {
    if (!this.isConnected() || !this.transport)
      return !1;
    try {
      return !0;
    } catch (e) {
      return ze.warn("[StreamableHttpPlugin] Health check failed:", e), !1;
    }
  }
  async callTool(e, r, n) {
    if (!this.isConnected())
      throw new Error("StreamableHttpPlugin: Not connected");
    ze.debug(`Calling tool: ${r}`);
    try {
      const o = await e.callTool({ name: r, arguments: n });
      return ze.debug(`Tool call completed: ${r}`), o;
    } catch (o) {
      throw ze.error(`Tool call failed: ${r}`, o), o;
    }
  }
  async getPrimitives(e) {
    if (!this.isConnected())
      throw new Error("StreamableHttpPlugin: Not connected");
    ze.debug("[StreamableHttpPlugin] Getting primitives...");
    try {
      const r = e.getServerCapabilities(), n = [], o = [];
      return r != null && r.resources && o.push(
        e.listResources().then(({ resources: s }) => {
          s.forEach((i) => n.push({ type: "resource", value: i }));
        }).catch((s) => {
          ze.warn("[StreamableHttpPlugin] Failed to list resources:", s);
        })
      ), r != null && r.tools && o.push(
        e.listTools().then(({ tools: s }) => {
          s.forEach((i) => n.push({ type: "tool", value: i }));
        }).catch((s) => {
          ze.warn("[StreamableHttpPlugin] Failed to list tools:", s);
        })
      ), r != null && r.prompts && o.push(
        e.listPrompts().then(({ prompts: s }) => {
          s.forEach((i) => n.push({ type: "prompt", value: i }));
        }).catch((s) => {
          ze.warn("[StreamableHttpPlugin] Failed to list prompts:", s);
        })
      ), await Promise.all(o), ze.debug(`Retrieved ${n.length} primitives`), n;
    } catch (r) {
      return ze.error("[StreamableHttpPlugin] Failed to get primitives:", r), [];
    }
  }
}
const bt = nt("PluginRegistry");
class Wy extends Ou {
  constructor() {
    super();
    B(this, "plugins", /* @__PURE__ */ new Map());
    B(this, "initialized", /* @__PURE__ */ new Set());
    bt.debug("[PluginRegistry] Initialized");
  }
  async register(r) {
    const { transportType: n } = r.metadata;
    this.plugins.has(n) && bt.warn(`Plugin for transport '${n}' already registered, replacing`), this.plugins.set(n, r), bt.debug(
      `Registered plugin: ${r.metadata.name} v${r.metadata.version} (${n})`
    ), this.emit("registry:plugin-registered", { plugin: r });
  }
  unregister(r) {
    return this.plugins.get(r) ? (this.plugins.delete(r), this.initialized.delete(r), bt.debug(`Unregistered plugin for transport: ${r}`), this.emit("registry:plugin-unregistered", { type: r }), !0) : !1;
  }
  getPlugin(r) {
    return this.plugins.get(r);
  }
  async getInitializedPlugin(r, n) {
    const o = this.getPlugin(r);
    if (!o)
      throw new Error(`Plugin for transport '${r}' not found`);
    if (!this.initialized.has(r)) {
      const s = n || o.getDefaultConfig();
      await o.initialize(s), this.initialized.add(r), bt.debug(`Initialized plugin: ${r}`);
    }
    return o;
  }
  isPluginAvailable(r) {
    return this.plugins.has(r);
  }
  isPluginInitialized(r) {
    return this.initialized.has(r);
  }
  listAvailable() {
    return Array.from(this.plugins.keys());
  }
  listInitialized() {
    return Array.from(this.initialized);
  }
  getPluginInfo(r) {
    const n = this.plugins.get(r);
    return {
      available: !!n,
      initialized: this.initialized.has(r),
      metadata: n == null ? void 0 : n.metadata
    };
  }
  async loadDefaultPlugins() {
    bt.debug("[PluginRegistry] Loading default plugins...");
    try {
      await this.register(new Fu()), await this.register(new Lu()), await this.register(new Zu());
      const r = this.plugins.size;
      bt.debug(`Loaded ${r} default plugins`), this.emit("registry:plugins-loaded", { count: r });
    } catch (r) {
      throw bt.error("[PluginRegistry] Failed to load default plugins:", r), new Error(`Failed to load default plugins: ${r instanceof Error ? r.message : String(r)}`);
    }
  }
  clear() {
    this.plugins.clear(), this.initialized.clear(), bt.debug("[PluginRegistry] Cleared all plugins");
  }
  getStats() {
    return {
      totalPlugins: this.plugins.size,
      initializedPlugins: this.initialized.size,
      availableTypes: this.listAvailable(),
      initializedTypes: this.listInitialized()
    };
  }
}
const Mo = {
  defaultTransport: "sse",
  defaultUri: "http://localhost:3055/sse",
  plugins: {
    sse: {
      keepAlive: !0,
      connectionTimeout: 5e3,
      readTimeout: 3e4
    },
    websocket: {
      protocols: ["mcp-v1"],
      pingInterval: 3e4,
      pongTimeout: 5e3,
      maxReconnectAttempts: 3,
      binaryType: "arraybuffer"
    },
    "streamable-http": {
      keepAlive: !0,
      connectionTimeout: 5e3,
      readTimeout: 3e4,
      fallbackToSSE: !1,
      maxRetries: 2
    }
  },
  global: {
    timeout: 3e4,
    maxRetries: 3,
    healthCheckInterval: 6e4,
    reconnectDelay: 2e3,
    logLevel: "info"
  }
}, By = "G-GYKRZLYBXQ", Gy = "oVosLwqtS5u_lNpCrO_-_g", Ke = nt("AnalyticsService"), Ky = "https://www.google-analytics.com/mp/collect", tc = !("update_url" in chrome.runtime.getManifest()), Jy = Ky, Qy = 100, Xy = 30, rc = typeof window < "u";
async function Yy() {
  try {
    let e = (await chrome.storage.local.get("clientId")).clientId;
    return e || (e = self.crypto.randomUUID(), await chrome.storage.local.set({ clientId: e }), Ke.debug("[GA4] Generated new clientId:", e)), e;
  } catch (t) {
    return Ke.error("[GA4] Error getting or creating clientId:", t), "error-client-id";
  }
}
async function ev() {
  try {
    let { sessionData: t } = await chrome.storage.session.get("sessionData");
    const e = Date.now();
    return t && t.timestamp && ((e - t.timestamp) / 6e4 > Xy ? (t = null, Ke.debug("[GA4] Session expired, starting new one.")) : (t.timestamp = e, await chrome.storage.session.set({ sessionData: t }))), t || (t = {
      session_id: e.toString(),
      timestamp: e
      // Store timestamp as number
    }, await chrome.storage.session.set({ sessionData: t }), Ke.debug("[GA4] Created new session:", t.session_id)), t.session_id;
  } catch (t) {
    return Ke.error("[GA4] Error getting or creating session_id:", t), "error-session-id";
  }
}
async function Je(t, e, r) {
  try {
    const n = await Yy(), o = await ev(), s = {
      name: t,
      params: {
        session_id: o,
        engagement_time_msec: Qy,
        ...e
        // Spread user-provided params
      }
    }, i = {
      client_id: n,
      events: [s]
    };
    r && (i.user_properties = r), Ke.debug(`[GA4] Sending event: ${t}`, JSON.stringify(e));
    const a = await fetch(`${Jy}?measurement_id=${By}&api_secret=${Gy}`, {
      method: "POST",
      body: JSON.stringify(i),
      headers: {
        "Content-Type": "application/json"
      }
    });
    if (a.ok) {
      if (Ke.debug("[GA4] Event sent successfully."), tc && a.status !== 204)
        try {
          const c = await a.json();
          Ke.debug("[GA4] Debug endpoint success response:", JSON.stringify(c, null, 2));
        } catch {
          Ke.debug("[GA4] Debug endpoint success response likely had no body (e.g., 200 OK with empty body).");
        }
    } else if (Ke.warn(`[GA4] Analytics request failed: ${a.status} ${a.statusText}`), tc)
      try {
        const c = await a.json();
        Ke.error("[GA4] Debug endpoint error response:", JSON.stringify(c, null, 2));
      } catch {
        Ke.error("[GA4] Debug endpoint error response could not be parsed as JSON:", await a.text());
      }
  } catch (n) {
    Ke.error("[GA4] Error sending analytics event:", n);
  }
}
function cs() {
  try {
    const t = (navigator == null ? void 0 : navigator.userAgent) || "Unknown", e = (navigator == null ? void 0 : navigator.language) || "en";
    let r = "Unknown", n = "Unknown", o = "Unknown", s = "Unknown";
    if (t.indexOf("Firefox") > -1) {
      r = "Firefox";
      const m = t.match(/Firefox\/(\d+\.\d+)/);
      n = m && m[1] ? m[1] : "Unknown";
    } else if (t.indexOf("Edg") > -1) {
      r = "Edge";
      const m = t.match(/Edg\/(\d+\.\d+)/);
      n = m && m[1] ? m[1] : "Unknown";
    } else if (t.indexOf("Chrome") > -1) {
      r = "Chrome";
      const m = t.match(/Chrome\/(\d+\.\d+)/);
      n = m && m[1] ? m[1] : "Unknown";
    } else if (t.indexOf("Safari") > -1) {
      r = "Safari";
      const m = t.match(/Version\/(\d+\.\d+)/);
      n = m && m[1] ? m[1] : "Unknown";
    } else if (t.indexOf("MSIE") > -1 || t.indexOf("Trident/") > -1) {
      r = "Internet Explorer";
      const m = t.match(/(?:MSIE |rv:)(\d+\.\d+)/);
      n = m && m[1] ? m[1] : "Unknown";
    }
    if (t.indexOf("Windows") > -1) {
      o = "Windows";
      const m = t.match(/Windows NT (\d+\.\d+)/), _ = m && m[1] ? m[1] : "Unknown";
      s = {
        "10.0": "10/11",
        "6.3": "8.1",
        "6.2": "8",
        "6.1": "7",
        "6.0": "Vista",
        "5.2": "XP x64",
        "5.1": "XP"
      }[_] || _;
    } else if (t.indexOf("Mac") > -1) {
      o = "macOS";
      const m = t.match(/Mac OS X ([\d_]+)/);
      s = m && m[1] ? m[1].replace(/_/g, ".") : "Unknown";
    } else if (t.indexOf("Linux") > -1) {
      o = "Linux";
      const m = t.match(/Linux ([\w\d\.]+)/);
      s = m && m[1] ? m[1] : "Unknown";
    } else if (t.indexOf("Android") > -1) {
      o = "Android";
      const m = t.match(/Android ([\d\.]+)/);
      s = m && m[1] ? m[1] : "Unknown";
    } else if (t.indexOf("iOS") > -1 || t.indexOf("iPhone") > -1 || t.indexOf("iPad") > -1) {
      o = "iOS";
      const m = t.match(/OS ([\d_]+)/);
      s = m && m[1] ? m[1].replace(/_/g, ".") : "Unknown";
    }
    let i = "desktop";
    /Mobi|Android|iPhone|iPad|iPod/i.test(t) && (i = /iPad|tablet/i.test(t) ? "tablet" : "mobile");
    const a = e.split("-")[1] || e;
    let c = "Unknown", u = 1, l = "Unknown", h = 0;
    if (rc && typeof window < "u")
      try {
        c = `${window.screen.width}x${window.screen.height}`, u = window.devicePixelRatio || 1, l = Intl.DateTimeFormat().resolvedOptions().timeZone, h = (/* @__PURE__ */ new Date()).getTimezoneOffset() / -60;
      } catch (m) {
        Ke.debug("[GA4] Window-dependent features not available:", m);
      }
    return {
      browser: r,
      browser_version: n,
      operating_system: o,
      os_version: s,
      language: e,
      region: a,
      screen_resolution: c,
      pixel_ratio: u,
      device_type: i,
      timezone: l,
      timezone_offset: h,
      user_agent: t,
      context: rc ? "content_script" : "background_service_worker"
    };
  } catch (t) {
    return Ke.error("[GA4] Error collecting demographic data:", t), {
      browser: "Unknown",
      browser_version: "Unknown",
      operating_system: "Unknown",
      os_version: "Unknown",
      language: "en",
      region: "Unknown",
      screen_resolution: "Unknown",
      pixel_ratio: 1,
      device_type: "desktop",
      timezone: "Unknown",
      timezone_offset: 0,
      user_agent: "Unknown",
      context: "error",
      error: "Failed to collect demographic data"
    };
  }
}
async function Vu(t, e) {
  var r;
  await Je("extension_error", {
    error_message: t.message,
    error_stack: (r = t.stack) == null ? void 0 : r.substring(0, 500),
    // Limit stack trace length
    error_context: e
  });
}
const Dt = nt("AnalyticsService"), Wt = class Wt {
  // 2 seconds
  constructor() {
    // Session state
    B(this, "sessionStartTime", Date.now());
    B(this, "sessionToolExecutions", 0);
    B(this, "sessionUniqueTools", /* @__PURE__ */ new Set());
    B(this, "sessionAdapters", /* @__PURE__ */ new Set());
    B(this, "sessionConnections", 0);
    B(this, "sessionErrors", 0);
    B(this, "lastUserAction", "none");
    // User properties cache
    B(this, "userProperties", {});
    B(this, "demographicData", {});
    // Connection state
    B(this, "currentConnectionStatus", "disconnected");
    B(this, "connectionStartTime", null);
    B(this, "currentTransportType", null);
    B(this, "toolsAvailableCount", 0);
    // Active adapter
    B(this, "activeAdapter", null);
    // Debouncing for connection events
    B(this, "lastConnectionTrackTime", 0);
    B(this, "CONNECTION_TRACK_DEBOUNCE", 2e3);
    this.initialize();
  }
  static getInstance() {
    return Wt.instance || (Wt.instance = new Wt()), Wt.instance;
  }
  /**
   * Initialize analytics service with user properties
   */
  async initialize() {
    try {
      const e = await chrome.storage.local.get([
        "installDate",
        "version",
        "userProperties",
        "ga4UserPropertiesSet"
      ]);
      this.demographicData = cs(), this.userProperties = {
        extension_version: chrome.runtime.getManifest().version,
        install_date: e.installDate || (/* @__PURE__ */ new Date()).toISOString(),
        ...this.demographicData,
        ...e.userProperties || {}
      }, Dt.debug("[AnalyticsService] Initialized with user properties:", this.userProperties), e.ga4UserPropertiesSet || (await this.setGA4UserProperties(), await chrome.storage.local.set({ ga4UserPropertiesSet: !0 }));
    } catch (e) {
      Dt.error("[AnalyticsService] Initialization failed:", e);
    }
  }
  /**
   * Set GA4 user properties (called once on first launch)
   * These are static demographics that don't change and will be available in all GA4 reports
   */
  async setGA4UserProperties() {
    try {
      const e = {
        extension_version: { value: this.userProperties.extension_version },
        install_date: { value: this.userProperties.install_date },
        browser: { value: this.demographicData.browser },
        browser_version: { value: this.demographicData.browser_version },
        operating_system: { value: this.demographicData.operating_system },
        os_version: { value: this.demographicData.os_version },
        device_type: { value: this.demographicData.device_type },
        language: { value: this.demographicData.language },
        region: { value: this.demographicData.region },
        screen_resolution: { value: this.demographicData.screen_resolution },
        pixel_ratio: { value: this.demographicData.pixel_ratio },
        timezone: { value: this.demographicData.timezone },
        timezone_offset: { value: this.demographicData.timezone_offset }
      };
      await Je("user_properties_initialized", {}, e), Dt.debug("[AnalyticsService] GA4 user properties set successfully");
    } catch (e) {
      Dt.error("[AnalyticsService] Failed to set GA4 user properties:", e);
    }
  }
  /**
   * Get common event parameters that should be included in all events
   * Note: Static demographics (browser, OS, etc.) are set as GA4 user properties
   * and don't need to be included in every event.
   */
  getCommonParameters() {
    return {
      // Dynamic/session-specific fields only
      extension_version: this.userProperties.extension_version,
      // Can change on update
      session_duration_ms: Date.now() - this.sessionStartTime,
      // Increases over time
      user_segment: this.getUserSegment(),
      // Changes with usage
      days_since_install: this.getDaysSinceInstall()
      // Increases daily
    };
  }
  /**
   * Track tool execution with enhanced context
   */
  async trackToolExecution(e) {
    const r = this.sessionToolExecutions === 0;
    this.sessionToolExecutions++, this.sessionUniqueTools.add(e.tool_name);
    const n = e.adapter_name || this.activeAdapter || "none";
    await Je("mcp_tool_executed", {
      ...e,
      ...this.getCommonParameters(),
      connection_status: this.currentConnectionStatus,
      active_adapter: n,
      // Use adapter name from content script
      tools_available_count: this.toolsAvailableCount,
      session_tool_count: this.sessionToolExecutions,
      is_first_tool_execution: r,
      unique_tools_used: this.sessionUniqueTools.size
    }), e.execution_status === "error" && this.sessionErrors++;
  }
  /**
   * Track connection status changes
   */
  async trackConnectionChange(e) {
    const r = Date.now();
    if (!(e.tools_discovered && e.tools_discovered > 0 && this.toolsAvailableCount === 0) && r - this.lastConnectionTrackTime < this.CONNECTION_TRACK_DEBOUNCE) {
      Dt.debug("[AnalyticsService] Connection event debounced (too soon after last event)"), this.currentConnectionStatus = e.connection_status, this.currentTransportType = e.transport_type, e.tools_discovered && (this.toolsAvailableCount = e.tools_discovered);
      return;
    }
    this.lastConnectionTrackTime = r;
    const o = this.currentConnectionStatus, s = this.connectionStartTime ? Date.now() - this.connectionStartTime : 0;
    this.currentConnectionStatus = e.connection_status, this.currentTransportType = e.transport_type, e.connection_status === "connected" ? (this.connectionStartTime = Date.now(), this.sessionConnections++, this.toolsAvailableCount = e.tools_discovered || 0) : e.connection_status === "disconnected" && (this.connectionStartTime = null, this.toolsAvailableCount = 0), await Je("mcp_connection_changed", {
      ...e,
      ...this.getCommonParameters(),
      previous_status: o,
      connection_duration_ms: s,
      session_connections_count: this.sessionConnections,
      active_adapter: this.activeAdapter || "none"
    }), e.connection_status === "error" && this.sessionErrors++;
  }
  /**
   * Track adapter activation
   */
  async trackAdapterActivation(e) {
    const r = this.activeAdapter;
    this.activeAdapter = e.adapter_name, this.sessionAdapters.add(e.adapter_name), this.toolsAvailableCount = e.tools_available, await Je("adapter_activated", {
      ...e,
      ...this.getCommonParameters(),
      previous_adapter: r || "none",
      session_adapter_switches: this.sessionAdapters.size,
      connection_status: this.currentConnectionStatus
    });
  }
  /**
   * Track feature usage
   */
  async trackFeatureUsage(e) {
    this.lastUserAction = e.feature_name, await Je("feature_used", {
      ...e,
      ...this.getCommonParameters(),
      active_adapter: this.activeAdapter || "none",
      connection_status: this.currentConnectionStatus,
      tools_available: this.toolsAvailableCount
    });
  }
  /**
   * Track enhanced error with context
   */
  async trackError(e) {
    var r;
    this.sessionErrors++, await Je("extension_error", {
      ...e,
      ...this.getCommonParameters(),
      error_stack: (r = e.error_stack) == null ? void 0 : r.substring(0, 500),
      // Limit stack trace
      user_action_before_error: this.lastUserAction,
      tools_available_when_error: this.toolsAvailableCount,
      connection_status: this.currentConnectionStatus,
      active_adapter: this.activeAdapter || "none",
      session_errors_count: this.sessionErrors
    });
  }
  /**
   * Track session summary (call on extension unload or periodically)
   */
  async trackSessionSummary() {
    const e = Date.now() - this.sessionStartTime;
    await Je("session_summary", {
      ...this.getCommonParameters(),
      session_duration_ms: e,
      tools_executed_count: this.sessionToolExecutions,
      unique_tools_used: this.sessionUniqueTools.size,
      unique_adapters_used: this.sessionAdapters.size,
      adapters_activated: Array.from(this.sessionAdapters),
      connections_made: this.sessionConnections,
      errors_encountered: this.sessionErrors,
      final_connection_status: this.currentConnectionStatus
    });
  }
  /**
   * Update user properties (call on extension install/update)
   */
  async updateUserProperties(e) {
    this.userProperties = {
      ...this.userProperties,
      ...e
    }, await chrome.storage.local.set({ userProperties: this.userProperties }), Dt.debug("[AnalyticsService] User properties updated:", this.userProperties);
  }
  /**
   * Reset session state (call on new session start)
   */
  resetSession() {
    this.sessionStartTime = Date.now(), this.sessionToolExecutions = 0, this.sessionUniqueTools.clear(), this.sessionAdapters.clear(), this.sessionConnections = 0, this.sessionErrors = 0, this.lastUserAction = "none", Dt.debug("[AnalyticsService] Session reset");
  }
  /**
   * Get days since installation
   */
  getDaysSinceInstall() {
    const e = this.userProperties.install_date;
    if (!e) return 0;
    const r = new Date(e).getTime(), n = Date.now();
    return Math.floor((n - r) / (1e3 * 60 * 60 * 24));
  }
  /**
   * Determine user segment based on usage patterns
   */
  getUserSegment() {
    const e = this.getDaysSinceInstall(), r = this.sessionToolExecutions;
    return e < 7 ? "new_user" : e < 30 ? r > 20 ? "engaged_new_user" : "recent_user" : r > 100 ? "power_user" : r > 30 ? "active_user" : r > 5 ? "regular_user" : "casual_user";
  }
  /**
   * Get current session state (for debugging)
   */
  getSessionState() {
    return {
      sessionDuration: Date.now() - this.sessionStartTime,
      toolExecutions: this.sessionToolExecutions,
      uniqueTools: this.sessionUniqueTools.size,
      adapters: Array.from(this.sessionAdapters),
      connections: this.sessionConnections,
      errors: this.sessionErrors,
      connectionStatus: this.currentConnectionStatus,
      activeAdapter: this.activeAdapter,
      toolsAvailable: this.toolsAvailableCount,
      userSegment: this.getUserSegment(),
      daysSinceInstall: this.getDaysSinceInstall()
    };
  }
};
B(Wt, "instance", null);
let us = Wt;
const Zt = us.getInstance(), ne = nt("McpClient");
class nc extends Ou {
  // 5 minutes
  constructor(r = {}) {
    super();
    B(this, "registry");
    B(this, "config");
    B(this, "client", null);
    B(this, "activePlugin", null);
    B(this, "activeTransport", null);
    B(this, "isConnectedFlag", !1);
    B(this, "connectionPromise", null);
    B(this, "healthCheckTimer", null);
    B(this, "primitivesCache", null);
    B(this, "primitivesCacheTime", 0);
    B(this, "CACHE_TTL", 3e5);
    this.config = {
      ...Mo,
      ...r,
      global: {
        ...Mo.global,
        ...r.global
      },
      plugins: {
        ...Mo.plugins,
        ...r.plugins
      }
    }, this.registry = new Wy(), this.registry.on("registry:plugin-registered", (n) => {
      this.emit("registry:plugin-registered", n);
    }), this.registry.on("registry:plugins-loaded", (n) => {
      this.emit("registry:plugins-loaded", n);
    }), ne.debug("[McpClient] Initialized with config:", this.config), this.emit("client:initialized", { config: this.config });
  }
  async initialize() {
    try {
      ne.debug("[McpClient] Loading default plugins..."), await this.registry.loadDefaultPlugins(), ne.debug("[McpClient] Initialization complete");
    } catch (r) {
      ne.error("[McpClient] Initialization failed:", r), ne.debug("[McpClient] Attempting manual plugin registration as fallback...");
      try {
        await this.manualPluginRegistration(), ne.debug("[McpClient] Manual plugin registration successful");
      } catch (n) {
        throw ne.error("[McpClient] Manual plugin registration also failed:", n), r;
      }
    }
  }
  async manualPluginRegistration() {
    await this.registry.register(new Fu()), await this.registry.register(new Lu()), await this.registry.register(new Zu()), ne.debug("[McpClient] Manual plugin registration completed");
  }
  async connect(r) {
    var n, o, s, i;
    if (this.isConnectedFlag && ((n = this.activePlugin) == null ? void 0 : n.metadata.transportType) === r.type) {
      ne.debug(`Already connected via ${r.type}, skipping`);
      return;
    }
    if (this.connectionPromise) {
      ne.debug("[McpClient] Connection already in progress, waiting...");
      try {
        if (await this.connectionPromise, this.isConnectedFlag && ((o = this.activePlugin) == null ? void 0 : o.metadata.transportType) === r.type) {
          ne.debug("[McpClient] Existing connection matches request");
          return;
        }
      } catch {
        ne.debug("[McpClient] Previous connection failed, starting new one"), this.connectionPromise = null;
      }
    }
    this.isConnectedFlag && ((s = this.activePlugin) == null ? void 0 : s.metadata.transportType) !== r.type && (ne.debug(`Switching from ${(i = this.activePlugin) == null ? void 0 : i.metadata.transportType} to ${r.type}`), await this.disconnect()), this.connectionPromise = this.performConnection(r);
    try {
      await this.connectionPromise;
    } finally {
      this.connectionPromise = null;
    }
  }
  async performConnection(r) {
    const { uri: n, type: o, config: s } = r;
    try {
      ne.debug(`Connecting to ${n} via ${o}`), this.emit("client:connecting", { uri: n, type: o }), this.isConnectedFlag && await this.disconnect();
      const i = {
        ...this.config.plugins[o],
        ...s
      }, a = await this.registry.getInitializedPlugin(o, i);
      if (!a.isSupported(n))
        throw new Error(`Plugin ${o} does not support URI: ${n}`);
      const c = await a.connect(n);
      o === "websocket" && "setDisconnectionCallback" in a && a.setDisconnectionCallback((m, _, S) => {
        ne.debug(`WebSocket disconnection detected: ${m} (code: ${_})`), this.isConnectedFlag = !1, this.emit("connection:status-changed", {
          isConnected: !1,
          type: "websocket",
          error: `WebSocket disconnected: ${m}${_ ? ` (code: ${_})` : ""}${S ? ` - ${S}` : ""}`
        }), this.cleanup().catch(($) => {
          ne.error("[McpClient] Error during cleanup after WebSocket disconnection:", $);
        });
      }), this.client = new X_(
        {
          name: `mcp-client-${o}`,
          version: "1.0.0"
        },
        { capabilities: {} }
      ), this.client.setNotificationHandler(_u, (m) => {
        ne.debug("Server log:", m.params.data);
      }), ne.debug("Starting MCP client connection to transport...");
      const u = 3e4, l = this.client.connect(c), h = new Promise((m, _) => {
        setTimeout(() => {
          _(new Error(`MCP client connection timeout after ${u}ms`));
        }, u);
      });
      await Promise.race([l, h]), ne.debug("MCP client connected successfully"), this.activePlugin = a, this.activeTransport = c, this.isConnectedFlag = !0, this.clearPrimitivesCache(), this.startHealthMonitoring(), ne.debug(`Successfully connected via ${o}`), this.emit("client:connected", { uri: n, type: o }), this.emit("connection:status-changed", {
        isConnected: !0,
        type: o,
        error: void 0
      }), Zt.trackConnectionChange({
        connection_status: "connected",
        transport_type: o,
        tools_discovered: 0
        // Will be updated after getPrimitives
      }).catch((m) => {
        ne.warn("[McpClient] Analytics tracking failed:", m);
      });
    } catch (i) {
      const a = i instanceof Error ? i.message : String(i);
      throw ne.error("Connection failed:", i), await this.cleanup(), this.emit("client:error", {
        error: i instanceof Error ? i : new Error(a),
        context: "connection"
      }), this.emit("connection:status-changed", {
        isConnected: !1,
        type: o,
        error: a
      }), Zt.trackConnectionChange({
        connection_status: "error",
        transport_type: o,
        error_type: i instanceof Error ? i.name : "UnknownError"
      }).catch((c) => {
        ne.warn("[McpClient] Analytics tracking failed:", c);
      }), i;
    }
  }
  async disconnect() {
    var n;
    if (!this.isConnectedFlag) {
      ne.debug("[McpClient] Already disconnected");
      return;
    }
    const r = (n = this.activePlugin) == null ? void 0 : n.metadata.transportType;
    ne.debug(`Disconnecting from ${r || "unknown"}`), r && this.emit("client:disconnecting", { type: r });
    try {
      await this.cleanup(), ne.debug("[McpClient] Disconnected successfully"), r && this.emit("client:disconnected", { type: r }), this.emit("connection:status-changed", {
        isConnected: !1,
        type: r || null
      });
    } catch (o) {
      ne.error("[McpClient] Error during disconnect:", o), this.emit("client:error", {
        error: o instanceof Error ? o : new Error(String(o)),
        context: "disconnect"
      });
    }
  }
  async cleanup() {
    if (this.stopHealthMonitoring(), this.client) {
      try {
        await this.client.close();
      } catch (r) {
        ne.warn("[McpClient] Error closing client:", r);
      }
      this.client = null;
    }
    if (this.activePlugin) {
      try {
        await this.activePlugin.disconnect();
      } catch (r) {
        ne.warn("[McpClient] Error disconnecting plugin:", r);
      }
      this.activePlugin = null;
    }
    this.activeTransport = null, this.isConnectedFlag = !1, this.clearPrimitivesCache();
  }
  async callTool(r, n, o) {
    var i, a, c;
    if (!this.isConnectedFlag || !this.activePlugin || !this.client)
      throw new Error("Not connected to any MCP server");
    const s = Date.now();
    this.emit("tool:call-started", { toolName: r, args: n });
    try {
      ne.debug(`Calling tool: ${r}`);
      const u = await this.activePlugin.callTool(this.client, r, n), l = Date.now() - s;
      return this.emit("tool:call-completed", { toolName: r, result: u, duration: l }), Zt.trackToolExecution({
        tool_name: r,
        execution_status: "success",
        execution_duration_ms: l,
        transport_type: ((i = this.activePlugin) == null ? void 0 : i.metadata.transportType) || "unknown",
        adapter_name: o
        // Pass adapter name from content script
      }).catch((h) => {
        ne.warn("[McpClient] Analytics tracking failed:", h);
      }), u;
    } catch (u) {
      const l = Date.now() - s, h = u instanceof Error ? u : new Error(String(u));
      throw this.emit("tool:call-failed", { toolName: r, error: h, duration: l }), Zt.trackToolExecution({
        tool_name: r,
        execution_status: "error",
        execution_duration_ms: l,
        transport_type: ((a = this.activePlugin) == null ? void 0 : a.metadata.transportType) || "unknown",
        error_type: h.name || "UnknownError",
        adapter_name: o
        // Pass adapter name from content script
      }).catch((m) => {
        ne.warn("[McpClient] Analytics tracking failed:", m);
      }), await this.isHealthy() || (this.isConnectedFlag = !1, this.emit("connection:status-changed", {
        isConnected: !1,
        type: ((c = this.activePlugin) == null ? void 0 : c.metadata.transportType) || null,
        error: "Connection lost during tool call"
      })), h;
    }
  }
  async getPrimitives(r = !1) {
    var n;
    if (!this.isConnectedFlag || !this.activePlugin || !this.client)
      throw new Error("Not connected to any MCP server");
    if (!r && this.primitivesCache && this.isCacheValid())
      return ne.debug("[McpClient] Returning cached primitives"), this.primitivesCache;
    try {
      ne.debug("[McpClient] Fetching primitives from server...");
      const o = await this.activePlugin.getPrimitives(this.client), s = this.normalizeTools(o.filter((u) => u.type === "tool")), i = o.filter((u) => u.type === "resource").map((u) => u.value), a = o.filter((u) => u.type === "prompt").map((u) => u.value), c = {
        tools: s,
        resources: i,
        prompts: a,
        timestamp: Date.now()
      };
      return this.primitivesCache = c, this.primitivesCacheTime = Date.now(), this.emit("tools:list-updated", {
        tools: s,
        type: this.activePlugin.metadata.transportType
      }), (this.primitivesCache === null || this.primitivesCache.tools.length === 0) && Zt.trackConnectionChange({
        connection_status: "connected",
        transport_type: this.activePlugin.metadata.transportType,
        tools_discovered: s.length
      }).catch((u) => {
        ne.warn("[McpClient] Analytics tracking failed:", u);
      }), ne.debug(
        `Retrieved ${s.length} tools, ${i.length} resources, ${a.length} prompts`
      ), c;
    } catch (o) {
      throw ne.error("[McpClient] Failed to get primitives:", o), await this.isHealthy() || (this.isConnectedFlag = !1, this.emit("connection:status-changed", {
        isConnected: !1,
        type: ((n = this.activePlugin) == null ? void 0 : n.metadata.transportType) || null,
        error: "Connection lost while getting primitives"
      })), o;
    }
  }
  normalizeTools(r) {
    return r.map((n) => {
      const o = n.value;
      let s = o.inputSchema || o.input_schema;
      return (typeof s != "object" || s === null || Array.isArray(s)) && (s = { type: "object" }, ne.debug(`[McpClient] Invalid schema for tool: ${o.name}, using default`)), s.type || (ne.debug(`[McpClient] Adding missing 'type' to schema for tool: ${o.name}`), s = { ...s, type: "object" }), {
        name: o.name,
        description: o.description || "",
        input_schema: s,
        schema: JSON.stringify(s),
        ...o.uri && { uri: o.uri },
        ...o.arguments && { arguments: o.arguments }
      };
    });
  }
  clearPrimitivesCache() {
    this.primitivesCache = null, this.primitivesCacheTime = 0;
  }
  isCacheValid() {
    return Date.now() - this.primitivesCacheTime < this.CACHE_TTL;
  }
  async isHealthy() {
    if (!this.isConnectedFlag || !this.activePlugin)
      return !1;
    try {
      return await this.activePlugin.isHealthy();
    } catch (r) {
      return ne.warn("[McpClient] Health check failed:", r), !1;
    }
  }
  isConnected() {
    var r;
    return this.isConnectedFlag && ((r = this.activePlugin) == null ? void 0 : r.isConnected()) === !0;
  }
  getConnectionInfo() {
    var r, n;
    return {
      isConnected: this.isConnectedFlag,
      type: ((r = this.activePlugin) == null ? void 0 : r.metadata.transportType) || null,
      uri: null,
      // Could store this if needed
      pluginInfo: ((n = this.activePlugin) == null ? void 0 : n.metadata) || null
    };
  }
  getAvailableTransports() {
    return this.registry.listAvailable();
  }
  async switchTransport(r) {
    var o;
    const n = ((o = this.activePlugin) == null ? void 0 : o.metadata.transportType) || null;
    n === r.type ? ne.debug(`Already using ${r.type}, reconnecting...`) : (ne.debug(`Switching from ${n} to ${r.type}`), this.emit("client:plugin-switched", { from: n, to: r.type })), await this.connect(r);
  }
  startHealthMonitoring() {
    const r = this.config.global.healthCheckInterval;
    r <= 0 || (this.healthCheckTimer = setInterval(async () => {
      var n;
      if (!this.isConnectedFlag) {
        this.stopHealthMonitoring();
        return;
      }
      try {
        const o = await this.isHealthy(), s = ((n = this.activePlugin) == null ? void 0 : n.metadata.transportType) || null;
        s && this.emit("connection:health-check", {
          healthy: o,
          type: s,
          timestamp: Date.now()
        }), o || (ne.warn(`Health check failed for ${s}`), this.isConnectedFlag = !1, this.emit("connection:status-changed", {
          isConnected: !1,
          type: s,
          error: "Health check failed"
        }));
      } catch (o) {
        ne.error("[McpClient] Health check error:", o);
      }
    }, r));
  }
  stopHealthMonitoring() {
    this.healthCheckTimer && (clearInterval(this.healthCheckTimer), this.healthCheckTimer = null);
  }
  getConfig() {
    return { ...this.config };
  }
  updateConfig(r) {
    this.config = {
      ...this.config,
      ...r,
      global: {
        ...this.config.global,
        ...r.global
      },
      plugins: {
        ...this.config.plugins,
        ...r.plugins
      }
    }, ne.debug("[McpClient] Configuration updated");
  }
}
const Et = nt("mcp_client");
let at = null;
async function Dr() {
  if (!at)
    try {
      at = new nc(), await at.initialize(), oc(at);
    } catch (t) {
      Et.error("[getGlobalClient] Failed to initialize client:", t), at = new nc(), oc(at);
    }
  return at;
}
function oc(t) {
  t.on("connection:status-changed", (e) => {
    Et.debug("[Global Client] Connection status changed:", e), typeof window < "u" && window.dispatchEvent && window.dispatchEvent(new CustomEvent("mcp:connection-status-changed", {
      detail: e
    })), typeof chrome < "u" && chrome.runtime && chrome.runtime.sendMessage && chrome.runtime.sendMessage({
      type: "mcp:connection-status-changed",
      payload: e,
      origin: "mcpclient"
    }).catch(() => {
    });
  }), t.on("client:connected", (e) => {
    Et.debug("[Global Client] Client connected:", e);
  }), t.on("client:disconnected", (e) => {
    Et.debug("[Global Client] Client disconnected:", e);
  }), t.on("client:error", (e) => {
    Et.error("[Global Client] Client error:", e);
  });
}
function co(t) {
  try {
    const e = new URL(t);
    return e.protocol === "ws:" || e.protocol === "wss:" ? "websocket" : "sse";
  } catch {
    return "sse";
  }
}
function tv() {
  return at ? at.isConnected() : !1;
}
async function Vt() {
  try {
    return await (await Dr()).isHealthy();
  } catch (t) {
    return Et.error("[Backward Compatibility] checkMcpServerConnection failed:", t), !1;
  }
}
async function rv(t, e, r, n, o) {
  const s = await Dr(), i = o || co(t);
  return s.isConnected() || await s.connect({ uri: t, type: i }), await s.callTool(e, r, n);
}
async function cr(t, e = !1, r) {
  const n = await Dr(), o = r || co(t);
  n.isConnected() || await n.connect({ uri: t, type: o });
  const s = await n.getPrimitives(e), i = [];
  return s.tools.forEach((a) => {
    i.push({ type: "tool", value: a });
  }), s.resources.forEach((a) => {
    i.push({ type: "resource", value: a });
  }), s.prompts.forEach((a) => {
    i.push({ type: "prompt", value: a });
  }), i;
}
async function sc(t, e) {
  const r = await Dr(), n = e || co(t);
  r.isConnected() && await r.disconnect(), await r.connect({ uri: t, type: n });
}
async function nv(t, e) {
  const r = await Dr(), n = e || co(t);
  await r.connect({ uri: t, type: n });
  const o = await r.getPrimitives();
  Et.debug(`Connected, found ${o.tools.length} tools, ${o.resources.length} resources, ${o.prompts.length} prompts`);
}
function ov() {
  at && at.isConnected() && at.disconnect().catch((t) => {
    Et.error("[Backward Compatibility] resetMcpConnectionState failed:", t);
  });
}
function sv() {
  Et.debug("[Backward Compatibility] resetMcpConnectionStateForRecovery - handled by plugin health monitoring");
}
function ur(t) {
  return t.filter((e) => e.type === "tool").map((e) => {
    const r = e.value;
    return {
      name: r.name,
      description: r.description || "",
      input_schema: r.inputSchema || r.input_schema || {},
      schema: r.inputSchema ? JSON.stringify(r.inputSchema) : r.input_schema ? JSON.stringify(r.input_schema) : "{}",
      ...r.uri && { uri: r.uri },
      ...r.arguments && { arguments: r.arguments }
    };
  });
}
const Z = nt("BACKGROUND"), Hu = "http://localhost:3055/sse", Wu = "ws://localhost:3055/message", Kn = "http://localhost:3057/mcp", ls = "streamable-http";
let Me = null, Cr = Kn, Re = ls, Bu = !1, ds = !1;
async function iv() {
  try {
    const t = await chrome.storage.local.get(["mcpServerUrl", "mcpConnectionType"]);
    Re = t.mcpConnectionType || ls;
    const e = Re === "websocket" ? Wu : Re === "streamable-http" ? Kn : Hu;
    Cr = t.mcpServerUrl || e, ds = !0, Z.debug("[Background] Server config loaded from storage:", {
      url: Cr,
      type: Re
    });
  } catch (t) {
    Z.warn("[Background] Failed to load server config from storage, using defaults:", t), Re = ls, Cr = Kn, ds = !0;
  }
}
async function av() {
  for (; !ds; )
    await new Promise((t) => setTimeout(t, 100));
}
function Rt() {
  return Cr;
}
function cv(t, e) {
  Cr = t, e && (Re = e), Z.debug("[Background] Server config updated to:", { url: t, type: Re });
}
function Gu() {
  return Bu;
}
function gt(t) {
  Bu = t, Z.debug("[Background] Connection status updated to:", t);
}
let Ht = !1, Ft = 0;
const jo = 3;
function uv(t) {
  const e = t.message.toLowerCase(), r = [
    /tool .* not found/i,
    /tool not found/i,
    /method not found/i,
    /invalid arguments/i,
    /invalid parameters/i,
    /mcp error -32602/i,
    // Invalid params
    /mcp error -32601/i,
    // Method not found
    /mcp error -32600/i,
    // Invalid request
    /tool '[^']+' is not available/i,
    /tool '[^']+' not found on server/i
  ], n = [
    /connection refused/i,
    /econnrefused/i,
    /timeout/i,
    /etimedout/i,
    /enotfound/i,
    /network error/i,
    /server unavailable/i,
    /could not connect/i,
    /connection failed/i,
    /transport error/i,
    /fetch failed/i
  ];
  return r.some((o) => o.test(e)) ? { isConnectionError: !1, isToolError: !0, category: "tool_error" } : n.some((o) => o.test(e)) ? { isConnectionError: !0, isToolError: !1, category: "connection_error" } : { isConnectionError: !1, isToolError: !0, category: "unknown_tool_error" };
}
async function Ku() {
  Je("extension_loaded", {}), Z.debug("Extension initializing...");
  try {
    const r = await rl.get();
    Z.debug("Theme initialized:", r);
  } catch (r) {
    Z.warn("Error initializing theme, continuing with defaults:", r);
  }
  await iv(), await av();
  const t = Rt();
  Z.debug("Background script initialized with server URL:", t), gt(!1), await pv(), Z.debug("Extension initialized successfully"), (async () => {
    const r = Rt();
    Z.debug(`Attempting initial connection to ${r} with transport: ${Re}`);
    let n = !1;
    try {
      await Gs(r, Re), n = await Vt(), Z.debug(`Initial connection attempt result: ${n ? "connected" : "failed"}`);
    } catch (o) {
      Z.debug(`Initial connection attempt failed: ${o instanceof Error ? o.message : String(o)}`), n = !1;
    }
    if (gt(n), ct(n), Z.debug(`Initial connection status broadcast: ${n ? "connected" : "disconnected"}`), n)
      try {
        Z.debug("[Background] Server connected, fetching and broadcasting initial tools...");
        const o = await cr(r, !1, Re);
        Z.debug(`Retrieved ${o.length} primitives for initial broadcast`);
        const s = ur(o);
        Z.debug(`Broadcasting ${s.length} normalized initial tools`), Ir(s);
      } catch (o) {
        Z.warn("[Background] Error broadcasting initial tools:", o);
      }
  })();
}
async function Gs(t, e = Re) {
  if (Ht) {
    Z.debug("Connection attempt already in progress, skipping");
    return;
  }
  Ht = !0, Ft++, Z.debug(
    `Attempting to connect to MCP server via ${e} (attempt ${Ft}/${jo}): ${t}`
  );
  try {
    await nv(t, e), Z.debug("MCP client connected successfully"), gt(!0), ct(!0);
    try {
      Z.debug("[Background] Connection successful, fetching and broadcasting tools...");
      const r = await cr(t, !0, e);
      Z.debug(`Retrieved ${r.length} primitives after connection`);
      const n = ur(r);
      Z.debug(`Broadcasting ${n.length} normalized tools after successful connection`), Ir(n);
    } catch (r) {
      Z.warn("[Background] Error broadcasting tools after connection:", r);
    }
    Ft = 0;
  } catch (r) {
    const n = uv(r instanceof Error ? r : new Error(String(r)));
    if (Z.warn(`MCP server connection failed (${n.category}): ${r.message || String(r)}`), Z.debug("Extension will continue to function with limited capabilities"), n.isConnectionError ? (gt(!1), ct(!1, r.message || String(r))) : Z.debug("Error categorized as tool-related, not updating connection status"), Ft < jo) {
      const o = Math.min(5e3 * Ft, 15e3);
      Z.debug(`Scheduling next connection attempt in ${o / 1e3} seconds...`), setTimeout(() => {
        Ht = !1, Gs(t).catch(() => {
        });
      }, o);
    } else
      Z.debug("Maximum connection attempts reached. Will try again during periodic check."), Ht = !1;
  } finally {
    Ft >= jo && (Ht = !1);
  }
}
const lv = 6e4;
setInterval(async () => {
  if (Ht)
    return;
  const t = Gu(), e = await Vt();
  if (gt(e), t !== e) {
    if (Z.debug(`Connection status changed: ${t} -> ${e}`), ct(e), e)
      try {
        Z.debug("[Background] Periodic check: Connection established, fetching and broadcasting tools...");
        const r = await cr(Rt(), !0, Re);
        Z.debug(`Periodic check: Retrieved ${r.length} primitives`);
        const n = ur(r);
        Z.debug(`Periodic check: Broadcasting ${n.length} normalized tools`), Ir(n);
      } catch (r) {
        Z.warn("[Background] Error broadcasting tools after status change:", r);
      }
  } else
    ct(e);
  if (!e && !Ht) {
    Ft = 0, Z.debug("Periodic check: MCP server not connected, attempting to connect");
    const r = Rt();
    try {
      Z.debug("[Background] Resetting MCP client connection state for periodic recovery attempt"), sv();
    } catch (n) {
      Z.warn("[Background] Error resetting MCP connection state:", n);
    }
    Gs(r, Re).catch(() => {
    });
  }
}, lv);
setInterval(() => {
}, 6e4);
self.addEventListener("unhandledrejection", (t) => {
  Z.error("Unhandled rejection in service worker:", t.reason), t.reason instanceof Error ? Vu(t.reason, "background_unhandled_rejection") : Je("extension_error", {
    error_message: `Unhandled rejection: ${JSON.stringify(t.reason)}`,
    error_context: "background_unhandled_rejection_non_error"
  });
});
self.addEventListener("error", (t) => {
  Z.error("Uncaught error in service worker:", t.error), t.error instanceof Error ? Vu(t.error, "background_uncaught_error") : Je("extension_error", {
    error_message: `Uncaught error: ${t.message}`,
    error_context: "background_uncaught_error_non_error"
  });
});
chrome.runtime.onInstalled.addListener(async (t) => {
  Z.debug("Extension installed or updated:", t.reason);
  const e = chrome.runtime.getManifest().version, r = (/* @__PURE__ */ new Date()).toISOString();
  if (t.reason === "install") {
    Z.debug("Performing first-time installation setup.");
    const n = cs();
    await chrome.storage.local.set({
      installDate: r,
      version: e,
      userProperties: {
        extension_version: e,
        install_date: r,
        ...n
      }
    }), await Zt.updateUserProperties({
      extension_version: e,
      install_date: r,
      ...n
    }), Je("extension_installed", {
      reason: t.reason,
      extension_version: e,
      ...n
    }), Me && Me.initialized && await Me.fetchConfig(!0);
  } else if (t.reason === "update") {
    const n = t.previousVersion || "unknown";
    Z.debug(`Extension updated from ${n} to ${e}`);
    const o = cs();
    await chrome.storage.local.set({
      version: e,
      previousVersion: n,
      lastUpdateDate: (/* @__PURE__ */ new Date()).toISOString()
    }), await Zt.updateUserProperties({
      extension_version: e,
      previous_version: n,
      ...o
    }), Je("extension_installed", {
      reason: t.reason,
      extension_version: e,
      previous_version: n,
      ...o
    }), Me && Me.initialized && await Me.fetchConfig(!0), setTimeout(() => {
      chrome.tabs.query({}, (s) => {
        s.forEach((i) => {
          i.id && chrome.tabs.sendMessage(i.id, {
            type: "app:version-updated",
            data: {
              oldVersion: n,
              newVersion: e,
              timestamp: Date.now()
            }
          }).catch(() => {
          });
        });
      });
    }, 1e3);
  }
});
chrome.runtime.onStartup.addListener(() => {
  Z.debug("Browser startup detected."), Je("browser_startup", {}), Ku().catch((t) => Z.error("Error initializing on startup:", t));
});
Ku().then(() => {
  Z.debug("Extension startup complete");
}).catch((t) => {
  Z.error("Error during extension initialization:", t), Z.debug("Extension will continue running with limited functionality");
});
Z.debug("Background script loaded");
Z.debug("Edit 'chrome-extension/src/background/index.ts' and save to reload.");
chrome.runtime.onMessage.addListener((t, e, r) => {
  if (Z.debug("[Background] Received message:", {
    type: t.type || t.command,
    origin: t.origin || "unknown",
    id: t.id,
    hasPayload: !!t.payload,
    from: e.tab ? `tab-${e.tab.id}` : "extension"
  }), t.type === "mcp:connection-status-changed" && t.origin === "mcpclient") {
    Z.debug("[Background] Received connection status change from MCP client:", t.payload);
    const { isConnected: n, error: o } = t.payload;
    return gt(n), ct(n, o), !1;
  }
  return t.command === "trackAnalyticsEvent" ? t.eventName && t.eventParams ? (Je(t.eventName, t.eventParams).then(() => r({ success: !0 })).catch((n) => {
    Z.error("[Background] Error tracking analytics event from message:", n), r({ success: !1, error: n instanceof Error ? n.message : String(n) });
  }), !0) : (Z.warn("[Background] Invalid trackAnalyticsEvent message received:", t), r({ success: !1, error: "Invalid eventName or eventParams" }), !1) : typeof t.type == "string" && t.type.startsWith("mcp:") ? (dv(t, e, r), !0) : typeof t.type == "string" && t.type.startsWith("remote-config:") ? (hv(t, e, r), !0) : (Z.debug("[Background] Message not handled, ignoring:", t.type || t.command), !1);
});
async function dv(t, e, r) {
  const n = Date.now(), o = t.type;
  try {
    let s = null;
    const i = t.payload || {};
    switch (Z.debug(`Processing MCP message: ${o}`), o) {
      case "mcp:call-tool": {
        const { toolName: c, args: u, adapterName: l } = i;
        if (!c)
          throw new Error("Tool name is required");
        Z.debug(`Calling tool: ${c} from adapter: ${l || "unknown"}`), s = await rv(Rt(), c, u || {}, l), Z.debug(`Tool call completed: ${c}`);
        break;
      }
      case "mcp:get-connection-status": {
        Z.debug("[Background] Getting current connection status");
        const c = Gu(), u = await Vt();
        Z.debug(`Stored status: ${c}, Actual status: ${u}`), c !== u && (Z.debug("[Background] Status mismatch detected, updating and broadcasting..."), gt(u), ct(u)), s = {
          status: u ? "connected" : "disconnected",
          isConnected: u,
          timestamp: Date.now()
        };
        break;
      }
      case "mcp:get-tools": {
        const { forceRefresh: c = !1 } = i;
        Z.debug(`Getting tools (forceRefresh: ${c})`);
        try {
          const u = await cr(Rt(), c, Re);
          Z.debug(`Retrieved ${u.length} primitives from server`);
          const l = ur(u);
          Z.debug(`Returning ${l.length} normalized tools to content script`), s = l;
        } catch (u) {
          Z.error("[Background] Error getting tools:", u), s = [];
        }
        break;
      }
      case "mcp:force-reconnect": {
        Z.debug("[Background] Force reconnect requested via context bridge");
        try {
          ct(!1, "Reconnecting..."), Z.debug("[Background] Starting force reconnection process..."), ov();
          const c = sc(Rt(), Re), u = new Promise(
            (h, m) => setTimeout(() => m(new Error("Reconnection timeout after 20 seconds")), 2e4)
          );
          await Promise.race([c, u]), Z.debug("[Background] Force reconnect completed successfully");
          const l = await Vt();
          if (gt(l), ct(l), l)
            try {
              Z.debug("[Background] Fetching tools after successful reconnection...");
              const h = await cr(Rt(), !0, Re);
              Z.debug(`Retrieved ${h.length} primitives after reconnection`);
              const m = ur(h);
              Z.debug(`Broadcasting ${m.length} normalized tools after reconnection`), Ir(m);
            } catch (h) {
              Z.error("[Background] Error fetching tools after reconnect:", h);
            }
          s = { isConnected: l, message: "Reconnection completed" };
        } catch (c) {
          Z.error("[Background] Force reconnect failed:", c);
          const u = await Vt();
          gt(u);
          const l = c instanceof Error ? c.message : String(c);
          ct(u, l), s = { isConnected: u, error: l };
        }
        break;
      }
      case "mcp:get-server-config": {
        const c = await chrome.storage.local.get(["mcpServerUrl", "mcpConnectionType"]), u = Re === "websocket" ? Wu : Re === "streamable-http" ? Kn : Hu;
        s = {
          uri: c.mcpServerUrl || u,
          connectionType: c.mcpConnectionType || Re
        };
        break;
      }
      case "mcp:update-server-config": {
        const { config: c } = i;
        if (!c || typeof c.uri != "string")
          throw new Error("Invalid server config: uri is required");
        let u = c.connectionType;
        if (Z.debug(`Received connection type: ${c.connectionType}, parsed as: ${u}`), !u)
          try {
            const h = new URL(c.uri);
            u = h.protocol === "ws:" || h.protocol === "wss:" ? "websocket" : "sse";
          } catch {
            u = Re;
          }
        Z.debug(`Updating server config to: ${c.uri} (${u})`), await chrome.storage.local.set({
          mcpServerUrl: c.uri,
          mcpConnectionType: u
        }), cv(c.uri, u), fv({ uri: c.uri, connectionType: u }), (async () => {
          try {
            Z.debug("[Background] Starting async reconnection after config update..."), await sc(c.uri, u);
            const h = await Vt();
            if (gt(h), ct(h), Z.debug(`Async reconnection completed, connected: ${h}`), h)
              try {
                const m = await cr(c.uri, !0, u), _ = ur(m);
                Ir(_), Z.debug(`Broadcasted ${_.length} normalized tools after config update`);
              } catch (m) {
                Z.warn("[Background] Failed to fetch tools after config update:", m);
              }
          } catch (h) {
            Z.warn("[Background] Async reconnect after config update failed:", h);
            const m = await Vt();
            gt(m);
            const _ = h instanceof Error ? h.message : String(h);
            ct(m, _);
          }
        })().catch((h) => {
          Z.error("[Background] Unhandled error in async reconnection:", h);
        }), s = { success: !0 };
        break;
      }
      case "mcp:heartbeat": {
        const { timestamp: c } = i, u = tv();
        s = {
          timestamp: Date.now(),
          isConnected: u,
          receivedTimestamp: c
        }, t.id && setTimeout(() => {
          chrome.tabs.query({}, (l) => {
            l.forEach((h) => {
              h.id && chrome.tabs.sendMessage(h.id, {
                type: "mcp:heartbeat-response",
                payload: { timestamp: Date.now(), isConnected: u },
                origin: "background",
                timestamp: Date.now()
              }).catch(() => {
              });
            });
          });
        }, 0);
        break;
      }
      default:
        throw new Error(`Unhandled MCP message type: ${o}`);
    }
    const a = Date.now() - n;
    Z.debug(`MCP message ${o} processed in ${a}ms`), r({
      type: `${o}:response`,
      payload: s,
      success: !0,
      timestamp: Date.now(),
      processingTime: a,
      origin: "background",
      id: t.id
    });
  } catch (s) {
    const i = Date.now() - n, a = s instanceof Error ? s.message : String(s);
    Z.error(`MCP message handling error (${i}ms):`, s), r({
      type: `${o}:response`,
      error: a,
      success: !1,
      timestamp: Date.now(),
      processingTime: i,
      origin: "background",
      id: t.id
    });
  }
}
function ct(t, e) {
  const r = e ? "error" : t ? "connected" : "disconnected";
  Z.debug(`Broadcasting connection status: ${r} (connected: ${t})`);
  const n = {
    type: "connection:status-changed",
    payload: {
      status: r,
      // Type assertion needed due to status calculation
      error: e || void 0,
      isConnected: t,
      timestamp: Date.now()
    },
    origin: "background",
    timestamp: Date.now()
  };
  chrome.tabs.query({}, (o) => {
    o.forEach((s) => {
      s.id && chrome.tabs.sendMessage(s.id, n).catch(() => {
      });
    });
  });
}
function Ir(t) {
  Z.debug(`Broadcasting tools update to content scripts: ${t.length} tools`);
  const e = {
    type: "mcp:tool-update",
    payload: {
      tools: t
    },
    origin: "background",
    timestamp: Date.now()
  };
  chrome.tabs.query({}, (r) => {
    r.forEach((n) => {
      n.id && chrome.tabs.sendMessage(n.id, e).catch(() => {
      });
    });
  });
}
function fv(t) {
  Z.debug(`Broadcasting config update to content scripts: ${t.uri}`);
  const e = {
    type: "mcp:server-config-updated",
    payload: {
      config: t
      // Type assertion due to partial config structure
    },
    origin: "background",
    timestamp: Date.now()
  };
  chrome.tabs.query({}, (r) => {
    r.forEach((n) => {
      n.id && chrome.tabs.sendMessage(n.id, e).catch(() => {
      });
    });
  });
}
async function hv(t, e, r) {
  const n = Date.now();
  try {
    if (Z.debug(`Processing Remote Config message: ${t.type}`), !Me || !Me.initialized)
      throw new Error("Remote Config Manager not initialized");
    let o = null;
    switch (t.type) {
      case "remote-config:fetch": {
        const { force: i = !1 } = t.payload || {};
        Z.debug(`Fetching remote config (force: ${i})`), await Me.fetchConfig(i), o = { success: !0, timestamp: Date.now() };
        break;
      }
      case "remote-config:get-feature-flag": {
        const { flagName: i } = t.payload || {};
        if (!i)
          throw new Error("Feature flag name is required");
        Z.debug(`Getting feature flag: ${i}`), o = await Me.getFeatureFlag(i);
        break;
      }
      case "remote-config:get-config": {
        const { key: i } = t.payload || {};
        i ? (Z.debug(`Getting specific config for key: ${i}`), o = await Me.getSpecificConfig(i)) : (Z.debug("[Background] Getting all remote config"), o = await Me.getAllConfig());
        break;
      }
      case "remote-config:get-status": {
        Z.debug("[Background] Getting remote config status"), o = {
          initialized: Me.initialized,
          lastFetchTime: await Me.getLastFetchTimePublic(),
          timestamp: Date.now()
        };
        break;
      }
      case "remote-config:clear-cache": {
        Z.debug("[Background] Clearing remote config cache and refreshing"), o = {
          success: await Me.clearCacheAndRefresh(),
          timestamp: Date.now()
        };
        break;
      }
      default:
        throw new Error(`Unknown remote config message type: ${t.type}`);
    }
    const s = {
      success: !0,
      data: o,
      processingTime: Date.now() - n,
      timestamp: Date.now()
    };
    Z.debug(`Remote Config message processed successfully: ${t.type} (${s.processingTime}ms)`), r(s);
  } catch (o) {
    const s = o instanceof Error ? o.message : String(o);
    Z.error(`Error processing Remote Config message ${t.type}:`, o);
    const i = {
      success: !1,
      error: s,
      processingTime: Date.now() - n,
      timestamp: Date.now()
    };
    r(i);
  }
}
async function pv() {
  try {
    Me = new al(), await Me.initialize(), Z.debug("[Background] Remote Config Manager initialized successfully"), typeof globalThis < "u" && (globalThis.remoteConfigManager = Me, Z.debug("[Background] RemoteConfigManager is now accessible globally as window.remoteConfigManager"));
  } catch (t) {
    Z.error("[Background] Failed to initialize Remote Config Manager:", t);
  }
}
